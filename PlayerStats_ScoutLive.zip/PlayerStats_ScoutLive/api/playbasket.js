// api/playbasket.js  (Vercel Serverless Function)
// Scarica lato server una pagina profilo di playbasket.it e ne restituisce l'HTML.
// La lettura delle tabelle (stagioni e partite) avviene nel browser, in playbasket-import.js.
// Nessuna dipendenza esterna. Endpoint: /api/playbasket?url=<link profilo>

module.exports = async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  const fail = (code, error) => res.status(code).json({ error });

  const raw = req.query && req.query.url;
  let target;
  try { target = new URL(raw); } catch { return fail(400, "Link non valido."); }

  // Sicurezza: solo playbasket.it, solo pagine profilo (evita che la funzione diventi un proxy aperto)
  const hostOk = target.protocol === "https:" && /(^|\.)playbasket\.it$/i.test(target.hostname);
  if (!hostOk || !/\/profile\.php$/i.test(target.pathname)) {
    return fail(400, "Serve il link di un profilo giocatore di playbasket.it.");
  }

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  try {
    const r = await fetch(target.toString(), {
      signal: ctrl.signal,
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; PlayerStatsProfile/1.0)",
        "Accept": "text/html",
        "Accept-Language": "it-IT,it;q=0.9"
      }
    });
    if (!r.ok) return fail(502, `PlayBasket ha risposto con errore ${r.status}.`);
    if (!/(^|\.)playbasket\.it$/i.test(new URL(r.url).hostname)) return fail(502, "Reindirizzamento non consentito.");
    const html = await r.text();
    if (html.length > 3000000) return fail(413, "Pagina troppo grande.");
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    return res.status(200).send(html);
  } catch (e) {
    return fail(504, e.name === "AbortError" ? "PlayBasket non risponde (timeout)." : "Impossibile contattare PlayBasket.");
  } finally {
    clearTimeout(timer);
  }
};
