const defaults = {
  profile: {
    firstName: "",
    lastName: "",
    number: "",
    role: "",
    height: "",
    weight: "",
    birthDate: "",
    photo: ""
  },
  games: [],
  // Stagioni che l'utente ha scelto di escludere dalle statistiche generali (dato salvabile)
  excludedSeasons: [],
};

// ICONA DEFAULT A TEMA BASKET (PALLONE DA BASKET STILIZZATO)
const DEFAULT_USER_AVATAR = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100' fill='none' stroke='%23f47721' stroke-width='6' stroke-linecap='round' stroke-linejoin='round'><circle cx='50' cy='50' r='44' fill='%23101d35'/><path d='M6 50h88'/><path d='M50 6v88'/><path d='M20 12c22 18 22 58 0 76'/><path d='M80 12c-22 18-22 58 0 76'/></svg>";

// ID del giocatore corrente, letto dall'URL (player.html?id=...).
// Senza id valido si torna alla home/roster: ogni giocatore ha la sua scheda dati.
const PLAYER_ID = new URLSearchParams(location.search).get("id");
if (!PLAYER_ID) {
  location.replace("index.html");
  throw new Error("Nessun ID giocatore nell'URL: reindirizzamento alla home.");
}

const STORAGE_KEY = `capocottaStats_${PLAYER_ID}`;
const REGISTRY_KEY = "capocottaPlayersRegistry"; // "database" con l'elenco di tutti i giocatori
const THEME_KEY = "capocottaTheme";
const COLUMN_PREFS_KEY = "capocottaColumnsPrefs";
const $ = id => document.getElementById(id);

// Tiene aggiornata la scheda del giocatore nel registro usato dalla home,
// cosi' la roster mostra sempre nome/numero/ruolo/foto aggiornati senza export/import.
function loadRegistry() {
  try {
    const r = JSON.parse(localStorage.getItem(REGISTRY_KEY));
    return Array.isArray(r) ? r : [];
  } catch (e) {
    return [];
  }
}

// --- Protezione con password del singolo giocatore ---
// currentPassHash: hash (SHA-256) della password impostata per questo giocatore,
// letto dal registro locale ("" se non ancora impostata). window.viewOnly parte
// bloccato (sola lettura) finche' la verifica non sblocca la modalita' di modifica.
const existingRegEntry = loadRegistry().find(p => p.id === PLAYER_ID);
let currentPassHash = (existingRegEntry && existingRegEntry.passHash) || "";
let currentNoPassword = !!(existingRegEntry && existingRegEntry.noPassword); // creato volontariamente senza password
let bannerDismissed = false;
let accessResolved = false; // il banner "sola lettura" compare solo dopo la verifica di accesso (niente lampeggio)
window.viewOnly = true;

async function sha256Hex(str) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
}

// La foto nel registro (home + database condiviso) deve restare leggera: un documento
// Firestore non puo' superare 1 MB, e una foto enorme bloccava salvataggi e caricamento.
function photoForRegistry(photo) {
  return (photo && photo.length < 400000) ? photo : "";
}

// Un profilo "vuoto" (nessun nome/numero/ruolo) e' quello di default di un dispositivo che
// non ha ancora scaricato i dati: NON deve mai essere scritto nel registro o nel cloud,
// altrimenti cancella nome, foto e password del giocatore per tutti gli altri dispositivi.
function isEmptyProfile(p) {
  return !(p && (p.firstName || p.lastName || p.number || p.role));
}

// Scritture verso il cloud non ancora confermate (es. rete assente): restano segnate qui
// e vengono rinviate al prossimo caricamento, invece di essere sovrascritte dai dati online.
const PENDING_KEY = "capocottaPendingCloud";
function loadPending() {
  try {
    const p = JSON.parse(localStorage.getItem(PENDING_KEY)) || {};
    return { players: Array.isArray(p.players) ? p.players : [], stats: Array.isArray(p.stats) ? p.stats : [] };
  } catch (e) {
    return { players: [], stats: [] };
  }
}
function setPending(kind, id, on) {
  const p = loadPending();
  const set = new Set(p[kind]);
  if (on) set.add(id); else set.delete(id);
  p[kind] = [...set];
  PhotoUtils.safeSet(PENDING_KEY, JSON.stringify(p));
}

// Avviso non bloccante quando il salvataggio online fallisce (prima falliva in silenzio)
let cloudWarnShown = false;
function cloudWarn(msg) {
  if (cloudWarnShown) return;
  cloudWarnShown = true;
  const el = document.createElement("div");
  el.textContent = msg;
  el.style.cssText = "position:fixed;left:50%;bottom:20px;transform:translateX(-50%);max-width:92vw;z-index:9999;background:#b3261e;color:#fff;padding:10px 16px;border-radius:10px;font-size:13px;box-shadow:0 6px 24px rgba(0,0,0,.35);cursor:pointer";
  el.onclick = () => el.remove();
  document.body.appendChild(el);
  setTimeout(() => { el.remove(); cloudWarnShown = false; }, 9000);
}

// Voce del registro giocatori. La password viene inclusa solo se nota: un dispositivo che
// non la conosce (dati non ancora scaricati) non deve azzerarla.
function registryEntry(profile) {
  const e = {
    id: PLAYER_ID,
    firstName: profile.firstName || "",
    lastName: profile.lastName || "",
    number: profile.number || "",
    role: profile.role || "",
    photo: photoForRegistry(profile.photo),
    updatedAt: Date.now()
  };
  if (currentPassHash) { e.passHash = currentPassHash; e.noPassword = false; }
  else if (currentNoPassword) e.noPassword = true;
  // Media punti (PPG) mostrata nella home: stesse partite del riepilogo con "Tutte le stagioni"
  // (stagioni deselezionate nel menu "Statistiche" e amichevoli pre season escluse).
  // Un dispositivo che non ha ancora scaricato le partite non deve azzerare il valore online.
  if (data.games.length || remoteState === "ok") e.avgPts = computeAvgPts(data);
  return e;
}

function computeAvgPts(d) {
  const excluded = Array.isArray(d.excludedSeasons) ? d.excludedSeasons : [];
  const vals = d.games
    .filter(x => x.gameType !== "Amichevole (Pre season)" && !excluded.includes(x.season))
    .filter(x => x.pts !== null && x.pts !== undefined && x.pts !== "Unknown" && x.pts !== "" && !isNaN(x.pts))
    .map(x => Number(x.pts));
  return vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length * 10) / 10 : null;
}

// Aggiorna solo la media punti nel registro (locale + online) per i giocatori salvati prima
// di questa funzione o quando cambiano i dati da un altro dispositivo. Scrive solo se cambia.
function syncAvgPts() {
  if (!data.games.length || isEmptyProfile(data.profile)) return;
  const avg = computeAvgPts(data);
  const reg = loadRegistry();
  const idx = reg.findIndex(p => p.id === PLAYER_ID);
  if (idx < 0 || reg[idx].avgPts === avg) return;
  reg[idx].avgPts = avg;
  PhotoUtils.safeSet(REGISTRY_KEY, JSON.stringify(reg));
  if (window.cloudDB) {
    window.cloudDB.collection("players").doc(PLAYER_ID).set({ avgPts: avg }, { merge: true }).catch(() => {});
  }
}

function syncRegistryEntry(profile) {
  if (isEmptyProfile(profile)) return;
  const reg = loadRegistry();
  const idx = reg.findIndex(p => p.id === PLAYER_ID);
  const entry = { ...(idx >= 0 ? reg[idx] : {}), ...registryEntry(profile) };
  if (idx >= 0) reg[idx] = entry; else reg.push(entry);
  PhotoUtils.safeSet(REGISTRY_KEY, JSON.stringify(reg));
}

// Gestione Preferenze Colonne Tabella (di default nascoste)
const defaultColumnPrefs = { advanced: false, team: false, category: false, ageGroup: false, gameType: false, date: false, venue: false };

function loadColumnPrefs() {
  try {
    const saved = JSON.parse(localStorage.getItem(COLUMN_PREFS_KEY));
    if (saved && typeof saved === "object") {
      return { ...defaultColumnPrefs, ...saved };
    }
  } catch (e) {
    console.warn("Preferenze colonne non leggibili", e);
  }
  return { ...defaultColumnPrefs };
}

let columnPrefs = loadColumnPrefs();
const saveColumnPrefs = () => localStorage.setItem(COLUMN_PREFS_KEY, JSON.stringify(columnPrefs));

function setupDropdown(btn, menu) {
  if (!btn || !menu) return;

  btn.addEventListener("click", e => {
    e.stopPropagation();
    const isOpen = menu.classList.contains("open");

    document.querySelectorAll(".columns-menu.open").forEach(m => m.classList.remove("open"));
    document.querySelectorAll(".col-menu-btn.active").forEach(b => b.classList.remove("active"));

    if (!isOpen) {
      menu.classList.add("open");
      btn.classList.add("active");
    }
  });

  menu.addEventListener("click", e => e.stopPropagation());
}

function initColumnsMenu() {
  const btn = $("columnsToggle");
  const menu = $("columnsMenu");
  if (!btn || !menu) return;

  menu.querySelectorAll('input[type="checkbox"]').forEach(cb => {
    const key = cb.dataset.col;
    cb.checked = !!columnPrefs[key];
    cb.addEventListener("change", () => {
      columnPrefs[key] = cb.checked;
      saveColumnPrefs();
      render();
    });
  });

  setupDropdown(btn, menu);
}

initColumnsMenu();
setupDropdown($("seasonStatsBtn"), $("seasonStatsMenu"));

document.addEventListener("click", () => {
  document.querySelectorAll(".columns-menu.open").forEach(m => m.classList.remove("open"));
  document.querySelectorAll(".col-menu-btn.active").forEach(b => b.classList.remove("active"));
});

// Gestione Blocco Scroll Pagina durante i Modali Aperti
function toggleBodyScroll(disable) {
  if (disable) {
    document.body.style.overflow = 'hidden';
  } else {
    document.body.style.overflow = '';
  }
}

// Eventi per ripristinare lo scroll alla chiusura dei dialog
document.querySelectorAll('dialog').forEach(dialog => {
  dialog.addEventListener('close', () => toggleBodyScroll(false));
});

// Gestione Tema
function initTheme() {
  const savedTheme = localStorage.getItem(THEME_KEY);
  if (savedTheme === "dark") {
    document.documentElement.classList.add("dark-mode");
    if ($("themeToggle")) $("themeToggle").textContent = "☀️ Light Mode";
  } else {
    document.documentElement.classList.remove("dark-mode");
    if ($("themeToggle")) $("themeToggle").textContent = "🌙 Night Mode";
  }
}

function toggleTheme() {
  const btn = $("themeToggle");
  if (btn) btn.classList.add("theme-pop");

  const isDark = document.documentElement.classList.toggle("dark-mode");
  localStorage.setItem(THEME_KEY, isDark ? "dark" : "light");
  
  if (btn) {
    btn.textContent = isDark ? "☀️ Light Mode" : "🌙 Night Mode";
    setTimeout(() => btn.classList.remove("theme-pop"), 400);
  }
}

initTheme();

// Gestione Fluidita Scroll Sticky Hero (Proporzionale e senza glitch)
function initStickyHero() {
  const hero = document.querySelector('.hero');
  if (!hero) return;

  const maxScroll = 120;
  const smoothing = 0.14; // piu' basso = ridimensionamento piu' morbido/lento nell'inseguire lo scroll
  let targetProgress = 0;
  let currentProgress = 0;
  let rafId = null;

  function animate() {
    const diff = targetProgress - currentProgress;

    // Quando la differenza e' impercettibile, agganciamo direttamente il valore finale
    if (Math.abs(diff) < 0.001) {
      currentProgress = targetProgress;
    } else {
      currentProgress += diff * smoothing;
    }

    hero.classList.toggle('is-sticky', currentProgress > 0.01);
    hero.style.setProperty('--scroll-progress', currentProgress);

    if (currentProgress !== targetProgress) {
      rafId = requestAnimationFrame(animate);
    } else {
      rafId = null;
    }
  }

  const handleScroll = () => {
    const scrolled = window.scrollY;
    targetProgress = Math.min(Math.max(scrolled / maxScroll, 0), 1);

    if (rafId === null) {
      rafId = requestAnimationFrame(animate);
    }
  };

  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();
}

initStickyHero();

function loadData() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (saved && saved.profile && Array.isArray(saved.games)) {
      return {
        profile: { ...defaults.profile, ...saved.profile },
        games: saved.games,
        excludedSeasons: Array.isArray(saved.excludedSeasons) ? saved.excludedSeasons : [],
        updatedAt: Number(saved.updatedAt) || 0,
      };
    }
  } catch (e) {
    console.warn("Dati salvati non leggibili", e);
  }
  return structuredClone(defaults);
}

let data = loadData(), editing = -1;
// Stato del caricamento dal database condiviso: evita che un dispositivo senza dati locali
// mostri "Nuovo Giocatore" (sembra un giocatore non registrato) mentre i dati stanno arrivando.
let remoteState = window.cloudDB ? "loading" : "ok"; // loading | ok | missing | error
let pendingPhotoBase64 = null;

// --- Sincronizzazione con il database condiviso (Firebase), se configurato ---
// Il salvataggio locale resta il percorso principale (istantaneo, sempre
// funzionante anche offline); se firebase-config.js e' configurato, ogni
// salvataggio viene replicato anche online cosi' altre persone, da altri
// dispositivi, vedono le stesse partite e statistiche.
function cloudSaveStats() {
  if (!window.cloudDB) return;
  setPending("stats", PLAYER_ID, true);
  window.cloudDB.collection("playerStats").doc(PLAYER_ID).set(data)
    .then(() => setPending("stats", PLAYER_ID, false))
    .catch(e => {
      console.warn("Sincronizzazione cloud (statistiche) fallita:", e);
      cloudWarn("Salvataggio online non riuscito: le modifiche sono solo su questo dispositivo. Riprova più tardi.");
    });
}
function cloudSyncRegistryEntry(profile) {
  if (!window.cloudDB || isEmptyProfile(profile)) return;
  setPending("players", PLAYER_ID, true);
  // merge: aggiorna solo i campi inviati, senza cancellare quelli che questo dispositivo non conosce
  window.cloudDB.collection("players").doc(PLAYER_ID).set(registryEntry(profile), { merge: true })
    .then(() => setPending("players", PLAYER_ID, false))
    .catch(e => console.warn("Sincronizzazione cloud (registro) fallita:", e));
}

// Ripara le schede gia' rovinate dal vecchio comportamento: se la voce online del giocatore
// e' vuota ma le sue statistiche hanno il profilo, rimette nome/numero/ruolo/foto.
async function healCloudRegistry(profile) {
  if (!window.cloudDB || isEmptyProfile(profile)) return;
  try {
    const ref = window.cloudDB.collection("players").doc(PLAYER_ID);
    const d = await ref.get();
    if (!d.exists || !isEmptyProfile(d.data())) return;
    const fix = {
      id: PLAYER_ID,
      firstName: profile.firstName || "",
      lastName: profile.lastName || "",
      number: profile.number || "",
      role: profile.role || "",
      updatedAt: Date.now()
    };
    const ph = photoForRegistry(profile.photo);
    if (ph) fix.photo = ph;
    await ref.set(fix, { merge: true });
    syncRegistryEntry(profile);
  } catch (e) {
    console.warn("Riparazione voce registro non riuscita", e);
  }
}

async function cloudRefreshStats() {
  if (!window.cloudDB) return;
  try {
    const doc = await window.cloudDB.collection("playerStats").doc(PLAYER_ID).get();
    const pendingLocal = loadPending().stats.includes(PLAYER_ID);
    if (doc.exists) {
      const saved = doc.data();
      if (saved && saved.profile && Array.isArray(saved.games)) {
        if (pendingLocal || (data.updatedAt || 0) > (Number(saved.updatedAt) || 0)) {
          // Le modifiche fatte su questo dispositivo non erano ancora arrivate online: vincono
          // e vengono reinviate, invece di essere sostituite con i dati vecchi del cloud.
          cloudSaveStats();
        } else {
          data = {
            profile: { ...defaults.profile, ...saved.profile },
            games: saved.games,
            excludedSeasons: Array.isArray(saved.excludedSeasons) ? saved.excludedSeasons : [],
            updatedAt: Number(saved.updatedAt) || 0,
          };
          PhotoUtils.safeSet(STORAGE_KEY, JSON.stringify(data));
          shrinkLoadedPhoto();
        }
        healCloudRegistry(data.profile);
      }
      remoteState = "ok";
      render();
    } else if (pendingLocal && !isEmptyProfile(data.profile)) {
      // Giocatore creato offline e mai arrivato online: lo carichiamo ora.
      // (Se invece non e' in attesa, e' stato eliminato da un altro dispositivo: non lo resuscitiamo.)
      cloudSaveStats();
      cloudSyncRegistryEntry(data.profile);
      remoteState = "ok";
      render();
    } else if (isEmptyProfile(data.profile) && !data.games.length) {
      // Nessuna statistica online e nessun dato locale: la scheda base (nome, numero, ruolo, foto)
      // si ricostruisce dalla voce del registro giocatori, cosi' il giocatore non risulta "non registrato".
      const reg = await window.cloudDB.collection("players").doc(PLAYER_ID).get();
      if (reg.exists && !isEmptyProfile(reg.data())) {
        const r = reg.data();
        data.profile = { ...defaults.profile, firstName: r.firstName || "", lastName: r.lastName || "", number: r.number || "", role: r.role || "", photo: r.photo || "" };
        remoteState = "ok";
      } else {
        remoteState = "missing";
      }
      render();
    } else {
      remoteState = "ok";
    }
  } catch (e) {
    console.warn("Impossibile scaricare le statistiche dal database condiviso, mostro i dati salvati localmente.", e);
    remoteState = "error";
    render();
  }
}

const save = () => {
  data.updatedAt = Date.now();
  const savedLocally = PhotoUtils.safeSet(STORAGE_KEY, JSON.stringify(data));
  if (!savedLocally && !window.cloudDB) alert("Memoria del browser piena: impossibile salvare le modifiche.");
  syncRegistryEntry(data.profile);
  cloudSaveStats();
  cloudSyncRegistryEntry(data.profile);
};

// Foto salvate in passato senza compressione: le riduciamo una volta sola,
// cosi' salvataggi, import/export e home tornano veloci.
let shrinkingPhoto = false;
async function shrinkLoadedPhoto() {
  const p = data.profile.photo;
  if (shrinkingPhoto || !p || p.length <= PhotoUtils.HEAVY) return;
  shrinkingPhoto = true;
  try {
    const small = await PhotoUtils.compressDataUrl(p);
    if (data.profile.photo === p) {
      data.profile.photo = small;
      PhotoUtils.safeSet(STORAGE_KEY, JSON.stringify(data));
      render();
      if (!window.viewOnly) save();
    }
  } catch (e) {
    console.warn("Impossibile ridurre la foto salvata", e);
  } finally {
    shrinkingPhoto = false;
  }
}

// NB: all'apertura della scheda non si scrive piu' nulla nel registro/cloud. Prima si
// inviava subito il profilo locale, che su un secondo dispositivo e' vuoto: cosi' nome,
// foto e password del giocatore venivano cancellati per tutti. Ora si scrive solo quando
// l'utente salva, o per riparare/rinviare dati (vedi cloudRefreshStats).

function applyViewOnly() {
  document.body.classList.toggle("view-only", window.viewOnly);
  const banner = $("viewOnlyBanner");
  if (banner) banner.classList.toggle("hidden", !accessResolved || !window.viewOnly || bannerDismissed);
}

// Prova a leggere l'hash password piu' recente dal database condiviso (se configurato),
// cosi' chi apre il link da un altro dispositivo, senza il registro locale, viene
// comunque verificato correttamente invece di poter impostare una nuova password.
async function resolvePassHash() {
  if (!window.cloudDB) return;
  try {
    const doc = await window.cloudDB.collection("players").doc(PLAYER_ID).get();
    if (doc.exists) {
      const d = doc.data();
      if (d && typeof d.passHash === "string") currentPassHash = d.passHash;
      if (d) currentNoPassword = !!d.noPassword;
    }
  } catch (e) {
    console.warn("Impossibile verificare la password dal database condiviso, uso quella salvata localmente.", e);
  }
}


// Sblocco per sessione: dopo aver inserito la password di un giocatore, resta sbloccato finche'
// non si chiude il sito (sessionStorage). Si salva l'hash: se la password cambia, lo sblocco decade.
const UNLOCK_KEY = "psUnlockedHashes";
// Si ricordano gli hash delle password inserite in questa sessione: ogni giocatore con la stessa password
// risulta sbloccato. Se la password di un giocatore cambia, il nuovo hash non e' nella lista e la chiede.
function getUnlocked() { try { const a = JSON.parse(sessionStorage.getItem(UNLOCK_KEY)); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
function markUnlocked(id, hash) { if (!hash) return; const u = getUnlocked(); if (u.includes(hash)) return; u.push(hash); try { sessionStorage.setItem(UNLOCK_KEY, JSON.stringify(u)); } catch (e) {} }
function isUnlocked(id, hash) { return !!hash && getUnlocked().includes(hash); }

let statsReady = Promise.resolve();

function runAccessControl() {
  return new Promise(async resolve => {
    // Non si sblocca la modifica finche' i dati del cloud non sono arrivati (max 6 s): editare
    // con dati vecchi/vuoti e salvare li sovrascriverebbe online.
    await Promise.race([statsReady, new Promise(r => setTimeout(r, 6000))]);

    // Chi ha appena creato il giocatore ha gia' impostato la password in questo stesso
    // passaggio: non gliela richiediamo di nuovo immediatamente dopo.
    const justSetKey = `capocottaJustSet_${PLAYER_ID}`;
    if (sessionStorage.getItem(justSetKey) === "1") {
      sessionStorage.removeItem(justSetKey);
      markUnlocked(PLAYER_ID, currentPassHash);
      window.viewOnly = false;
      applyViewOnly();
      resolve();
      return;
    }

    // L'hash aggiornato viene letto dal database condiviso in background: se la password e' gia'
    // nota localmente (caso normale) la finestra si apre subito, senza aspettare la rete.
    const cloudReady = resolvePassHash();
    if (!currentPassHash && !currentNoPassword) await cloudReady;

    // Gia' sbloccato in questa sessione (password inserita in precedenza): nessuna nuova richiesta.
    // Si conferma con l'hash piu' recente dal cloud, cosi' una password cambiata invalida lo sblocco.
    if (currentPassHash && isUnlocked(PLAYER_ID, currentPassHash)) {
      await Promise.race([cloudReady, new Promise(r => setTimeout(r, 1500))]);
      if (isUnlocked(PLAYER_ID, currentPassHash)) {
        window.viewOnly = false;
        applyViewOnly();
        render();
        resolve();
        return;
      }
    }

    // Giocatore creato volontariamente "senza password": nessuna richiesta, modificabile da chiunque
    if (!currentPassHash && currentNoPassword) {
      window.viewOnly = false;
      applyViewOnly();
      render();
      resolve();
      return;
    }

    const dialog = $("accessDialog");
    if (!dialog) { window.viewOnly = false; applyViewOnly(); resolve(); return; }

    const fieldsWrap = $("accessFields");
    const title = $("accessTitle");
    const desc = $("accessDesc");
    const errorEl = $("accessError");
    const form = $("accessForm");
    const skipBtn = $("accessSkip");
    const isSetup = !currentPassHash;

    title.textContent = isSetup ? "Imposta una Password" : "Password Giocatore";
    desc.textContent = isSetup
      ? "Questo giocatore non ha ancora una password. Impostane una per proteggere le modifiche future (facoltativo)."
      : "Inserisci la password per modificare le statistiche di questo giocatore.";
    fieldsWrap.innerHTML = isSetup
      ? `<label class="field full-width">Nuova password <input type="password" id="accessPass1" minlength="4" autocomplete="new-password"></label>
         <label class="field full-width">Conferma password <input type="password" id="accessPass2" minlength="4" autocomplete="new-password"></label>`
      : `<label class="field full-width">Password <input type="password" id="accessPass1" autocomplete="current-password"></label>`;
    skipBtn.textContent = isSetup ? "Non ora, resta senza password" : "Continua in sola visualizzazione";
    errorEl.classList.add("hidden");

    let decided = false;
    const finish = viewOnly => {
      if (decided) return;
      decided = true;
      window.viewOnly = viewOnly;
      applyViewOnly();
      render();
      dialog.close();
      resolve();
    };

    skipBtn.onclick = () => finish(isSetup ? false : true);

    form.onsubmit = async e => {
      e.preventDefault();
      const p1 = $("accessPass1") ? $("accessPass1").value : "";

      if (isSetup) {
        const p2 = $("accessPass2") ? $("accessPass2").value : "";
        if (!p1) { finish(false); return; } // password vuota = nessuna password (come "non ora")
        if (p1.length < 4) {
          errorEl.textContent = "La password deve avere almeno 4 caratteri.";
          errorEl.classList.remove("hidden");
          return;
        }
        if (p1 !== p2) {
          errorEl.textContent = "Le due password non coincidono.";
          errorEl.classList.remove("hidden");
          return;
        }
        currentPassHash = await sha256Hex(p1);
        markUnlocked(PLAYER_ID, currentPassHash);
        syncRegistryEntry(data.profile);
        cloudSyncRegistryEntry(data.profile);
        finish(false);
      } else {
        const hash = await sha256Hex(p1);
        await cloudReady; // usa l'hash piu' recente (di norma gia' pronto)
        if (hash === currentPassHash) {
          markUnlocked(PLAYER_ID, currentPassHash);
          finish(false);
        } else {
          errorEl.textContent = "Password errata.";
          errorEl.classList.remove("hidden");
        }
      }
    };

    dialog.addEventListener("cancel", () => finish(isSetup ? false : true), { once: true });

    toggleBodyScroll(true);
    dialog.showModal();
  });
}

if ($("unlockBtn")) $("unlockBtn").onclick = () => { bannerDismissed = false; runAccessControl(); };
if ($("dismissBannerBtn")) $("dismissBannerBtn").onclick = () => { bannerDismissed = true; applyViewOnly(); };

if ($("backHome")) $("backHome").onclick = () => { location.href = "index.html"; };

function showCustomConfirm(title, message, isDangerous = false, hideCancel = false) {
  return new Promise((resolve) => {
    const dialog = $("confirmDialog");
    const okBtn = $("confirmOk");
    const cancelBtn = $("confirmCancel");
    const closeXBtn = $("closeConfirmBtn");

    $("confirmTitle").textContent = title;
    $("confirmMessage").textContent = message;

    if (isDangerous) {
      okBtn.className = "delete-btn";
    } else {
      okBtn.className = "primary";
    }

    cancelBtn.style.display = hideCancel ? "none" : "inline-block";

    const handleOk = () => {
      cleanup();
      dialog.close();
      resolve(true);
    };

    const handleCancel = () => {
      cleanup();
      dialog.close();
      resolve(false);
    };

    const cleanup = () => {
      okBtn.removeEventListener("click", handleOk);
      cancelBtn.removeEventListener("click", handleCancel);
      closeXBtn.removeEventListener("click", handleCancel);
    };

    okBtn.addEventListener("click", handleOk);
    cancelBtn.addEventListener("click", handleCancel);
    closeXBtn.addEventListener("click", handleCancel);

    toggleBodyScroll(true);
    dialog.showModal();
  });
}

function calculateAge(birthDateStr) {
  if (!birthDateStr) return null;
  const birth = new Date(birthDateStr);
  if (isNaN(birth.getTime())) return null;

  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();

  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--;
  }

  return age >= 0 ? age : null;
}

function mean(g, k) {
  const validGames = g.filter(x => x[k] !== null && x[k] !== undefined && x[k] !== "Unknown" && x[k] !== "" && !isNaN(x[k]));
  if (!validGames.length) return "0.0";
  const sum = validGames.reduce((s, x) => s + Number(x[k]), 0);
  return (sum / validGames.length).toFixed(1);
}

function totalSum(g, k) {
  const validGames = g.filter(x => x[k] !== null && x[k] !== undefined && x[k] !== "Unknown" && x[k] !== "" && !isNaN(x[k]));
  return validGames.reduce((s, x) => s + Number(x[k]), 0);
}

function esc(s = "") {
  return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

const fmt = val => (val === null || val === undefined || val === "Unknown" || val === "" || isNaN(val)) 
  ? '<span class="dash">—</span>' 
  : val;

function hasValidData(array, key) {
  return array.some(x => x[key] !== null && x[key] !== undefined && x[key] !== "Unknown" && x[key] !== "" && !isNaN(x[key]));
}

// Converte un valore di un campo in numero, trattando i vuoti/"Unknown" come 0
function toNum(v) {
  return (v === null || v === undefined || v === "Unknown" || v === "" || isNaN(v)) ? 0 : +v;
}

function isValidField(v) {
  return v !== null && v !== undefined && v !== "Unknown" && v !== "" && !isNaN(v);
}

// Rimbalzi totali di una partita: preferisce RO+RD (nuovi campi avanzati),
// altrimenti ricade sul vecchio campo "reb" (compatibilita' con dati precedenti)
function computeRebRaw(x) {
  const oValid = isValidField(x.oreb);
  const dValid = isValidField(x.dreb);
  if (oValid || dValid) return (oValid ? Number(x.oreb) : 0) + (dValid ? Number(x.dreb) : 0);
  if (isValidField(x.reb)) return Number(x.reb);
  return null;
}

// Formatta una coppia realizzati/tentati (es. T2, T3, TL) come stringa "M/A"
function madeAtt(x, mKey, aKey) {
  const mValid = isValidField(x[mKey]);
  const aValid = isValidField(x[aKey]);
  if (!mValid && !aValid) return '<span class="dash">—</span>';
  return `${mValid ? Number(x[mKey]) : 0}/${aValid ? Number(x[aKey]) : 0}`;
}

// Media di una coppia realizzati/tentati su un insieme di partite, come "M.m/A.a"
function madeAttAvg(arr, mKey, aKey) {
  return `${mean(arr, mKey)}/${mean(arr, aKey)}`;
}

// Una partita ha almeno una statistica avanzata/di base valorizzata
function rowHasStats(x) {
  const keys = ["pts", "ast", "stl", "blk", "twoM", "twoA", "threeM", "threeA", "ftM", "ftA", "oreb", "dreb", "to"];
  return keys.some(k => isValidField(x[k])) || computeRebRaw(x) !== null;
}

// VAL (indice di valutazione) di una singola partita:
// (Punti + Rimbalzi + Assist + Palle Rec. + Stoppate) - (Tiri Falliti dal Campo + Liberi Falliti + Palle Perse)
function gameVal(x) {
  const pts = toNum(x.pts);
  const reb = computeRebRaw(x) || 0;
  const ast = toNum(x.ast);
  const stl = toNum(x.stl);
  const blk = toNum(x.blk);
  const twoA = toNum(x.twoA), twoM = toNum(x.twoM);
  const threeA = toNum(x.threeA), threeM = toNum(x.threeM);
  const ftA = toNum(x.ftA), ftM = toNum(x.ftM);
  const to = toNum(x.to);
  const missedFG = (twoA - twoM) + (threeA - threeM);
  const missedFT = (ftA - ftM);
  return pts + reb + ast + stl + blk - missedFG - missedFT - to;
}

function animateCounters() {
  const elements = document.querySelectorAll('.count-up');
  
  elements.forEach(el => {
    const target = parseFloat(el.getAttribute('data-target'));
    const isFloat = el.getAttribute('data-float') === 'true';
    const suffix = el.getAttribute('data-suffix') || '';
    
    if (isNaN(target)) {
      el.textContent = '0' + suffix;
      return;
    }

    let start = parseFloat(el.getAttribute('data-current')) || 0;
    
    if (start === target) {
      el.textContent = (isFloat ? target.toFixed(1) : Math.round(target)) + suffix;
      return;
    }

    const duration = 500;
    const startTime = performance.now();

    function updateNumber(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      const easeProgress = 1 - Math.pow(1 - progress, 3);
      const currentVal = start + (target - start) * easeProgress;

      el.textContent = (isFloat ? currentVal.toFixed(1) : Math.round(currentVal)) + suffix;

      if (progress < 1) {
        requestAnimationFrame(updateNumber);
      } else {
        el.setAttribute('data-current', target);
        el.textContent = (isFloat ? target.toFixed(1) : Math.round(target)) + suffix;
      }
    }

    requestAnimationFrame(updateNumber);
  });
}

// Adatta la larghezza del registro in base alle colonne effettivamente visibili:
// prova sempre a farlo stare nel contenitore, e forza lo scroll orizzontale
// solo quando le colonne selezionate in "Visualizza" superano lo spazio disponibile.
let lastTotalCols = 0;

function adjustTableScroll(totalCols) {
  const tableWrap = document.querySelector(".table-wrap");
  const tableEl = tableWrap ? tableWrap.querySelector("table") : null;
  if (!tableWrap || !tableEl) return;

  const isMobile = window.innerWidth <= 768;
  const comfortableCols = isMobile ? 5 : 9; // colonne che stanno comode senza scroll
  const extraCols = totalCols - comfortableCols;

  if (extraCols > 0) {
    const perColPx = isMobile ? 68 : 90;
    const basePx = isMobile ? 460 : 820;
    tableEl.style.minWidth = (basePx + extraCols * perColPx) + "px";
    tableWrap.classList.add("has-horizontal-scroll");
  } else {
    tableEl.style.minWidth = "";
    tableWrap.classList.remove("has-horizontal-scroll");
  }
}

let scrollAdjustTimer = null;
window.addEventListener("resize", () => {
  clearTimeout(scrollAdjustTimer);
  scrollAdjustTimer = setTimeout(() => adjustTableScroll(lastTotalCols), 150);
});

function render() {
  const g = data.games;
  const f = $("seasonFilter").value;
  const query = $("searchGame").value.trim().toLowerCase();
  
  // Scheda Giocatore
  const fullName = `${data.profile.firstName || ''} ${data.profile.lastName || ''}`.trim();
  const noLocal = isEmptyProfile(data.profile) && !data.games.length;
  $("playerName").textContent = fullName || (noLocal && remoteState === "loading" ? "Caricamento…"
    : noLocal && remoteState === "missing" ? "Giocatore non trovato"
    : noLocal && remoteState === "error" ? "Impossibile caricare il giocatore (connessione o permessi del database)"
    : "Nuovo Giocatore");
  
  const roleStr = data.profile.role || "Ruolo";
  const heightStr = data.profile.height ? `${data.profile.height} cm` : "- cm";
  const weightStr = data.profile.weight ? `${data.profile.weight} kg` : "- kg";
  const age = calculateAge(data.profile.birthDate);
  const ageStr = age !== null ? `${age} anni` : "- anni";
  $("playerMeta").textContent = `${ageStr} · ${heightStr} · ${weightStr} · ${roleStr}`;
  
  $("playerJersey").textContent = data.profile.number || "-";
  
  if ($("playerPhoto")) {
    $("playerPhoto").src = (data.profile.photo && data.profile.photo.trim() !== "") 
      ? data.profile.photo 
      : DEFAULT_USER_AVATAR;
  }

  // Filtro Stagioni
  const seasons = [...new Set(g.map(x => x.season).filter(Boolean))].sort((a, b) => b.localeCompare(a, undefined, { numeric: true, sensitivity: 'base' }));
  const old = f;
  $("seasonFilter").innerHTML = '<option value="all">Tutte le stagioni</option>' + seasons.map(s => `<option value="${esc(s)}">${esc(s)}</option>`).join("");
  $("seasonFilter").value = seasons.includes(old) || old === "all" ? old : "all";

  // Priorita' di visualizzazione per Annata: Senior sempre piu' in alto, Under piu' in basso
  // (le partite senza annata impostata mantengono priorita' neutra, come prima di questa modifica)
  const agePriority = v => (String(v || "").trim().toLowerCase() === "under" ? 1 : 0);

  // Priorita' per tipo partita (dall'alto): Finale, Semifinale, Quarti, Ottavi, PlayOff/PlayIn/PlayOut,
  // poi RS, per ultima l'Amichevole. Le partite senza tipo stanno tra RS e Amichevole.
  const typePriority = v => {
    const t = String(v || "");
    if (t.startsWith("Finale")) return 0;
    if (t.startsWith("Semifinale")) return 1;
    if (t.startsWith("Quarti")) return 2;
    if (t.startsWith("Ottavi")) return 3;
    if (t === "PlayOff" || t === "PlayIn" || t === "PlayOut") return 4;
    if (t.startsWith("RS")) return 5;
    if (t.startsWith("Amichevole")) return 7;
    return 6;
  };

  const sortedGames = [...g].sort((a, b) => {
    const sA = String(a.season || "");
    const sB = String(b.season || "");
    if (sA !== sB) {
      return sB.localeCompare(sA, undefined, { numeric: true, sensitivity: 'base' });
    }
    const prA = agePriority(a.ageGroup);
    const prB = agePriority(b.ageGroup);
    if (prA !== prB) return prA - prB;
    // Squadre e categorie diverse (anche con la stessa squadra) restano in blocchi separati
    const tmA = String(a.team || "").trim(), tmB = String(b.team || "").trim();
    if (tmA !== tmB) return tmA.localeCompare(tmB, undefined, { numeric: true, sensitivity: 'base' });
    const ctA = String(a.category || "").trim(), ctB = String(b.category || "").trim();
    if (ctA !== ctB) return ctA.localeCompare(ctB, undefined, { numeric: true, sensitivity: 'base' });
    const tpA = typePriority(a.gameType);
    const tpB = typePriority(b.gameType);
    if (tpA !== tpB) return tpA - tpB;
    const numA = Number(a.gameNumber) || 0;
    const numB = Number(b.gameNumber) || 0;
    return numB - numA;
  });

  const currentFilter = $("seasonFilter").value;
  let visible = currentFilter === "all" ? sortedGames : sortedGames.filter(x => x.season === currentFilter);

  if (query) {
    visible = visible.filter(x => {
      return (x.opponent && x.opponent.toLowerCase().includes(query)) ||
             (x.gameNumber && String(x.gameNumber).toLowerCase().includes(query)) ||
             (x.giornata && String(x.giornata).toLowerCase().includes(query)) ||
             (x.date && x.date.toLowerCase().includes(query)) ||
             (x.gameType && x.gameType.toLowerCase().includes(query)) ||
             (x.result && x.result.toLowerCase().includes(query)) ||
             (x.score && x.score.toLowerCase().includes(query)) ||
             (x.season && x.season.toLowerCase().includes(query)) ||
             (x.category && x.category.toLowerCase().includes(query)) ||
             (x.ageGroup && x.ageGroup.toLowerCase().includes(query)) ||
             (x.team && x.team.toLowerCase().includes(query));
    });
  }

  // Le stagioni deselezionate nel menu "Statistiche" vengono escluse solo dal totale con "Tutte le stagioni";
  // se si sceglie una stagione specifica, le sue statistiche si vedono comunque.
  const statsVisible = visible.filter(x =>
    x.gameType !== "Amichevole (Pre season)" &&
    (currentFilter !== "all" || !data.excludedSeasons.includes(x.season))
  );

  // Menu a tendina: elenco stagioni con spunta per includerle/escluderle dalle statistiche generali
  const seasonStatsList = $("seasonStatsList");
  if (seasonStatsList) {
    seasonStatsList.innerHTML = seasons.length
      ? seasons.map(s => `
          <label class="col-menu-item">
            <input type="checkbox" ${window.viewOnly ? "disabled" : ""} onchange="toggleSeasonStats('${esc(s).replace(/'/g, "&#39;")}', this.checked)" ${!data.excludedSeasons.includes(s) ? "checked" : ""}>
            ${esc(s)}
          </label>
        `).join("")
      : `<div class="season-stats-empty">Nessuna stagione disponibile</div>`;
  }

  const ptsLabel = currentFilter === "all" ? "PTS TOT" : "PTS STAG";
  const totalPoints = totalSum(statsVisible, "pts");
  const statsVisibleReb = statsVisible.map(x => ({ ...x, reb: computeRebRaw(x) }));

  // BEST: punteggio piu' alto in una singola partita, tra quelle delle stagioni selezionate
  const bestPtsVals = statsVisible.filter(x => isValidField(x.pts)).map(x => toNum(x.pts));
  const bestPts = bestPtsVals.length ? Math.max(...bestPtsVals) : 0;

  const mainAvgHtml = [
    ["BEST", bestPts, false],
    [ptsLabel, totalPoints, false],
    ["PPG", mean(statsVisible, "pts"), true], 
    ["RPG", mean(statsVisibleReb, "reb"), true], 
    ["APG", mean(statsVisible, "ast"), true]
  ].map(([l, v, isFloat]) => `
    <div class="avg">
      <strong class="count-up" data-target="${v}" data-float="${isFloat}">0</strong>
      <span>${l}</span>
    </div>
  `).join("");

  let averagesHtml = `<div class="avg-line avg-line-main">${mainAvgHtml}</div>`;

  // Campi avanzati nella scheda giocatore, sotto la riga principale: tiri totali, tiri da 2,
  // tiri da 3 (medie a partita, non totali cumulativi) e VAL medio
  if (columnPrefs.advanced) {
    const statsVisibleTotShots = statsVisible.map(x => {
      const hasShotData = isValidField(x.twoM) || isValidField(x.twoA) || isValidField(x.threeM) || isValidField(x.threeA);
      return {
        ...x,
        totM: hasShotData ? (toNum(x.twoM) + toNum(x.threeM)) : null,
        totA: hasShotData ? (toNum(x.twoA) + toNum(x.threeA)) : null
      };
    });
    const avgValStr = statsVisible.length ? (statsVisible.reduce((s, x) => s + gameVal(x), 0) / statsVisible.length).toFixed(1) : "0.0";

    const advAvgHtml = [
      ["TIRI TOT", `${mean(statsVisibleTotShots, "totM")}/${mean(statsVisibleTotShots, "totA")}`],
      ["TIRI 2P", madeAttAvg(statsVisible, "twoM", "twoA")],
      ["TIRI 3P", madeAttAvg(statsVisible, "threeM", "threeA")],
      ["TL", madeAttAvg(statsVisible, "ftM", "ftA")],
      ["VAL MEDIA", avgValStr]
    ].map(([l, v]) => `
      <div class="avg avg-adv">
        <strong>${v}</strong>
        <span>${l}</span>
      </div>
    `).join("");

    averagesHtml += `<div class="avg-line avg-line-adv">${advAvgHtml}</div>`;
  }

  $("averages").innerHTML = averagesHtml;

  // Colonne opzionali: visibili solo se attivate dal mini menu "Colonne"
  const adv = !!columnPrefs.advanced;
  const showTeam = !!columnPrefs.team;
  const showCategory = !!columnPrefs.category;
  const showAgeGroup = !!columnPrefs.ageGroup;
  const showType = !!columnPrefs.gameType;
  const showDate = !!columnPrefs.date;
  const showVenueBadge = !!columnPrefs.venue;
  const showMin = hasValidData(visible, "min");
  const showPts = hasValidData(visible, "pts");
  const showReb = hasValidData(visible.map(x => ({ ...x, reb: computeRebRaw(x) })), "reb");
  const showAst = hasValidData(visible, "ast");
  const showBlk = hasValidData(visible, "blk");

  // Colonne avanzate: visibili solo quando "Avanzate" e' attivo nel menu "Visualizza"
  const showT2 = adv && (hasValidData(visible, "twoM") || hasValidData(visible, "twoA"));
  const showT3 = adv && (hasValidData(visible, "threeM") || hasValidData(visible, "threeA"));
  const showTL = adv && (hasValidData(visible, "ftM") || hasValidData(visible, "ftA"));
  const showRO = adv && hasValidData(visible, "oreb");
  const showRD = adv && hasValidData(visible, "dreb");
  const showPR = adv && hasValidData(visible, "stl");
  const showPP = adv && hasValidData(visible, "to");
  const showValCol = adv && visible.some(rowHasStats);

  let totalCols = window.viewOnly ? 3 : 4; // N° Partita, Avversario, Esito, (+Azioni se non in sola lettura)
  if (showTeam) totalCols++;
  if (showCategory) totalCols++;
  if (showAgeGroup) totalCols++;
  if (showMin) totalCols++;
  if (showPts) totalCols++;
  if (showT2) totalCols++;
  if (showT3) totalCols++;
  if (showTL) totalCols++;
  if (showRO) totalCols++;
  if (showRD) totalCols++;
  if (showReb) totalCols++;
  if (showAst) totalCols++;
  if (showBlk) totalCols++;
  if (showPR) totalCols++;
  if (showPP) totalCols++;
  if (showValCol) totalCols++;
  if (showType) totalCols++;
  if (showDate) totalCols++;

  const thead = document.querySelector(".table-wrap thead tr");
  if (thead) {
    thead.innerHTML = `
      <th class="col-sticky col-num">N° Partita</th>
      <th class="col-sticky col-opp">Avversario</th>
      <th class="col-result">Esito</th>
      ${showMin ? "<th>Min</th>" : ""}
      ${showPts ? "<th class=\"col-pts\">Punti</th>" : ""}
      ${showT2 ? "<th class=\"col-adv\">T2</th>" : ""}
      ${showT3 ? "<th class=\"col-adv\">T3</th>" : ""}
      ${showTL ? "<th class=\"col-adv\">TL</th>" : ""}
      ${showRO ? "<th class=\"col-adv\">RO</th>" : ""}
      ${showRD ? "<th class=\"col-adv\">RD</th>" : ""}
      ${showReb ? "<th class=\"col-reb\">Rimb.</th>" : ""}
      ${showAst ? "<th class=\"col-ast\">Ass</th>" : ""}
      ${showBlk ? "<th>Stopp.</th>" : ""}
      ${showPR ? "<th class=\"col-adv\">PR</th>" : ""}
      ${showPP ? "<th class=\"col-adv\">PP</th>" : ""}
      ${showValCol ? "<th class=\"col-adv col-val\">Val</th>" : ""}
      ${showTeam ? "<th>Squadra</th>" : ""}
      ${showCategory ? "<th>Categoria</th>" : ""}
      ${showAgeGroup ? "<th>Annata</th>" : ""}
      ${showType ? "<th>Tipo</th>" : ""}
      ${showDate ? "<th class=\"col-date\">Calendario</th>" : ""}
      ${window.viewOnly ? "" : "<th>Azioni</th>"}
    `;
  }

  let lastGroupKey = null;
  $("games").innerHTML = visible.map(x => {
    const i = g.indexOf(x);

    // Separatore a ogni cambio di stagione / squadra / categoria (anche con la stessa squadra).
    // Con una stagione specifica selezionata il nome della stagione non viene ripetuto.
    const seasonPart = (x.season && String(x.season).trim() !== "") ? String(x.season).trim() : "Senza stagione";
    const teamPart = String(x.team || "").trim();
    const catPart = String(x.category || "").trim();
    const groupKey = `${seasonPart}||${teamPart}||${catPart}`;
    let dividerHtml = "";
    if (groupKey !== lastGroupKey) {
      const label = [currentFilter === "all" ? seasonPart : "", teamPart, catPart].filter(Boolean).join(" · ") || seasonPart;
      dividerHtml = `<tr class="season-divider-row"><td colspan="${totalCols}"><div class="season-divider"><span>${esc(label)}</span></div></td></tr>`;
      lastGroupKey = groupKey;
    }

    // N° PARTITA ORA IN GRASSETTO BOLD
    return dividerHtml + `<tr onclick="highlightRow(this)">
      <td class="col-sticky col-num"><b>${esc(x.gameNumber) || "—"}</b></td>
      <td class="col-sticky col-opp">
        <div class="opp-line"><span class="opp-name">${esc(x.opponent)}</span>${x.scout ? `<button type="button" class="scout-pill" title="Apri lo scout di questa partita" onclick="event.stopPropagation();openScoutView(${i})">Scout</button>` : ""}</div>
        ${(showVenueBadge && x.venue) ? `<span class="venue-pill ${x.venue === "Casa" ? "venue-home" : "venue-away"}">${esc(x.venue).toUpperCase()}</span>` : ""}
      </td>
      <td class="result">
        ${x.score ? `<span class="score-text">${esc(x.score)}</span>` : ""}
        ${x.result ? `<span class="result-badge ${x.result === "P" ? "loss" : ""}">${esc(x.result)}</span>` : (x.score ? "" : '<span class="dash">—</span>')}
      </td>
      ${showMin ? `<td>${fmt(x.min)}</td>` : ""}
      ${showPts ? `<td class="col-pts"><b>${fmt(x.pts)}</b></td>` : ""}
      ${showT2 ? `<td class="col-adv">${madeAtt(x, "twoM", "twoA")}</td>` : ""}
      ${showT3 ? `<td class="col-adv">${madeAtt(x, "threeM", "threeA")}</td>` : ""}
      ${showTL ? `<td class="col-adv">${madeAtt(x, "ftM", "ftA")}</td>` : ""}
      ${showRO ? `<td class="col-adv">${fmt(x.oreb)}</td>` : ""}
      ${showRD ? `<td class="col-adv">${fmt(x.dreb)}</td>` : ""}
      ${showReb ? `<td class="col-reb">${fmt(computeRebRaw(x))}</td>` : ""}
      ${showAst ? `<td class="col-ast">${fmt(x.ast)}</td>` : ""}
      ${showBlk ? `<td>${fmt(x.blk)}</td>` : ""}
      ${showPR ? `<td class="col-adv">${fmt(x.stl)}</td>` : ""}
      ${showPP ? `<td class="col-adv">${fmt(x.to)}</td>` : ""}
      ${showValCol ? `<td class="col-adv col-val">${rowHasStats(x) ? gameVal(x) : '<span class="dash">—</span>'}</td>` : ""}
      ${showTeam ? `<td>${x.team ? esc(x.team) : "—"}</td>` : ""}
      ${showCategory ? `<td>${x.category ? esc(x.category) : "—"}</td>` : ""}
      ${showAgeGroup ? `<td>${x.ageGroup ? esc(x.ageGroup) : "—"}</td>` : ""}
      ${showType ? `<td>${esc(x.gameType) || "—"}</td>` : ""}
      ${showDate ? `<td class="col-date"><span class="giornata-badge">${esc(calendarLabel(x))}</span>${x.date ? `<span class="giornata-date">${esc(x.date)}</span>` : ""}</td>` : ""}
      ${window.viewOnly ? "" : `<td><button onclick="editGame(${i})">Modifica</button> <button class="delete" onclick="removeGame(${i})">×</button></td>`}
    </tr>`;
  }).join("") || `<tr><td colspan="${totalCols}">${query ? 'Nessuna partita trovata per questa ricerca.' : 'Nessuna partita presente: clicca "+ Aggiungi partita" per iniziare.'}</td></tr>`;

  // Statistiche Generali
  const totalGames = statsVisible.length;
  const wins = statsVisible.filter(x => String(x.result).trim().toUpperCase() === "V").length;
  const losses = statsVisible.filter(x => String(x.result).trim().toUpperCase() === "P").length;
  const totalMin = statsVisible.reduce((s, x) => s + (isNaN(x.min) || x.min === "Unknown" || x.min === "" || x.min === null ? 0 : +x.min), 0);

  let generalStatsHtml = "";

  if (totalGames > 0) {
    generalStatsHtml += `
      <article class="stat-card acc-orange">
        <h3>Partite Totali Giocate</h3>
        <div class="stat-value count-up" data-target="${totalGames}">0</div>
        <small>Presenze in campo (Ufficiali)</small>
      </article>
    `;
  }

  if (wins > 0 || losses > 0) {
    generalStatsHtml += `
      <article class="stat-card acc-green">
        <h3>Partite Vinte</h3>
        <div class="stat-value win-val count-up" data-target="${wins}">0</div>
        <small>Vittorie ufficiali</small>
      </article>
      <article class="stat-card acc-red">
        <h3>Partite Perse</h3>
        <div class="stat-value loss-val count-up" data-target="${losses}">0</div>
        <small>Sconfitte ufficiali</small>
      </article>
    `;
  }

  if (hasValidData(statsVisible, "pts")) {
    const validPtsGames = statsVisible.filter(x => x.pts !== null && x.pts !== undefined && x.pts !== "Unknown" && x.pts !== "" && !isNaN(x.pts));
    const bestScore = validPtsGames.length ? Math.max(...validPtsGames.map(x => Number(x.pts))) : 0;
    generalStatsHtml += `
      <article class="stat-card acc-purple">
        <h3>Best Score</h3>
        <div class="stat-value count-up" data-target="${bestScore}">0</div>
        <small>Miglior punteggio in una partita</small>
      </article>
    `;
  }

  if (hasValidData(statsVisible, "min")) {
    generalStatsHtml += `
      <article class="stat-card acc-blue">
        <h3>Minuti Totali Giocati</h3>
        <div class="stat-value count-up" data-target="${totalMin}" data-suffix="'">0</div>
        <small>Minuti in gare ufficiali</small>
      </article>
    `;
  }

  if (generalStatsHtml) {
    $("secStats").style.display = "block";
    $("generalStats").innerHTML = generalStatsHtml;
  } else {
    $("secStats").style.display = "none";
  }

  // Percentuali tiro
  const shootingConfigs = [
    ["Tiri da 2", "twoM", "twoA", "court2pPct", "acc-green"],
    ["Tiri da 3", "threeM", "threeA", "court3pPct", "acc-blue"],
    ["Tiri liberi", "ftM", "ftA", "courtFtPct", "acc-orange"]
  ];

  // Percentuale totale dal campo (media combinata Tiri da 2 + Tiri da 3, senza liberi)
  const num = v => (isNaN(v) || v === "Unknown" || v === "" || v === null) ? 0 : +v;
  const fgMade = statsVisible.reduce((s, x) => s + num(x.twoM) + num(x.threeM), 0);
  const fgAtt = statsVisible.reduce((s, x) => s + num(x.twoA) + num(x.threeA), 0);
  const fgPct = fgAtt ? Math.round(fgMade / fgAtt * 100) : 0;
  if ($("courtTotPct")) $("courtTotPct").textContent = fgPct + "%";

  let shootingHtml = "";

  if (fgAtt > 0 || fgMade > 0) {
    shootingHtml += `
      <article class="shot shot-total">
        <h3>Tiri dal Campo</h3>
        <div class="percent count-up" data-target="${fgPct}" data-suffix="%">0%</div>
        <div class="track"><div class="fill" style="width:${Math.min(fgPct, 100)}%"></div></div>
        <small>Realizzati: ${fgMade} · Tentati: ${fgAtt}</small>
      </article>
    `;
  }

  shootingConfigs.forEach(([name, m, a, courtElemId, accentClass]) => {
    let made = statsVisible.reduce((s, x) => s + (isNaN(x[m]) || x[m] === "Unknown" || x[m] === "" || x[m] === null ? 0 : +x[m]), 0);
    let att = statsVisible.reduce((s, x) => s + (isNaN(x[a]) || x[a] === "Unknown" || x[a] === "" || x[a] === null ? 0 : +x[a]), 0);
    
    let p = att ? Math.round(made / att * 100) : 0;
    if ($(courtElemId))$(courtElemId).textContent = p + "%";

    if (att > 0 || made > 0) {
      shootingHtml += `
        <article class="shot ${accentClass}">
          <h3>${name}</h3>
          <div class="percent count-up" data-target="${p}" data-suffix="%">0%</div>
          <div class="track"><div class="fill" style="width:${Math.min(p, 100)}%"></div></div>
          <small>Realizzati: ${made} · Tentati: ${att}</small>
        </article>
      `;
    }
  });

  if (shootingHtml) {
    $("secShooting").style.display = "block";
    $("shooting").innerHTML = shootingHtml;
  } else {
    const courtCard = $("shootingCourtCard");
    if (!courtCard || courtCard.classList.contains("hidden")) {
      $("secShooting").style.display = "none";
    }
  }

  lastTotalCols = totalCols;
  adjustTableScroll(totalCols);

  renderSeasonSummary();

  animateCounters();
}

// Tabella riepilogativa "Statistiche per Stagione": raggruppa per stagione + squadra + competizione
// e calcola le medie a partita (VAL calcolato automaticamente)
function renderSeasonSummary() {
  const wrap = $("secSeasonStats");
  const tbody = $("seasonSummary");
  if (!wrap || !tbody) return;

  // Visibile solo quando il filtro e' su "Tutte le stagioni": con una stagione specifica
  // selezionata, il riepilogo per stagione non ha senso e viene nascosto.
  const currentFilter = $("seasonFilter") ? $("seasonFilter").value : "all";
  if (currentFilter !== "all") {
    wrap.style.display = "none";
    return;
  }

  const eligible = data.games.filter(x => x.gameType !== "Amichevole (Pre season)");

  if (!eligible.length) {
    wrap.style.display = "none";
    return;
  }

  const groups = {};
  eligible.forEach(x => {
    const season = (x.season && String(x.season).trim()) || "Senza stagione";
    const team = (x.team && String(x.team).trim()) || "—";
    const comp = (x.category && String(x.category).trim()) || "—";
    const key = `${season}||${team}||${comp}`;
    if (!groups[key]) groups[key] = { season, team, comp, games: [] };
    groups[key].games.push(x);
  });

  const rows = Object.values(groups).sort((a, b) => {
    if (a.season !== b.season) {
      return b.season.localeCompare(a.season, undefined, { numeric: true, sensitivity: 'base' });
    }
    return b.games.length - a.games.length;
  });

  const adv = !!columnPrefs.advanced;

  // Intestazione tabella (desktop): le colonne avanzate compaiono solo con "Avanzate" attivo
  const theadRow = document.querySelector(".season-summary-table thead tr");
  if (theadRow) {
    theadRow.innerHTML = `
      <th>Stagione</th>
      <th>Squadra</th>
      <th>Competizione</th>
      <th>Gare</th>
      <th>Pt</th>
      <th>Pt Tot</th>
      <th>Best</th>
      <th>Rimb</th>
      <th>Ass</th>
      ${adv ? "<th>Tiri Tot</th><th>T2</th><th>T3</th><th>TL</th><th>Val</th>" : ""}
    `;
  }

  const summaries = rows.map(r => {
    const gArr = r.games;
    const rebArr = gArr.map(x => ({ ...x, reb: computeRebRaw(x) }));
    const totArr = gArr.map(x => {
      const hasShotData = isValidField(x.twoM) || isValidField(x.twoA) || isValidField(x.threeM) || isValidField(x.threeA);
      return {
        totM: hasShotData ? (toNum(x.twoM) + toNum(x.threeM)) : null,
        totA: hasShotData ? (toNum(x.twoA) + toNum(x.threeA)) : null
      };
    });
    const ptsVals = gArr.filter(x => isValidField(x.pts)).map(x => toNum(x.pts));
    return {
      season: r.season, team: r.team, comp: r.comp, games: gArr.length,
      pts: mean(gArr, "pts"),
      ptsTot: totalSum(gArr, "pts"),
      best: ptsVals.length ? Math.max(...ptsVals) : "-",
      reb: mean(rebArr, "reb"),
      ast: mean(gArr, "ast"),
      tot: `${mean(totArr, "totM")}/${mean(totArr, "totA")}`,
      t2: madeAttAvg(gArr, "twoM", "twoA"),
      t3: madeAttAvg(gArr, "threeM", "threeA"),
      tl: madeAttAvg(gArr, "ftM", "ftA"),
      val: gArr.length ? (gArr.reduce((s, x) => s + gameVal(x), 0) / gArr.length).toFixed(1) : "0.0"
    };
  });

  tbody.innerHTML = summaries.map(r => `<tr>
      <td><b>${esc(r.season)}</b></td>
      <td>${esc(r.team)}</td>
      <td>${esc(r.comp)}</td>
      <td>${r.games}</td>
      <td><b>${r.pts}</b></td>
      <td><b>${r.ptsTot}</b></td>
      <td>${r.best}</td>
      <td>${r.reb}</td>
      <td>${r.ast}</td>
      ${adv ? `<td>${r.tot}</td><td>${r.t2}</td><td>${r.t3}</td><td>${r.tl}</td><td class="col-val">${r.val}</td>` : ""}
    </tr>`).join("");

  // Schede per stagione (mobile)
  const cardsEl = $("seasonCards");
  if (cardsEl) {
    cardsEl.innerHTML = summaries.map(r => `
      <div class="season-card">
        <div class="season-card-head"><b>${esc(r.season)}</b> · ${esc(r.team)} · ${esc(r.comp)}</div>
        <div class="season-card-row season-card-main">
          <div class="sc-stat sc-accent"><strong>${r.pts}</strong><span>PT</span></div>
          <div class="sc-stat"><strong>${r.ptsTot}</strong><span>PT TOT</span></div>
          <div class="sc-stat"><strong>${r.reb}</strong><span>RIMB</span></div>
          <div class="sc-stat"><strong>${r.ast}</strong><span>ASS</span></div>
          <div class="sc-stat"><strong>${r.games}</strong><span>GARE</span></div>
          <div class="sc-stat"><strong>${r.best}</strong><span>BEST</span></div>
        </div>
        ${adv ? `
        <div class="season-card-row season-card-adv">
          <div class="sc-stat"><strong>${r.tot}</strong><span>TIRI TOT</span></div>
          <div class="sc-stat"><strong>${r.t2}</strong><span>TIRI 2P</span></div>
          <div class="sc-stat"><strong>${r.t3}</strong><span>TIRI 3P</span></div>
          <div class="sc-stat"><strong>${r.tl}</strong><span>TL</span></div>
          <div class="sc-stat"><strong>${r.val}</strong><span>VAL</span></div>
        </div>` : ""}
      </div>
    `).join("");
  }

  wrap.style.display = "block";
}

// Etichetta della colonna calendario: nei PlayOff il numero vale come "Gara"; per Ottavi, Quarti,
// Semifinale e Finale al posto della giornata si mostra la fase; altrimenti "N° Giornata".
function phaseLabel(gameType) {
  const t = String(gameType || "");
  if (t.startsWith("Finale")) return "Finale";
  if (t.startsWith("Semifinale")) return "Semifinale";
  if (t.startsWith("Quarti")) return "Quarti";
  if (t.startsWith("Ottavi")) return "Ottavi";
  return "";
}
function calendarLabel(x) {
  const phase = phaseLabel(x.gameType);
  if (phase) return phase;
  if (x.gameType === "PlayOff") return x.giornata ? `${x.giornata}° Gara` : "—";
  return x.giornata ? `${x.giornata}° Giornata` : "—";
}

function highlightRow(row) {
  document.querySelectorAll("#games tr").forEach(r => r.classList.remove("active-row"));
  row.classList.add("active-row");
}

const gameTypeOptions = [
  "Amichevole (Pre season)",
  "RS (Regular Season)",
  "PlayIn",
  "PlayOut",
  "PlayOff",
  "Ottavi di finale (Round of 16)",
  "Quarti di finale (Quarterfinals)",
  "Semifinale (Semifinal)",
  "Finale (Final)"
];

// Campi divisi in gruppi: informazioni generali (anagrafica partita) e statistiche
// Campi divisi in gruppi: informazioni generali (anagrafica partita) e statistiche
const gameFieldGroups = [
  {
    title: "Informazioni Generali",
    fields: {
      category: "Categoria / Competizione",
      ageGroup: "Annata (Senior / Under)",
      team: "Squadra",
      season: "Stagione",
      result: "Esito (V/P)",
      score: "Risultato (es. 80-52)",
      opponent: "Avversario",
      gameNumber: "Numero Partita",
      venue: "Casa / Trasferta",
      gameType: "Tipo Partita",
      giornata: "Giornata",
      date: "Data partita"
    }
  },
  {
    title: "Statistiche",
    fields: {
      min: "Minuti",
      pts: "Punti",
      ast: "Assist",
      blk: "Stoppate",
      twoM: "Tiri da 2 realizzati",
      twoA: "Tiri da 2 tentati",
      threeM: "Tiri da 3 realizzati",
      threeA: "Tiri da 3 tentati",
      ftM: "Tiri liberi realizzati (TL)",
      ftA: "Tiri liberi tentati (TL)",
      oreb: "Rimbalzi Offensivi (RO)",
      dreb: "Rimbalzi Difensivi (RD)",
      stl: "Palle recuperate (PR)",
      to: "Palle perse (PP)"
    }
  }
];
// Elenco piatto di tutti i campi (usato per il salvataggio/validazione)
const gameFields = gameFieldGroups.reduce((acc, grp) => ({ ...acc, ...grp.fields }), {});

function fieldInputHtml(k, label, obj) {
  const val = (obj[k] === "Unknown" || obj[k] === null || obj[k] === undefined) ? "" : obj[k];

  if (k === "gameType") {
    const opts = gameTypeOptions.map(opt => `<option value="${esc(opt)}" ${val === opt ? "selected" : ""}>${esc(opt)}</option>`).join("");
    return `<label class="field"><span class="field-label">${label}</span>
      <select name="${k}">
        <option value="">-- Seleziona tipo --</option>
        ${opts}
      </select>
    </label>`;
  }

  if (k === "result") {
    const resultOptions = [
      { value: "V", label: "V - Vittoria" },
      { value: "P", label: "P - Persa" }
    ];
    const opts = resultOptions.map(opt => `<option value="${esc(opt.value)}" ${val === opt.value ? "selected" : ""}>${esc(opt.label)}</option>`).join("");
    return `<label class="field"><span class="field-label">${label}</span>
      <select name="${k}">
        <option value="">-- Seleziona --</option>
        ${opts}
      </select>
    </label>`;
  }

  if (k === "ageGroup") {
    const ageGroupOptions = ["Senior", "Under"];
    const opts = ageGroupOptions.map(opt => `<option value="${esc(opt)}" ${val === opt ? "selected" : ""}>${esc(opt)}</option>`).join("");
    return `<label class="field"><span class="field-label">${label}</span>
      <select name="${k}">
        <option value="">-- Seleziona --</option>
        ${opts}
      </select>
    </label>`;
  }

  if (k === "venue") {
    const venueOptions = ["Casa", "Trasferta"];
    const opts = venueOptions.map(opt => `<option value="${esc(opt)}" ${val === opt ? "selected" : ""}>${esc(opt)}</option>`).join("");
    return `<label class="field"><span class="field-label">${label}</span>
      <select name="${k}">
        <option value="">-- Seleziona --</option>
        ${opts}
      </select>
    </label>`;
  }

  return `<label class="field"><span class="field-label">${label}</span><input name="${k}" value="${esc(val)}" placeholder=""></label>`;
}

function fields(target, obj, groups) {
  target.innerHTML = groups.map(group => `
    <div class="form-section">
      <div class="form-section-title">${esc(group.title)}</div>
      <div class="formgrid">
        ${Object.entries(group.fields).map(([k, label]) => fieldInputHtml(k, label, obj)).join("")}
      </div>
    </div>
  `).join("");
}

// Campi che vengono bloccati quando si sceglie di aggiungere più partite in blocco
const batchLockedFields = ["min", "gameNumber", "giornata", "date", "pts", "ast", "stl", "blk", "twoM", "twoA", "threeM", "threeA", "ftM", "ftA", "oreb", "dreb", "to", "score"];

function updateBatchLock() {
  const batchInput = $("batchCount");
  const isLocking = editing < 0 && !!batchInput && batchInput.value.trim() !== "" && Number(batchInput.value) > 1;

  batchLockedFields.forEach(key => {
    const input = document.querySelector(`#gameFields [name="${key}"]`);
    if (!input) return;
    input.disabled = isLocking;
    const label = input.closest(".field");
    if (label) label.classList.toggle("field-locked", isLocking);
  });
}

if ($("batchCount")) {
  $("batchCount").addEventListener("input", updateBatchLock);
}

// Nei PlayOff il campo "Giornata" vale come "Gara": l'etichetta cambia in base al tipo partita
function syncGiornataLabel() {
  const wrap = $("gameFields");
  const sel = wrap.querySelector('select[name="gameType"]');
  const inp = wrap.querySelector('input[name="giornata"]');
  if (!sel || !inp) return;
  const span = inp.parentElement.querySelector(".field-label");
  if (span) span.textContent = sel.value === "PlayOff" ? "Gara" : "Giornata";
}

function editGame(i) {
  if (window.viewOnly) return;
  editing = i;
  $("dialogTitle").textContent = i < 0 ? "Aggiungi partita" : "Modifica partita";
  fields($("gameFields"), i < 0 ? {} : data.games[i], gameFieldGroups);
  const typeSel = $("gameFields").querySelector('select[name="gameType"]');
  if (typeSel) typeSel.addEventListener("change", syncGiornataLabel);
  syncGiornataLabel();

  const batchWrap = $("batchAddWrap");
  const batchInput = $("batchCount");
  if (batchWrap) {
    if (i < 0) {
      batchWrap.classList.remove("hidden");
      if (batchInput) batchInput.value = "";
    } else {
      batchWrap.classList.add("hidden");
    }
  }
  updateBatchLock();

  toggleBodyScroll(true);
  $("gameDialog").showModal();
}

if ($("themeToggle")) $("themeToggle").onclick = toggleTheme;

if ($("courtToggle")) {
  $("courtToggle").onclick = () => {
    const courtCard = $("shootingCourtCard");
    const secShooting = $("secShooting");

    if (courtCard) {
      if (secShooting) secShooting.style.display = "block";

      if (courtCard.classList.contains("hidden")) {
        courtCard.classList.remove("hidden");
        requestAnimationFrame(() => {
          courtCard.classList.remove("court-fade-out");
          courtCard.classList.add("court-fade-in");
        });

        courtCard.scrollIntoView({ behavior: "smooth", block: "nearest" });
      } else {
        courtCard.classList.remove("court-fade-in");
        courtCard.classList.add("court-fade-out");
        
        setTimeout(() => {
          courtCard.classList.add("hidden");
        }, 400);
      }
    }
  };
}

$("addGame").onclick = () => editGame(-1);
$("seasonFilter").onchange = render;
$("searchGame").oninput = render;

function toggleSeasonStats(season, checked) {
  if (window.viewOnly) return;
  const idx = data.excludedSeasons.indexOf(season);
  if (checked) {
    if (idx >= 0) data.excludedSeasons.splice(idx, 1);
  } else {
    if (idx < 0) data.excludedSeasons.push(season);
  }
  save();
  render();
}

$("gameForm").onsubmit = async e => {
  if (e.submitter.value === "cancel") return;
  e.preventDefault();
  let obj = Object.fromEntries(new FormData(e.target));
  
  for (let k of Object.keys(obj)) {
    if (!["date", "opponent", "result", "score", "season", "gameNumber", "giornata", "gameType", "category", "team", "venue", "ageGroup"].includes(k)) {
      const val = obj[k].trim();
      if (val === "" || val.toLowerCase() === "unknown") {
        obj[k] = "Unknown";
      } else {
        obj[k] = !isNaN(val) ? +val : "Unknown";
      }
    }
  }

  if (obj.gameType === "Amichevole (Pre season)") {
    await showCustomConfirm(
      "Partita Amichevole", 
      "Attenzione: Le partite amichevoli (Pre season) verranno mostrate nella lista ma NON incideranno sulle statistiche generali né su quelle di stagione.", 
      false, 
      true
    );
  }

  const batchInput = $("batchCount");
  const batchCount = (editing < 0 && batchInput) ? parseInt(batchInput.value, 10) : 0;

  if (editing < 0 && batchCount > 0) {
    for (let n = 0; n < batchCount; n++) {
      data.games.unshift({ ...obj });
    }
  } else if (editing < 0) {
    data.games.unshift(obj);
  } else {
    // Merge (non sovrascrive del tutto) per preservare eventuali campi legacy non piu' presenti nel form (es. vecchio "reb")
    data.games[editing] = { ...data.games[editing], ...obj };
  }

  save();
  $("gameDialog").close();
  render();
};

// Due partite appartengono alla stessa "serie di numerazione" se hanno stessa stagione,
// squadra, categoria, annata e tipo partita.
function sameGameGroup(a, b) {
  const norm = v => String(v || "").trim().toLowerCase();
  return ["season", "team", "category", "ageGroup", "gameType"].every(k => norm(a[k]) === norm(b[k]));
}

async function removeGame(i) {
  if (window.viewOnly) return;
  const confirmed = await showCustomConfirm(
    "Elimina partita", 
    "Sei sicuro di voler eliminare questa partita dalla lista? I numeri delle partite successive verranno aggiornati automaticamente.", 
    true
  );
  if (confirmed) {
    const [removed] = data.games.splice(i, 1);
    const removedRaw = String(removed && removed.gameNumber !== undefined && removed.gameNumber !== null ? removed.gameNumber : "").trim();
    if (/^\d+$/.test(removedRaw)) {
      const removedNum = parseInt(removedRaw, 10);
      data.games.forEach(x => {
        const raw = String(x.gameNumber !== undefined && x.gameNumber !== null ? x.gameNumber : "").trim();
        if (!/^\d+$/.test(raw)) return;
        const n = parseInt(raw, 10);
        if (n > removedNum && sameGameGroup(x, removed)) {
          x.gameNumber = typeof x.gameNumber === "number" ? n - 1 : String(n - 1);
        }
      });
    }
    save();
    render();
  }
}

// Modale Profilo
function updatePhotoPreview() {
  const photo = pendingPhotoBase64 !== null ? pendingPhotoBase64 : (data.profile.photo || "");
  $("profPhotoPreview").src = photo || DEFAULT_USER_AVATAR;
  $("photoRemoveBtn").classList.toggle("hidden", !photo);
}

function setPhotoStatus(msg, isError = false) {
  const el = $("photoStatus");
  el.textContent = msg || "";
  el.style.color = isError ? "var(--delete-text)" : "";
}

let photoBusy = null; // promessa dell'elaborazione foto in corso (il salvataggio la attende)

$("editProfile").onclick = () => {
  if (window.viewOnly) return;
  pendingPhotoBase64 = null; // null = foto invariata, "" = foto rimossa, testo = nuova foto
  $("profFirstName").value = data.profile.firstName || "";
  $("profLastName").value = data.profile.lastName || "";
  $("profNumber").value = data.profile.number || "";
  $("profRole").value = data.profile.role || "";
  $("profHeight").value = data.profile.height || "";
  $("profWeight").value = data.profile.weight || "";
  $("profBirthDate").value = data.profile.birthDate || "";
  $("photoInput").value = "";
  setPhotoStatus("");
  updatePhotoPreview();

  // Profili senza password: si puo' impostarla da qui
  $("profNewPass").value = "";
  $("profNewPass2").value = "";
  $("profPassError").classList.add("hidden");
  $("profPasswordBox").classList.toggle("hidden", !!currentPassHash);

  toggleBodyScroll(true);
  $("profileDialog").showModal();
};

$("photoChooseBtn").onclick = () => $("photoInput").click();

$("photoRemoveBtn").onclick = () => {
  pendingPhotoBase64 = "";
  setPhotoStatus("La foto verrà rimossa quando salvi.");
  updatePhotoPreview();
};

// La foto viene ridimensionata e compressa (max 360 px, JPEG) prima di essere usata:
// le foto originali da telefono erano troppo pesanti e bloccavano il salvataggio.
$("photoInput").onchange = e => {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;
  setPhotoStatus("Preparo la foto…");
  $("profSaveBtn").disabled = true;
  photoBusy = PhotoUtils.compressImageFile(file)
    .then(url => {
      pendingPhotoBase64 = url;
      setPhotoStatus("Foto pronta: premi Salva per applicarla.");
      updatePhotoPreview();
    })
    .catch(err => {
      console.warn("Foto non leggibile", err);
      setPhotoStatus("Non riesco a leggere questa immagine. Prova con un file JPG o PNG.", true);
    })
    .finally(() => { $("profSaveBtn").disabled = false; });
};

$("profileForm").onsubmit = async e => {
  if (e.submitter && e.submitter.value === "cancel") return;
  e.preventDefault();

  if (photoBusy) await photoBusy;

  // Password (solo per i profili che non ne hanno una): facoltativa
  let newHash = "";
  if (!currentPassHash) {
    const p1 = $("profNewPass").value;
    const p2 = $("profNewPass2").value;
    if (p1 || p2) {
      const err = $("profPassError");
      if (p1.length < 4) {
        err.textContent = "La password deve avere almeno 4 caratteri.";
        err.classList.remove("hidden");
        return;
      }
      if (p1 !== p2) {
        err.textContent = "Le due password non coincidono.";
        err.classList.remove("hidden");
        return;
      }
      newHash = await sha256Hex(p1);
    }
  }

  let o = Object.fromEntries(new FormData(e.target));
  o.photo = pendingPhotoBase64 !== null ? pendingPhotoBase64 : (data.profile.photo || "");

  if (newHash) {
    currentPassHash = newHash;
    currentNoPassword = false;
  }

  data.profile = o;
  save();
  $("profileDialog").close();
  render();

  if (newHash) {
    await showCustomConfirm("Password impostata", "Da ora servirà questa password per modificare o eliminare il giocatore.", false, true);
  }
};

// Reset: elimina questo giocatore (dati + voce nel registro) e torna alla home
$("deleteAllData").onclick = async () => {
  if (window.viewOnly) return;
  const confirmed = await showCustomConfirm(
    "Elimina giocatore", 
    "Sei sicuro di voler eliminare definitivamente questo giocatore e TUTTI i suoi dati e statistiche? L'azione non è reversibile.", 
    true
  );
  if (confirmed) {
    localStorage.removeItem(STORAGE_KEY);
    setPending("stats", PLAYER_ID, false);
    setPending("players", PLAYER_ID, false);
    const reg = loadRegistry().filter(p => p.id !== PLAYER_ID);
    localStorage.setItem(REGISTRY_KEY, JSON.stringify(reg));
    if (window.cloudDB) {
      window.cloudDB.collection("players").doc(PLAYER_ID).delete().catch(() => {});
      window.cloudDB.collection("playerStats").doc(PLAYER_ID).delete().catch(() => {});
    }
    location.href = "index.html";
  }
};

// Import/Export
$("exportData").onclick = () => {
  if (window.viewOnly) return;
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  const filename = `${data.profile.firstName || 'giocatore'}_${data.profile.lastName || 'stats'}.json`.toLowerCase().replace(/\s+/g, '_');
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
};

$("importBtn").onclick = () => {
  if (window.viewOnly) return;
  $("importInput").click();
};

$("importInput").onchange = e => {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = async event => {
    try {
      const importedData = JSON.parse(event.target.result);
      if (importedData && importedData.profile && Array.isArray(importedData.games)) {
        const profile = { ...defaults.profile, ...importedData.profile };
        const hadPhoto = !!profile.photo;
        // La foto nel file puo' essere enorme o non valida: la si ricomprime (o scarta) prima di salvare
        profile.photo = await PhotoUtils.normalizePhoto(profile.photo);
        data = {
          profile,
          games: importedData.games,
          excludedSeasons: Array.isArray(importedData.excludedSeasons) ? importedData.excludedSeasons : [],
        };
        save();
        render();

        $("profFirstName").value = data.profile.firstName || "";
        $("profLastName").value = data.profile.lastName || "";
        $("profNumber").value = data.profile.number || "";
        $("profRole").value = data.profile.role || "";
        $("profHeight").value = data.profile.height || "";
        $("profWeight").value = data.profile.weight || "";
        $("profBirthDate").value = data.profile.birthDate || "";
        pendingPhotoBase64 = null;

        $("profileDialog").close();
        await showCustomConfirm("Successo", (hadPhoto && !profile.photo)
          ? "Dati importati. La foto contenuta nel file non era valida e non è stata importata."
          : "Dati importati correttamente nella tua scheda!", false, true);
      } else {
        await showCustomConfirm("Errore", "Il file JSON inserito non ha una struttura valida.", true, true);
      }
    } catch (err) {
      await showCustomConfirm("Errore", "Impossibile leggere il file selezionato.", true, true);
    }
  };
  reader.readAsText(file);
  e.target.value = "";
};

applyViewOnly();
render();          // mostra subito i dati locali (istantaneo), in sola lettura finche' non verificato
shrinkLoadedPhoto();
statsReady = cloudRefreshStats().then(syncAvgPts); // poi aggiorna con i dati del database condiviso, se configurato
runAccessControl().then(() => { accessResolved = true; applyViewOnly(); });  // chiede la password (o la fa impostare la prima volta) prima di sbloccare la modifica
