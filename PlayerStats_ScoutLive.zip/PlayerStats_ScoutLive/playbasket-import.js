// playbasket-import.js — importa da un profilo playbasket.it le singole partite di tutte le stagioni
// e le aggiunge al Registro Partite (con i campi che il sito sa gestire: punti, tiri, rimbalzi, ecc.).
//
// Come funziona:
//  1) l'utente incolla il link di una pagina profilo/stagione di PlayBasket;
//  2) si scarica la pagina (funzione serverless /api/playbasket, oppure servizi pubblici di lettura pagine);
//  3) dalla pagina "storico" si trovano tutte le stagioni del giocatore e si scarica ciascuna (in parallelo);
//  4) da ogni stagione si leggono le partite ("Statistiche partite") e si mostra un'anteprima;
//  5) alla conferma le partite vengono aggiunte a data.games (quelle già importate vengono saltate).
//
// Import "veloce": NON si scaricano le pagine delle singole partite, quindi non si importano
// giornata e data. Si importano solo squadra, stagione, categoria, esito, punteggio e statistiche.
//
// Va caricato PRIMA di script.js: usa `data`, `save`, `render` solo a runtime.

(function () {
  const $ = id => document.getElementById(id);
  const FN_URL = "/api/playbasket";
  const BASE = "https://www.playbasket.it/campania/profile.php";
  let pending = null; // { games, url }

  const esc = (s = "") => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  // ---------- Rete ----------
  const PROXIES = [
    u => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
    u => `https://corsproxy.io/?${encodeURIComponent(u)}`
  ];

  async function timedFetch(url, ms = 12000) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), ms);
    try { return await fetch(url, { signal: ctrl.signal }); } finally { clearTimeout(t); }
  }

  const looksLikePlayBasket = t => typeof t === "string" && /profile\.php/i.test(t) && /<table/i.test(t);
  const htmlCache = new Map();

  // 1) funzione del sito (/api/playbasket)  2) servizi pubblici di lettura pagine
  async function fetchHtml(url, valid = looksLikePlayBasket) {
    if (htmlCache.has(url)) return htmlCache.get(url);
    let html = null;
    try {
      const res = await timedFetch(`${FN_URL}?url=${encodeURIComponent(url)}`);
      if (res.ok) {
        const t = await res.text();
        if (valid(t)) html = t;
      }
    } catch (e) { /* passa al metodo successivo */ }
    if (!html) {
      for (const mk of PROXIES) {
        try {
          const res = await timedFetch(mk(url));
          if (!res.ok) continue;
          const t = await res.text();
          if (valid(t)) { html = t; break; }
        } catch (e) { /* prova il servizio successivo */ }
      }
    }
    htmlCache.set(url, html);
    return html;
  }

  const parseHtml = html => new DOMParser().parseFromString(html, "text/html");
  const safeUrl = (u, base) => { try { return new URL(u, base || BASE); } catch (e) { return null; } };
  const isPbProfileUrl = u => !!u && u.protocol === "https:" && /(^|\.)playbasket\.it$/i.test(u.hostname) && /\/profile\.php$/i.test(u.pathname);

  // ---------- Lettura di una pagina "stagione" ----------
  const clean = s => String(s || "").replace(/\s+/g, " ").trim();
  const seasonFromParam = n => `${n - 1}/${String(n).slice(-2)}`; // season=2025 -> "2024/25"

  // numero oppure null se "-" / vuoto
  function nz(v) {
    const s = clean(v).replace("%", "").replace(",", ".");
    if (s === "" || s === "-" || s === "—") return null;
    const n = parseFloat(s);
    return Number.isFinite(n) ? n : null;
  }
  // "3/7" -> [3,7]; solo "3" (con eventuale %) -> [3, tentati ricavati dalla percentuale]
  function pair(text, pctText) {
    const s = clean(text);
    const m = s.match(/^(\d+)\s*\/\s*(\d+)$/);
    if (m) return [+m[1], +m[2]];
    const made = nz(s);
    if (made === null) return [null, null];
    const pct = nz(pctText);
    return [made, pct && pct > 0 ? Math.round(made * 100 / pct) : null];
  }
  function minutes(text) {
    const m = clean(text).match(/^(\d+):(\d{2})$/);
    return m ? Math.round(+m[1] + +m[2] / 60) : nz(text);
  }
  const U = v => (v === null || v === undefined ? "Unknown" : v); // "Unknown" = dato mancante, come nel resto del sito

  // Tabella partite: quella con le intestazioni PARTITA e PTS
  function findGamesTable(doc) {
    return [...doc.querySelectorAll("table")].find(t => {
      const head = t.querySelector("thead tr") || t.querySelector("tr");
      if (!head) return false;
      const keys = [...head.children].map(c => clean(c.textContent).toUpperCase());
      return keys.includes("PARTITA") && keys.includes("PTS");
    });
  }

  function parseSeasonPage(html, urlStr, catLabel) {
    const doc = parseHtml(html);
    const u = safeUrl(urlStr);
    const seasonParam = u ? Number(u.searchParams.get("season")) : 0;

    // Titolo: "Nome - Squadra [Categoria 2024/25] | ..."
    const tm = clean(doc.title).match(/^(.*?)\s+-\s+(.*?)\s+\[(.*?)\s+(\d{4})\/(\d{2})\]/);
    const season = tm ? `${tm[4]}/${tm[5]}` : (seasonParam ? seasonFromParam(seasonParam) : "");
    const team = tm ? tm[2].trim() : "";
    const catFull = tm ? tm[3].trim() : "";
    const category = catLabel || catFull;
    const ageGroup = /under|\bu\s?\d{2}\b/i.test(`${category} ${catFull}`) ? "Under" : "Senior";
    const extobj = (u && u.searchParams.get("extobj")) || category;

    const games = [];
    const table = findGamesTable(doc);
    if (table) {
      const headRow = table.querySelector("thead tr") || table.querySelector("tr");
      const heads = [...headRow.children];
      const idx = {};
      heads.forEach((h, i) => {
        const k = clean(h.textContent).toUpperCase();
        if (k && !(k in idx)) idx[k] = i; // le colonne senza titolo (icona, trend) vengono ignorate
      });
      let rows = [...table.querySelectorAll("tbody tr")];
      if (!rows.length) rows = [...table.querySelectorAll("tr")].filter(r => r !== headRow);

      rows.forEach(tr => {
        const cells = [...tr.children];
        if (cells.some(c => /^totale$/i.test(clean(c.textContent)))) return; // riga dei totali
        const a = tr.querySelector('a[href*="match.php"]');
        if (!a) return;

        // Le colonne si leggono per NOME dell'intestazione (non per posizione): niente traslazioni
        const off = cells.length - heads.length;
        const cell = k => {
          const i = idx[k];
          const c = i === undefined ? null : cells[i + off];
          return c ? clean(c.textContent) : "";
        };

        // "Avversario[L] 52-74"  (lettera = esito, punteggio nell'ordine casa-trasferta)
        const label = clean(a.textContent);
        let opponent = label, letter = "", s1 = null, s2 = null;
        let m = label.match(/^(.*?)\s*\[\s*([A-Za-z])\s*\]\s*(\d+)\s*[-–]\s*(\d+)$/);
        if (m) { opponent = m[1]; letter = m[2].toUpperCase(); s1 = +m[3]; s2 = +m[4]; }
        else if ((m = label.match(/^(.*?)\s+(\d+)\s*[-–]\s*(\d+)$/))) { opponent = m[1]; s1 = +m[2]; s2 = +m[3]; }

        let result = /^[VW]$/.test(letter) ? "V" : /^[PL]$/.test(letter) ? "P" : "";
        let score = "", venue = "";
        if (s1 !== null) {
          if (result === "V") { score = `${Math.max(s1, s2)}-${Math.min(s1, s2)}`; venue = s1 > s2 ? "Casa" : "Trasferta"; }
          else if (result === "P") { score = `${Math.min(s1, s2)}-${Math.max(s1, s2)}`; venue = s1 < s2 ? "Casa" : "Trasferta"; }
          else score = `${s1}-${s2}`;
        }

        const link = safeUrl(a.getAttribute("href"));
        const gtn = link ? link.searchParams.get("gtn") || "" : "";
        const gtt = link ? link.searchParams.get("gtt") || "" : "";
        const mn = link ? link.searchParams.get("mn") || "" : "";

        const [ftM, ftA] = pair(cell("TL"), cell("TL%"));
        const [twoM, twoA] = pair(cell("T2"), cell("T2%"));
        const [threeM, threeA] = pair(cell("T3"), cell("T3%"));

        games.push({
          _order: Number(gtn) || 0,
          _gtt: Number(gtt) || 0,
          _url: link ? link.toString() : "",
          season, team, category, ageGroup,
          gameType: "",
          giornata: "",
          gameNumber: "",
          opponent: clean(opponent),
          result, score, venue,
          date: "",
          min: U(minutes(cell("MIN"))),
          pts: U(nz(cell("PTS"))),
          ast: U(nz(cell("ASS"))),
          blk: U(nz(cell("ST"))),      // ST = stoppate
          twoM: U(twoM), twoA: U(twoA),
          threeM: U(threeM), threeA: U(threeA),
          ftM: U(ftM), ftA: U(ftA),
          oreb: U(nz(cell("RO"))),
          dreb: U(nz(cell("RD"))),
          stl: U(nz(cell("PR"))),      // PR = palle recuperate
          to: U(nz(cell("PP"))),       // PP = palle perse
          source: "playbasket",
          pbKey: `pb:${extobj}:${seasonParam || season}:${gtn}:${gtt}:${mn}`
        });
      });

      // Ordine: andata prima del ritorno, poi per turno (senza date reali non si può fare meglio)
      games.sort((x, y) => (x._gtt - y._gtt) || (x._order - y._order));
      games.forEach((g, i) => {
        g.gameNumber = String(i + 1);
        delete g._order; delete g._gtt; delete g._url;
      });
    }
    return { season, team, category, games };
  }

  // ---------- Ricerca delle altre stagioni del giocatore ----------
  function discoverSeasons(html, baseUrl, obj) {
    const doc = parseHtml(html);
    const out = [];
    doc.querySelectorAll('a[href*="profile.php"]').forEach(a => {
      const u = safeUrl(a.getAttribute("href"), baseUrl);
      if (!isPbProfileUrl(u) || u.searchParams.get("mod")) return; // mod=hs/ws sono pagine di elenco
      if (obj && u.searchParams.get("obj") !== obj) return;
      const season = u.searchParams.get("season"), extobj = u.searchParams.get("extobj");
      if (!season || !extobj) return;
      out.push({ key: `${season}|${extobj}`, url: u.toString(), label: clean(a.textContent) });
    });
    return out;
  }

  function withMod(base, mod) {
    const u = new URL(base.toString());
    u.searchParams.set("mod", mod);
    u.searchParams.set("action", "view");
    return u.toString();
  }

  async function loadSeasonsFromUrl(url) {
    const base = safeUrl(url);
    const obj = base.searchParams.get("obj");
    const firstHtml = await fetchHtml(base.toString());
    if (!firstHtml) return null;

    setStatus("Cerco le altre stagioni del giocatore…", false);
    const [hsHtml, wsHtml] = await Promise.all([fetchHtml(withMod(base, "hs")), fetchHtml(withMod(base, "ws"))]);
    const found = new Map();
    [hsHtml, wsHtml].forEach(h => h && discoverSeasons(h, base.toString(), obj).forEach(s => { if (!found.has(s.key)) found.set(s.key, s); }));

    const baseKey = `${base.searchParams.get("season")}|${base.searchParams.get("extobj")}`;
    if (!found.has(baseKey)) found.set(baseKey, { key: baseKey, url: base.toString(), label: "" });
    const list = [...found.values()].slice(0, 20);

    const seasons = [];
    let done = 0, cursor = 0;
    async function worker() {
      while (cursor < list.length) {
        const s = list[cursor++];
        const html = s.key === baseKey ? firstHtml : await fetchHtml(s.url);
        done++;
        setStatus(`Scarico le stagioni… ${done} di ${list.length}`, false);
        if (!html) continue;
        const parsed = parseSeasonPage(html, s.url, s.label);
        if (parsed.games.length) seasons.push(parsed);
      }
    }
    await Promise.all([worker(), worker(), worker(), worker()]);
    seasons.sort((a, b) => b.season.localeCompare(a.season, undefined, { numeric: true }));
    return seasons;
  }

  // ---------- Dialog ----------
  function setStatus(msg, isError = true) {
    const el = $("pbStatus");
    el.textContent = msg || "";
    el.classList.toggle("hidden", !msg);
    el.style.color = isError ? "" : "var(--muted)";
    el.classList.toggle("pb-ok", !isError);
  }

  function showPreview(seasons, url) {
    const games = seasons.flatMap(s => s.games);
    const known = new Set(data.games.map(g => g.pbKey).filter(Boolean));
    const fresh = games.filter(g => !known.has(g.pbKey));
    pending = { games: fresh, url };

    $("pbPreviewBody").innerHTML = seasons.map(s => {
      const pts = s.games.reduce((t, g) => t + (typeof g.pts === "number" ? g.pts : 0), 0);
      return `<tr><td><b>${esc(s.season)}</b></td><td>${esc(s.team || "—")}</td><td>${esc(s.category || "—")}</td>
        <td>${s.games.length}</td><td><b>${pts}</b></td></tr>`;
    }).join("");

    const skipped = games.length - fresh.length;
    const note = fresh.length
      ? `${fresh.length} ${fresh.length === 1 ? "partita verrà aggiunta" : "partite verranno aggiunte"} al Registro Partite${skipped ? ` (${skipped} già present${skipped === 1 ? "e" : "i"}, non duplicate)` : ""}. Giornata e data non vengono importate.`
      : "Tutte le partite trovate sono già nel Registro Partite.";
    $("pbReplaceNote").textContent = note;
    $("pbReplaceNote").classList.remove("hidden");
    $("pbConfirmBtn").disabled = !fresh.length;
    $("pbPreview").classList.remove("hidden");
    setStatus(`Trovate ${games.length} partite in ${seasons.length} ${seasons.length === 1 ? "stagione" : "stagioni"}. Controlla e conferma.`, false);
  }

  function resetDialog() {
    pending = null;
    htmlCache.clear();
    $("pbUrl").value = "";
    $("pbPasteText").value = "";
    $("pbPasteBox").open = false;
    $("pbPreview").classList.add("hidden");
    setStatus("");
    $("pbFetchBtn").disabled = false;
  }

  async function fromLink() {
    const url = $("pbUrl").value.trim();
    if (!isPbProfileUrl(safeUrl(url))) {
      setStatus("Inserisci il link di un profilo giocatore di playbasket.it.");
      return;
    }
    $("pbPreview").classList.add("hidden");
    $("pbFetchBtn").disabled = true;
    setStatus("Scarico il profilo…", false);
    try {
      const seasons = await loadSeasonsFromUrl(url);
      if (seasons === null) {
        setStatus("Non riesco a leggere il profilo dal link. Apri la pagina su PlayBasket, copia il codice della pagina e incollalo qui sotto.");
        $("pbPasteBox").open = true;
        $("pbPasteText").focus();
      } else if (!seasons.length) {
        setStatus("Nessuna partita trovata in questo profilo (PlayBasket potrebbe non avere statistiche partita per questo giocatore).");
      } else {
        showPreview(seasons, url);
      }
    } catch (e) {
      console.warn("Import PlayBasket fallito", e);
      setStatus("Qualcosa è andato storto durante la lettura. Riprova tra poco.");
    } finally {
      $("pbFetchBtn").disabled = false;
    }
  }

  // Alternativa: codice HTML della singola pagina stagione incollato a mano
  async function fromPaste() {
    const html = $("pbPasteText").value;
    const parsed = html.trim() ? parseSeasonPage(html, $("pbUrl").value.trim()) : null;
    if (!parsed || !parsed.games.length) {
      setStatus("Nessuna partita riconosciuta. Incolla il codice completo della pagina (Ctrl+U, seleziona tutto, copia) con la tabella \"Statistiche partite\".");
      return;
    }
    showPreview([parsed], $("pbUrl").value.trim());
  }

  function confirmImport() {
    if (!pending || !pending.games.length || window.viewOnly) return;
    data.games.push(...pending.games);
    save();
    render();
    $("importPbDialog").close();
  }

  // ---------- Eventi ----------
  $("importPbBtn").onclick = () => {
    if (window.viewOnly) return;
    resetDialog();
    if (typeof toggleBodyScroll === "function") toggleBodyScroll(true);
    $("importPbDialog").showModal();
    $("pbUrl").focus();
  };
  $("pbFetchBtn").onclick = fromLink;
  $("pbUrl").addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); fromLink(); } });
  $("pbParseBtn").onclick = fromPaste;
  $("pbConfirmBtn").onclick = confirmImport;
  $("pbCancelBtn").onclick = () => $("importPbDialog").close();

  // Esposto per test
  window.__pbParseSeasonPage = parseSeasonPage;
})();
