// photo-utils.js — utilità condivise da index.html e player.html
//  - ridimensiona/comprime le foto profilo (una foto da telefono pesa 3-8 MB: salvata così
//    riempiva la memoria del browser e superava il limite di 1 MB di un documento Firestore,
//    facendo bloccare il salvataggio, l'import del JSON e il caricamento della home)
//  - salvataggio sicuro in localStorage (non lancia eccezioni se la memoria è piena)
(function () {
  const MAX_SIDE = 360;     // lato massimo in pixel della foto salvata
  const QUALITY = 0.8;      // qualità JPEG
  const HEAVY = 120000;     // oltre questi caratteri (~90 KB) una foto viene ricompressa

  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const timer = setTimeout(() => reject(new Error("timeout")), 20000);
      img.onload = () => { clearTimeout(timer); resolve(img); };
      img.onerror = () => { clearTimeout(timer); reject(new Error("immagine non leggibile")); };
      img.src = src;
    });
  }

  function drawToDataUrl(img) {
    const w0 = img.naturalWidth || img.width;
    const h0 = img.naturalHeight || img.height;
    if (!w0 || !h0) throw new Error("dimensioni non valide");
    const scale = Math.min(1, MAX_SIDE / Math.max(w0, h0));
    const w = Math.max(1, Math.round(w0 * scale));
    const h = Math.max(1, Math.round(h0 * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#ffffff"; // i PNG trasparenti non devono diventare neri in JPEG
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(img, 0, 0, w, h);
    return canvas.toDataURL("image/jpeg", QUALITY);
  }

  // File scelto dall'utente -> data URL compresso
  async function compressImageFile(file) {
    const url = URL.createObjectURL(file);
    try {
      return drawToDataUrl(await loadImage(url));
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  // Data URL (anche molto pesante) -> data URL compresso
  async function compressDataUrl(dataUrl) {
    return drawToDataUrl(await loadImage(dataUrl));
  }

  // Per i dati che arrivano da fuori (file JSON): restituisce una foto sicura da salvare,
  // oppure "" se il valore non è un'immagine valida.
  async function normalizePhoto(p) {
    if (typeof p !== "string" || !p.startsWith("data:image/")) return "";
    if (p.length <= HEAVY) return p;
    try { return await compressDataUrl(p); } catch (e) { return ""; }
  }

  function safeSet(key, value) {
    try {
      localStorage.setItem(key, value);
      return true;
    } catch (e) {
      console.warn("Salvataggio locale fallito (memoria del browser piena?)", e);
      return false;
    }
  }

  window.PhotoUtils = { HEAVY, compressImageFile, compressDataUrl, normalizePhoto, safeSet };
})();
