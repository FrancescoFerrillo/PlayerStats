// scout-view.js — scout salvati nel profilo: mappa tiri e box score di ogni partita, con download in JPG.
// Ogni partita importata da Scout Live contiene game.scout = { shots, rows (box di squadra), me, ... }.
(function () {
  const R = window.ScoutRender, $$ = id => document.getElementById(id);
  const KEYS = ["pts", "m2", "a2", "m3", "a3", "ftm", "fta", "reb", "A", "PR", "PP", "FF", "ST", "val", "sec"];
  let cur = { i: -1, mode: "one", q: "all" };

  document.body.insertAdjacentHTML("beforeend", `<dialog id="scoutViewDlg" class="scout-dialog wide">
    <button class="close-dialog" onclick="scoutViewDlg.close()">×</button>
    <p class="eyebrow">SCOUT LIVE</p><h2 class="sv-head" id="svHead"></h2><p class="sv-sub" id="svSub"></p>
    <div class="sv-modes" id="svModes"></div><div class="sv-q" id="svQ"></div>
    <div class="sv-grid"><div><svg class="sv-court" id="svCourt" viewBox="0 0 500 470"></svg><p class="sv-legend" id="svLegend"></p></div><div class="sv-tiles" id="svTiles"></div></div>
    <div class="sv-box" id="svBox"></div>
    <div class="actions"><button class="outline" id="svBoxJpg" type="button">Box score (JPG)</button><button class="outline" id="svJpg" type="button">Scarica scout (JPG)</button><button class="primary" type="button" onclick="scoutViewDlg.close()">Chiudi</button></div></dialog>`);

  const scoutGames = () => { const f = ($$("seasonFilter") || {}).value || "all"; return data.games.filter(g => g.scout && (f === "all" || g.season === f)); };
  const me = sc => (sc.rows && sc.rows[sc.me]) || {};
  const pct = R.pct;

  function view() {
    const g = data.games[cur.i], sc = g && g.scout; if (!sc) return null;
    const p = data.profile || {}, name = `${p.firstName || ""} ${p.lastName || ""}`.trim();
    if (cur.mode === "one") {
      const r = me(sc), shots = sc.shots || [];
      return { one: true, sc, r, shots, name: r.name || name, num: r.num || p.number || "", head: `${sc.team || g.team || ""} ${sc.teamScore} – ${sc.oppScore} ${sc.opp || g.opponent || ""}`, sub: sc.infoLine || "" };
    }
    const list = scoutGames(), s = {}; KEYS.forEach(k => s[k] = list.reduce((a, x) => a + (me(x.scout)[k] || 0), 0));
    const f = ($$("seasonFilter") || {}).value || "all";
    return { one: false, r: s, shots: list.flatMap(x => x.scout.shots || []), name, num: p.number || "", head: `${list.length} partite con scout`, sub: f === "all" ? "Tutte le stagioni" : "Stagione " + f, count: list.length };
  }

  function render() {
    const v = view(); if (!v) return;
    const list = scoutGames();
    $$("svHead").textContent = v.head; $$("svSub").textContent = v.sub;
    $$("svModes").innerHTML = `<button data-m="one" class="${v.one ? "on" : ""}">Questa partita</button>` + (list.length > 1 ? `<button data-m="all" class="${v.one ? "" : "on"}">Tutte le partite con scout (${list.length})</button>` : "");
    const qs = v.one ? [...new Set((v.sc.shots || []).map(e => e.q))] : [];
    $$("svQ").innerHTML = qs.length > 1 ? `<button data-q="all" class="${cur.q === "all" ? "on" : ""}">Tutti i tempi</button>` + qs.map(q => `<button data-q="${esc(q)}" class="${cur.q === q ? "on" : ""}">${esc(q)}</button>`).join("") : "";
    const shots = v.one && cur.q !== "all" ? v.shots.filter(e => e.q === cur.q) : v.shots;
    $$("svCourt").innerHTML = R.courtInner() + R.shotsSvg(shots);
    const made = shots.filter(e => e.m).length;
    $$("svLegend").textContent = `Tiri dal campo mostrati: ${made}/${shots.length} (${pct(made, shots.length)}). Cerchio verde = segnato, croce rossa = sbagliato.`;
    const r = v.r, t = [["Punti", r.pts, 1], ["Minuti", R.fmtMin(r.sec)], ["Valutaz.", r.val], ["2 punti", `${r.m2}/${r.a2}`], ["3 punti", `${r.m3}/${r.a3}`], ["Liberi", `${r.ftm}/${r.fta}`], ["Rimbalzi", r.reb], ["Assist", r.A], ["Recuperi", r.PR], ["Palle perse", r.PP], ["Falli", r.FF], ["Stoppate", r.ST]];
    $$("svTiles").innerHTML = t.map(x => `<div class="sv-tile ${x[2] ? "hl" : ""}"><small>${x[0]}</small><b>${esc(String(x[1] ?? 0))}</b></div>`).join("");
    if (v.one) {
      $$("svBox").innerHTML = R.tableHtml(v.sc.rows || [], { me: v.sc.me, noTotal: !!v.sc.single });
    } else $$("svBox").innerHTML = "";
    $$("svBoxJpg").style.display = v.one ? "" : "none";
  }

  window.openScoutView = i => { cur = { i, mode: "one", q: "all" }; render(); $$("scoutViewDlg").showModal(); };
  $$("scoutViewDlg").addEventListener("click", e => {
    const b = e.target.closest("button"); if (!b) return;
    if (b.dataset.m) { cur.mode = b.dataset.m; cur.q = "all"; render(); }
    else if (b.dataset.q) { cur.q = b.dataset.q; render(); }
  });
  const safeName = () => R.safe(((data.profile || {}).firstName || "") + "_" + ((data.profile || {}).lastName || "")) || "giocatore";
  $$("svJpg").onclick = async () => {
    const v = view(); if (!v) return;
    const g = data.games[cur.i], sc = v.sc || {};
    const info = v.one
      ? { team: sc.team, opp: sc.opp, teamScore: sc.teamScore, oppScore: sc.oppScore, infoLine: sc.infoLine, num: v.num, name: v.name, s: v.r, shots: v.shots }
      : { scoreText: v.head, matchText: v.sub, infoLine: "Mappa tiri di tutte le partite con scout", num: v.num, name: v.name, s: v.r, shots: v.shots };
    const blob = await R.toBlob(await R.playerCanvas(info));
    R.download(blob, v.one ? `scout_${safeName()}_${R.safe(sc.opp || g.opponent)}_${g.date || ""}.jpg` : `scout_${safeName()}_totale.jpg`);
  };
  $$("svBoxJpg").onclick = async () => {
    const v = view(); if (!v || !v.one) return; const g = data.games[cur.i], sc = v.sc;
    const blob = await R.toBlob(await R.boxCanvas({ team: sc.team, opp: sc.opp, teamScore: sc.teamScore, oppScore: sc.oppScore, infoLine: sc.infoLine, rows: sc.rows, noTotal: !!sc.single }));
    R.download(blob, `boxscore_${R.safe(sc.team)}_vs_${R.safe(sc.opp)}_${g.date || ""}.jpg`);
  };
})();
