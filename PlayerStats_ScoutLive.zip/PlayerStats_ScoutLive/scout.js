// scout.js — Scout Live: tabellino in tempo reale, salvato in locale finche' non premi "Partita finita"
const $ = id => document.getElementById(id);
const seasonOf = d => { const y = +String(d).slice(0, 4), m = +String(d).slice(5, 7); return m >= 8 ? `${y}/${String(y + 1).slice(2)}` : `${y - 1}/${String(y).slice(2)}`; };
const KEY = "psScoutLive", REG = "capocottaPlayersRegistry", THEME = "capocottaTheme";
const esc = (s = "") => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const G = JSON.parse(localStorage.getItem(KEY) || "null");
if (!G || G.finished) { location.replace("index.html"); throw new Error("Nessuna partita in corso"); }

// tema condiviso
if (localStorage.getItem(THEME) === "dark") { document.documentElement.classList.add("dark-mode"); $("themeToggle").textContent = "Light Mode"; }
$("themeToggle").onclick = () => { const d = document.documentElement.classList.toggle("dark-mode"); localStorage.setItem(THEME, d ? "dark" : "light"); $("themeToggle").textContent = d ? "Light Mode" : "Night Mode"; };

// ---------- compatibilita' con partite salvate dalle versioni precedenti ----------
G.comp = G.comp || ""; G.gameType = G.gameType || ""; G.giornata = G.giornata || ""; G.gameNumber = G.gameNumber || "";
G.date = G.date || new Date().toISOString().slice(0, 10);
G.season = G.season || seasonOf(G.date);
G.qLen = G.qLen || 10; G.otLen = G.otLen || 5; G.subs = G.subs || [];
if (!Array.isArray(G.periods)) {
  G.periods = ["Q1", "Q2", "Q3", "Q4"];
  if (G.quarter === "OT") { G.periods.push("OT1"); G.quarter = "OT1"; }
  G.events.forEach(e => { if (e.q === "OT") e.q = "OT1"; });
}
if (!G.periods.includes(G.quarter)) G.quarter = G.periods[0];
G.clock = G.clock || { rem: {}, running: false, last: 0 };
G.clock.rem = G.clock.rem || {};
G.clock.running = false; // riaprendo la pagina il tempo riparte sempre da fermo (nessun minuto "fantasma")
G.players.forEach(p => { if (typeof p.sec !== "number") p.sec = 0; });
G.mode = G.mode === "single" ? "single" : "team"; G.teamExtra = G.teamExtra || 0; // scout singolo: un solo giocatore, punti dei compagni a mano
const SINGLE = G.mode === "single";
document.body.classList.toggle("single", SINGLE);

const save = () => localStorage.setItem(KEY, JSON.stringify(G));
let active = (G.players.find(p => p.onCourt) || G.players[0]).id;
const P = id => G.players.find(p => p.id === id);
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

function toast(t, bad) { const el = $("toast"); el.textContent = t; el.classList.toggle("bad", !!bad); el.classList.add("show"); clearTimeout(toast.t); toast.t = setTimeout(() => el.classList.remove("show"), 1800); }
function confirmBox(title, msg, danger) {
  return new Promise(res => {
    $("confirmTitle").textContent = title; $("confirmMessage").textContent = msg;
    $("confirmOk").className = danger ? "delete-btn" : "primary";
    const d = $("confirmDialog"), ok = () => end(true), no = () => end(false);
    const end = v => { $("confirmOk").onclick = $("confirmCancel").onclick = $("closeConfirmBtn").onclick = null; d.close(); res(v); };
    $("confirmOk").onclick = ok; $("confirmCancel").onclick = no; $("closeConfirmBtn").onclick = no; d.showModal();
  });
}

// ---------- cronometro ----------
const plen = q => (String(q).startsWith("OT") ? G.otLen : G.qLen) * 60;
const remOf = q => (typeof G.clock.rem[q] === "number" ? G.clock.rem[q] : plen(q));
const fmtClock = s => { s = Math.max(0, Math.ceil(s - 1e-6)); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };
const fmtMin = s => { s = Math.max(0, Math.round(s || 0)); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };

// Porta avanti il cronometro fino ad ora e accredita i secondi ai giocatori che sono in campo.
// Ritorna true se il periodo e' appena finito.
function flushClock() {
  const c = G.clock; if (!c.running) return false;
  const now = Date.now(), dt = Math.max(0, (now - c.last) / 1000); c.last = now;
  const rem = remOf(G.quarter), use = Math.min(dt, rem);
  c.rem[G.quarter] = rem - use;
  if (use > 0) G.players.forEach(p => { if (p.onCourt) p.sec = (p.sec || 0) + use; });
  if (c.rem[G.quarter] <= 0.0005) { c.rem[G.quarter] = 0; c.running = false; return true; }
  return false;
}
function pauseClock() { flushClock(); G.clock.running = false; }
const ICON_PLAY = '<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><path d="M4 2l10 6-10 6z"/></svg>';
const ICON_PAUSE = '<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><rect x="3" y="2" width="4" height="12" rx="1"/><rect x="9" y="2" width="4" height="12" rx="1"/></svg>';
function renderClock() {
  const rem = remOf(G.quarter), run = G.clock.running;
  $("clkTime").textContent = fmtClock(rem);
  $("clkTime").classList.toggle("run", run); $("clkTime").classList.toggle("end", rem <= 0);
  $("clkToggle").innerHTML = run ? ICON_PAUSE : ICON_PLAY; $("clkToggle").classList.toggle("run", run);
  const m = $("actMin"); if (m && P(active)) m.textContent = fmtMin(P(active).sec);
}
let lastSave = 0;
setInterval(() => {
  if (!G.clock.running) return;
  const ended = flushClock(); renderClock();
  if (ended) { save(); render(); toast(`Fine ${G.quarter}`); if (navigator.vibrate) navigator.vibrate([200, 100, 200]); }
  else if (Date.now() - lastSave > 1000) { lastSave = Date.now(); save(); }
}, 250);

$("clkToggle").onclick = () => {
  if (G.clock.running) { pauseClock(); }
  else {
    if (remOf(G.quarter) <= 0) { toast("Tempo finito: passa al periodo successivo o modifica il tempo", true); return; }
    G.clock.running = true; G.clock.last = Date.now();
  }
  save(); renderClock();
};
$("clkTime").onclick = () => {
  flushClock(); renderClock();
  $("clkTitle").textContent = `Modifica tempo · ${G.quarter}`;
  $("clkInput").value = fmtClock(remOf(G.quarter));
  $("clkDlg").showModal(); $("clkInput").select();
};
$("clkForm").onsubmit = e => {
  e.preventDefault();
  const m = $("clkInput").value.trim().match(/^(\d{1,2})(?:[:.,](\d{1,2}))?$/);
  if (!m) { toast("Formato non valido: usa mm:ss (es. 7:30)", true); return; }
  const sec = +m[1] * 60 + (m[2] ? +m[2] : 0);
  if (sec > 60 * 60) { toast("Tempo troppo lungo", true); return; }
  flushClock();
  G.clock.rem[G.quarter] = sec; if (G.clock.running) G.clock.last = Date.now();
  save(); renderClock(); $("clkDlg").close();
};

function setPeriod(q) { pauseClock(); G.quarter = q; save(); render(); }
function otRemovable() {
  const last = G.periods[G.periods.length - 1];
  return last && last.startsWith("OT") && !G.events.some(e => e.q === last) && typeof G.clock.rem[last] !== "number";
}
function addOT() {
  const n = G.periods.filter(x => x.startsWith("OT")).length + 1, name = "OT" + n;
  G.periods.push(name); setPeriod(name); toast(`Aggiunto ${name} (${G.otLen} min)`);
}
function removeOT() {
  if (!otRemovable()) return;
  const last = G.periods.pop();
  if (G.quarter === last) { pauseClock(); G.quarter = G.periods[G.periods.length - 1]; }
  save(); render();
}

// ---------- statistiche ----------
const KEYS = ["PR", "A", "RD", "RO", "PP", "FF", "FS", "ST"];
const LABEL = { PR: "Palle recuperate", A: "Assist", RD: "Rimb. difensivi", RO: "Rimb. offensivi", PP: "Palle perse", FF: "Falli fatti", FS: "Falli subiti", ST: "Stoppate" };
const NEG = { PP: 1, FF: 1 };
function stats(pid) {
  const s = { pts: 0, m2: 0, a2: 0, m3: 0, a3: 0, ftm: 0, fta: 0, PR: 0, A: 0, RD: 0, RO: 0, PP: 0, FF: 0, FS: 0, ST: 0 };
  for (const e of G.events) {
    if (e.p !== pid) continue;
    if (e.t === "s") { const k = e.pt === 3 ? "3" : "2"; s["a" + k]++; if (e.m) { s["m" + k]++; s.pts += e.pt; } }
    else if (e.k === "TLM") { s.ftm++; s.fta++; s.pts++; } else if (e.k === "TLX") s.fta++;
    else s[e.k]++;
  }
  s.reb = s.RD + s.RO;
  s.val = s.pts + s.reb + s.A + s.PR + s.FS + s.ST - (s.a2 - s.m2) - (s.a3 - s.m3) - (s.fta - s.ftm) - s.PP - s.FF;
  s.sec = (P(pid) && P(pid).sec) || 0;
  return s;
}
const teamScore = () => G.players.reduce((a, p) => a + stats(p.id).pts, 0) + (SINGLE ? G.teamExtra : 0);

// ---------- dettagli partita ----------
const dateIT = d => { const m = String(d || "").match(/^(\d{4})-(\d{2})-(\d{2})$/); return m ? `${m[3]}/${m[2]}/${m[1]}` : (d || ""); };
function gameInfoParts() {
  const parts = [];
  if (G.comp) parts.push(G.comp);
  if (G.ageGroup) parts.push(G.ageGroup);
  if (G.venue) parts.push(G.venue === "Casa" ? "In casa" : "Trasferta");
  if (SINGLE) parts.push("Scout singolo");
  if (G.season) parts.push("Stagione " + G.season);
  const typeShort = String(G.gameType || "").split(" (")[0];
  if (typeShort && !typeShort.startsWith("RS")) parts.push(typeShort);
  if (G.giornata) parts.push((G.gameType === "PlayOff" ? "Gara " : "Giornata ") + G.giornata);
  if (G.gameNumber) parts.push("Partita " + G.gameNumber);
  if (G.date) parts.push(dateIT(G.date));
  return parts;
}

// ---------- render ----------
function render() {
  $("tName").textContent = G.team; $("oName").textContent = G.opp;
  $("tScore").textContent = teamScore(); $("oScore").textContent = G.oppScore;
  const info = gameInfoParts();
  $("gMeta").innerHTML = info.map((x, i) => i === 0 && G.comp ? `<b>${esc(x)}</b>` : esc(x)).join(" · ");
  $("qBtns").innerHTML = G.periods.map(q => `<button data-q="${q}" class="${G.quarter === q ? "on" : ""}">${q}</button>`).join("") +
    `<button class="add-ot" data-addot="1" title="Aggiungi un tempo supplementare">+OT</button>` +
    (otRemovable() ? `<button class="rm-ot" data-rmot="1" title="Rimuovi l'ultimo OT vuoto">×</button>` : "");
  $("undoBtn").disabled = !G.events.length; $("navUndo").disabled = !G.events.length;
  $("pBar").innerHTML = [...G.players.filter(p => p.onCourt), ...G.players.filter(p => !p.onCourt)].map(p => `<button class="pchip ${p.id === active ? "on" : ""} ${p.onCourt ? "" : "bench"}" data-id="${p.id}"><b>#${esc(p.number || "-")}</b><span>${esc(p.name)}</span><span>${stats(p.id).pts} pt</span></button>`).join("");
  const a = P(active), s = stats(active);
  $("active").innerHTML = `<div class="num">#${esc(a.number || "-")}</div><div><div class="nm">${esc(a.name)} ${a.onCourt ? '<small class="on-court">in campo</small>' : ""}</div>
    <div class="ln"><span><b>${s.pts}</b> PTS</span><span>2P <b>${s.m2}/${s.a2}</b></span><span>3P <b>${s.m3}/${s.a3}</b></span><span>TL <b>${s.ftm}/${s.fta}</b></span><span>Val <b>${s.val}</b></span><span>Min <b id="actMin">${fmtMin(a.sec)}</b></span></div></div>`;
  $("pad").innerHTML = KEYS.map(k => `<button data-k="${k}" class="${NEG[k] ? "neg" : ""}"><i>${s[k]}</i><b>${k}</b><small>${LABEL[k]}</small></button>`).join("");
  $("ftBtn").innerHTML = `Tiri liberi <b>${s.ftm}/${s.fta}</b>`;
  renderClock(); renderSingle();
  drawShots();
}
function drawShots() {
  const c = $("court");
  c.querySelectorAll(".shot").forEach(n => n.remove());
  G.events.filter(e => e.t === "s" && (e.p === active || showAll)).forEach(e => {
    const g = document.createElementNS("http://www.w3.org/2000/svg", "g"); g.setAttribute("class", "shot");
    g.innerHTML = e.m ? `<circle cx="${e.x}" cy="${e.y}" r="11" fill="#16a34a" stroke="#fff" stroke-width="2"/>` :
      `<path d="M${e.x - 8} ${e.y - 8}l16 16m0-16l-16 16" stroke="#dc2626" stroke-width="4" stroke-linecap="round"/>`;
    c.appendChild(g);
  });
}
let showAll = false;

// ---------- campo ----------
const S = 500 / 15, BX = 250, BY = 470 - 1.575 * S;
$("court").innerHTML = `<g class="ln"><rect x="2" y="2" width="496" height="466"/>
 <rect x="${250 - 2.45 * S}" y="${470 - 5.8 * S}" width="${4.9 * S}" height="${5.8 * S}"/>
 <path d="M${250 - 1.8 * S} ${470 - 5.8 * S}a${1.8 * S} ${1.8 * S} 0 0 1 ${3.6 * S} 0"/>
 <path d="M${250 - 1.8 * S} ${470 - 5.8 * S}a${1.8 * S} ${1.8 * S} 0 0 0 ${3.6 * S} 0" stroke-dasharray="8 8"/>
 <path d="M30 470V${BY - Math.sqrt((6.75 * S) ** 2 - 220 ** 2)}A${6.75 * S} ${6.75 * S} 0 0 1 470 ${BY - Math.sqrt((6.75 * S) ** 2 - 220 ** 2)}V470"/>
 <path d="M${250 - 1.25 * S} ${BY}a${1.25 * S} ${1.25 * S} 0 0 1 ${2.5 * S} 0"/><path d="M${250 - 0.9 * S} ${470 - 1.2 * S}h${1.8 * S}"/></g>
 <circle cx="${BX}" cy="${BY}" r="9" fill="none" stroke="#f47721" stroke-width="4"/>`;
function shotAt(x, y, made) {
  const dx = x - BX, dy = y - BY, dist = Math.hypot(dx, dy) / S;
  const pt = dist > 6.75 || Math.abs(dx) > 220 ? 3 : 2;
  G.events.push({ id: uid(), t: "s", p: active, x: Math.round(x), y: Math.round(y), m: made, pt, q: G.quarter, d: +dist.toFixed(1) });
  save(); render();
  if (made && navigator.vibrate) navigator.vibrate(30);
  toast(`#${P(active).number} ${P(active).name}: ${made ? "canestro da " + pt : "errore da " + pt} (${dist.toFixed(1)}m)`, !made);
}
(function () {
  const c = $("court"); let timer = null, long = false, pos = null;
  const pt = ev => { const r = c.getBoundingClientRect(); return { x: (ev.clientX - r.left) / r.width * 500, y: (ev.clientY - r.top) / r.height * 470 }; };
  c.addEventListener("pointerdown", ev => { pos = pt(ev); long = false; timer = setTimeout(() => { long = true; shotAt(pos.x, pos.y, false); if (navigator.vibrate) navigator.vibrate(60); }, 450); });
  c.addEventListener("pointerup", () => { clearTimeout(timer); if (pos && !long) shotAt(pos.x, pos.y, true); pos = null; });
  c.addEventListener("pointermove", ev => { if (pos && Math.hypot(pt(ev).x - pos.x, pt(ev).y - pos.y) > 15) { clearTimeout(timer); pos = null; } });
  c.addEventListener("pointercancel", () => { clearTimeout(timer); pos = null; });
  c.addEventListener("contextmenu", e => e.preventDefault());
})();

// ---------- azioni ----------
const statEv = (k, p = active) => { G.events.push({ id: uid(), t: "k", p, k, q: G.quarter }); save(); render(); };
document.addEventListener("click", e => {
  const b = e.target.closest("button"); if (!b) return;
  if (b.dataset.q) { if (b.dataset.q !== G.quarter) setPeriod(b.dataset.q); }
  else if (b.dataset.addot) addOT();
  else if (b.dataset.rmot) removeOT();
  else if (b.dataset.id) { active = b.dataset.id; render(); }
  else if (b.dataset.h) { G.teamExtra = Math.max(0, G.teamExtra + +b.dataset.h); save(); render(); }
  else if (b.dataset.o) { G.oppScore = Math.max(0, G.oppScore + +b.dataset.o); save(); render(); }
  else if (b.dataset.tab) { document.querySelectorAll(".sc-tabs button, .sc-nav button[data-tab]").forEach(x => x.classList.toggle("on", x.dataset.tab === b.dataset.tab)); document.querySelector(".sc-grid").dataset.tab = b.dataset.tab; window.scrollTo({ top: 0, behavior: "smooth" }); }
});
document.querySelector(".sc-grid").dataset.tab = "court";
let padTimer;
$("pad").addEventListener("pointerdown", e => {
  const b = e.target.closest("button"); if (!b) return; const k = b.dataset.k;
  padTimer = setTimeout(() => { padTimer = null; const i = G.events.map(x => x.p === active && x.k === k).lastIndexOf(true); if (i >= 0) { G.events.splice(i, 1); save(); render(); toast(`−1 ${LABEL[k]}`, true); } }, 500);
});
$("pad").addEventListener("pointerup", e => {
  const b = e.target.closest("button"); if (!b) return;
  if (padTimer) { clearTimeout(padTimer); padTimer = null; statEv(b.dataset.k); toast(`#${P(active).number}: +1 ${LABEL[b.dataset.k]}`, !!NEG[b.dataset.k]); }
});
$("pad").addEventListener("pointerleave", () => { clearTimeout(padTimer); padTimer = null; });
$("pad").addEventListener("contextmenu", e => e.preventDefault());
$("undoBtn").onclick = () => { if (G.events.pop()) { save(); render(); toast("Ultima azione annullata", true); } };
$("scHome").onclick = () => { pauseClock(); save(); location.href = "index.html"; };

// ---------- tiri liberi (mini menu) ----------
let ftM = 0, ftA = 0;
const FT_PRESETS = ["0/1", "1/1", "1/2", "2/2", "0/2", "1/3", "2/3", "3/3"];
function renderFt() {
  const a = P(active), s = stats(active);
  $("ftWho").textContent = `#${a.number || "-"} ${a.name}`;
  $("ftTally").textContent = `${s.ftm}/${s.fta}`;
  $("ftPct").textContent = s.fta ? Math.round(s.ftm / s.fta * 100) + "%" : "—";
  $("ftM").textContent = ftM; $("ftA").textContent = ftA;
  $("ftPresets").innerHTML = FT_PRESETS.map(x => `<button type="button" data-pre="${x}">${x}</button>`).join("");
  $("ftUndo").disabled = !G.events.some(e => e.p === active && (e.k === "TLM" || e.k === "TLX"));
}
$("ftBtn").onclick = () => { ftM = 0; ftA = 0; renderFt(); $("ftDlg").showModal(); };
function addFt(made, n = 1) {
  for (let i = 0; i < n; i++) G.events.push({ id: uid(), t: "k", p: active, k: made ? "TLM" : "TLX", q: G.quarter });
}
$("ftMade").onclick = () => { addFt(true); save(); render(); renderFt(); if (navigator.vibrate) navigator.vibrate(30); };
$("ftMiss").onclick = () => { addFt(false); save(); render(); renderFt(); };
$("ftUndo").onclick = () => {
  const i = G.events.map(x => x.p === active && (x.k === "TLM" || x.k === "TLX")).lastIndexOf(true);
  if (i >= 0) { G.events.splice(i, 1); save(); render(); renderFt(); toast("Ultimo tiro libero annullato", true); }
};
$("ftDlg").addEventListener("click", e => {
  const b = e.target.closest("button"); if (!b) return;
  if (b.dataset.st) {
    const d = b.dataset.st;
    if (d === "m+") { ftM = Math.min(10, ftM + 1); if (ftA < ftM) ftA = ftM; }
    else if (d === "m-") ftM = Math.max(0, ftM - 1);
    else if (d === "a+") ftA = Math.min(10, ftA + 1);
    else if (d === "a-") ftA = Math.max(ftM, ftA - 1);
    renderFt();
  } else if (b.dataset.pre) {
    const [m, a] = b.dataset.pre.split("/").map(Number); ftM = m; ftA = a; renderFt();
  }
});
$("ftAdd").onclick = () => {
  if (!ftA) { toast("Indica quanti tiri sono stati tirati", true); return; }
  addFt(true, ftM); addFt(false, ftA - ftM); save(); render();
  toast(`#${P(active).number}: ${ftM}/${ftA} tiri liberi`); ftM = 0; ftA = 0; renderFt();
};

// ---------- numeri e cambi ----------
let pendingIn = null; // giocatore in panchina scelto per entrare: si sceglie poi chi esce
let lastSub = "";
function openMenu() { pendingIn = null; lastSub = ""; renderMenu(); $("menuDlg").showModal(); }
function renderMenu() {
  const on = G.players.filter(p => p.onCourt), off = G.players.filter(p => !p.onCourt);
  const row = p => {
    const s = stats(p.id);
    const cls = [p.id === active ? "on" : "", p.onCourt ? "oc" : "bn", pendingIn === p.id ? "sel" : "", pendingIn && p.onCourt ? "target" : ""].join(" ");
    const tag = p.onCourt ? (pendingIn ? "ESCE" : "IN CAMPO") : (pendingIn === p.id ? "ENTRA" : "PANCHINA");
    return `<div class="mrow ${cls}" data-pick="${p.id}"><b>#${esc(p.number || "-")}</b><span>${esc(p.name)}<small>${fmtMin(p.sec)} min · ${s.pts} pt · ${s.FF} falli</small></span><em class="${p.onCourt ? "in" : ""}">${tag}</em></div>`;
  };
  $("menuList").innerHTML = `<h4>In campo <span>${on.length}/5</span></h4><div class="menu-list">${on.map(row).join("")}</div>` +
    `<h4>In panchina <span>${off.length}</span></h4><div class="menu-list">${off.map(row).join("") || '<small style="color:var(--muted)">Nessun giocatore in panchina</small>'}</div>`;
  const pin = pendingIn && P(pendingIn);
  $("menuHint").textContent = pin
    ? `Entra #${pin.number || "-"} ${pin.name}. Ora tocca chi esce dal campo.`
    : (lastSub ? lastSub + " " : "") + "Cambio: tocca chi entra dalla panchina, poi chi esce dal campo.";
  $("menuHint").classList.toggle("swap-on", !!pin);
  $("menuCancelSwap").style.display = pin ? "" : "none";
}
// Scout singolo: al posto del roster c'e' un solo pulsante "In campo / In panchina"
function renderSingle() {
  if (!SINGLE) return;
  const on = G.players[0].onCourt, t = on ? "In campo" : "In panchina";
  $("rosterFab").textContent = t; $("navRoster").querySelector("span").textContent = t;
  $("rosterFab").classList.toggle("off", !on); $("navRoster").classList.toggle("off", !on);
}
function toggleSingle() {
  const p = G.players[0];
  pauseClockKeepRunning(() => { p.onCourt = !p.onCourt; });
  save(); render(); toast(p.onCourt ? "Giocatore in campo: i minuti scorrono" : "Giocatore in panchina: minuti fermi");
}
$("rosterFab").onclick = SINGLE ? toggleSingle : openMenu; $("navRoster").onclick = SINGLE ? toggleSingle : openMenu; $("navUndo").onclick = () => $("undoBtn").click();
$("navMore").onclick = () => $("moreDlg").showModal();
$("moreBox").onclick = () => { $("moreDlg").close(); $("boxBtn").click(); };
$("moreFinish").onclick = () => { $("moreDlg").close(); $("finishBtn").click(); };
$("moreTheme").onclick = () => $("themeToggle").click();
$("moreExit").onclick = () => { $("moreDlg").close(); $("scHome").click(); };
$("menuCancelSwap").onclick = () => { pendingIn = null; renderMenu(); };
function doSub(inP, outP) {
  pauseClockKeepRunning(() => {
    if (outP) outP.onCourt = false;
    inP.onCourt = true;
    G.subs.push({ q: G.quarter, t: Math.round(remOf(G.quarter)), in: inP.id, out: outP ? outP.id : null });
  });
  active = inP.id; save(); render();
  lastSub = outP ? `Cambio fatto: entra #${inP.number || "-"}, esce #${outP.number || "-"}.` : `#${inP.number || "-"} è entrato in campo.`;
  toast(outP ? `Cambio: entra #${inP.number || "-"}, esce #${outP.number || "-"}` : `#${inP.number || "-"} entra in campo`);
}
// Accredita i minuti fino a questo istante, applica la modifica e riparte se il tempo scorreva
function pauseClockKeepRunning(fn) { const was = G.clock.running; flushClock(); const still = G.clock.running; fn(); if (was && still) G.clock.last = Date.now(); }
$("menuList").onclick = e => {
  const row = e.target.closest("[data-pick]"); if (!row) return;
  const p = P(row.dataset.pick);
  if (!p.onCourt) {
    if (G.players.filter(x => x.onCourt).length < 5) { doSub(p, null); pendingIn = null; renderMenu(); return; }
    pendingIn = pendingIn === p.id ? null : p.id; renderMenu();
  } else if (pendingIn) {
    doSub(P(pendingIn), p); pendingIn = null; renderMenu();
  } else { active = p.id; $("menuDlg").close(); render(); }
};

// ---------- box score ----------
function boxRows() { return G.players.map(p => ({ p, s: stats(p.id) })); }
const boxData = () => boxRows().map(({ p, s }) => ({ num: p.number || "", name: p.name, ...s, sec: Math.round(s.sec) }));
function boxTableHtml(withHead) {
  const info = gameInfoParts().join(" · ");
  const table = ScoutRender.tableHtml(boxData(), { noTotal: SINGLE });
  // con l'intestazione: testo fermo, solo la tabella scorre in orizzontale
  return withHead ? `<p class="bx-head"><b>${esc(G.team)} ${teamScore()}</b> — ${G.oppScore} <b>${esc(G.opp)}</b></p>${info ? `<p class="access-hint">${esc(info)}</p>` : ""}<div class="box-wrap">${table}</div>` : table;
}
$("boxBtn").onclick = () => {
  pauseClockKeepRunning(() => { });
  $("boxWrap").innerHTML = boxTableHtml(true);
  $("boxDlg").showModal();
};
$("boxJson").onclick = () => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([JSON.stringify(G, null, 1)], { type: "application/json" })); a.download = `scout_${G.opp}_${G.date}.json`; a.click(); };

// ---------- immagini JPG (box score, singolo giocatore, tutti in ZIP) ----------
const scoreInfo = () => ({ team: G.team, opp: G.opp, teamScore: teamScore(), oppScore: G.oppScore, infoLine: gameInfoParts().join("   ·   ") });
const shotsOf = pid => G.events.filter(e => e.t === "s" && e.p === pid).map(e => ({ x: e.x, y: e.y, m: e.m ? 1 : 0, pt: e.pt, q: e.q }));
const fileBase = () => `${ScoutRender.safe(G.team)}_vs_${ScoutRender.safe(G.opp)}_${G.date}`;
const boxBlob = async () => ScoutRender.toBlob(await ScoutRender.boxCanvas({ ...scoreInfo(), rows: boxData(), noTotal: SINGLE }));
const playerBlob = async p => ScoutRender.toBlob(await ScoutRender.playerCanvas({ ...scoreInfo(), num: p.number, name: p.name, s: stats(p.id), shots: shotsOf(p.id) }));
async function boxJpg() {
  try { toast("Creo l'immagine…"); ScoutRender.download(await boxBlob(), `boxscore_${fileBase()}.jpg`); toast("Box score salvato in JPG"); }
  catch (e) { console.error(e); toast("Impossibile creare l'immagine", true); }
}
async function playerJpg() {
  const p = P(active);
  try { toast("Creo l'immagine…"); ScoutRender.download(await playerBlob(p), `scout_${ScoutRender.safe(p.number)}_${ScoutRender.safe(p.name)}_${G.date}.jpg`); toast("Scout salvato in JPG"); }
  catch (e) { console.error(e); toast("Impossibile creare l'immagine", true); }
}
async function allScoutsZip() {
  try {
    toast("Preparo le immagini…");
    const files = [{ name: `00_boxscore_${fileBase()}.jpg`, blob: await boxBlob() }];
    for (let i = 0; i < G.players.length; i++) {
      const p = G.players[i];
      files.push({ name: `${String(i + 1).padStart(2, "0")}_${ScoutRender.safe(p.number || "x")}_${ScoutRender.safe(p.name)}.jpg`, blob: await playerBlob(p) });
    }
    ScoutRender.download(await ScoutRender.makeZip(files), `scout_${fileBase()}.zip`);
    toast(`Salvate ${files.length} immagini in uno ZIP`);
  } catch (e) { console.error(e); toast("Impossibile creare lo ZIP", true); }
}
if (SINGLE) $("boxZip").style.display = "none";
$("boxJpgBtn").onclick = boxJpg;
$("boxPlayerJpg").onclick = playerJpg;
$("boxZip").onclick = allScoutsZip;

// ---------- fine partita ----------
$("finishBtn").onclick = () => {
  pauseClock(); save(); renderClock();
  $("finishScore").innerHTML = `<span class="fs-names">${esc(G.team)} <i>-</i> ${esc(G.opp)}</span><span class="fs-num"><em>${teamScore()}</em><i>-</i><em>${G.oppScore}</em></span>`;
  $("finishBox").innerHTML = boxTableHtml(false);
  $("finishDlg").showModal();
};
$("finJpg").onclick = boxJpg;
$("finImport").onclick = () => { $("finishDlg").close(); openImport(); };
$("finDiscard").onclick = async () => {
  if (!(await confirmBox("Chiudere senza importare?", "La partita verrà chiusa e le statistiche NON saranno salvate nei profili dei giocatori. Se non hai scaricato il box score andrà perso. L'azione non è reversibile.", true))) return;
  localStorage.removeItem(KEY);
  location.href = "index.html";
};

// ---------- import nel database ----------
const loadReg = () => { try { return JSON.parse(localStorage.getItem(REG)) || []; } catch (e) { return []; } };
const norm = s => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z ]/g, "").trim();
async function fetchReg() {
  if (window.cloudDB) try { const snap = await window.cloudDB.collection("players").get(); const r = []; snap.forEach(d => r.push(d.data())); if (r.length) { localStorage.setItem(REG, JSON.stringify(r)); return r; } } catch (e) { console.warn(e); }
  return loadReg();
}
function autoMatch(p, reg) {
  const n = norm(p.name); if (!n) return null;
  const full = x => norm(`${x.firstName || ""} ${x.lastName || ""}`);
  return (reg.find(x => full(x) === n) || reg.find(x => x.lastName && n.split(" ").includes(norm(x.lastName)) && (!p.number || !x.number || String(x.number) === String(p.number))) || {}).id || null;
}
async function openImport() {
  const reg = await fetchReg();
  const opts = reg.slice().sort((a, b) => (a.lastName || "").localeCompare(b.lastName || "")).map(x => `<option value="${esc(x.id)}">${esc((x.firstName + " " + x.lastName).trim())} #${esc(x.number || "-")}</option>`).join("");
  const used = new Set();
  $("importList").innerHTML = boxRows().map(({ p, s }) => {
    let m = autoMatch(p, reg);
    if (m && used.has(m)) m = null; // lo stesso giocatore del database non puo' ricevere due righe
    if (m) used.add(m);
    return `<div class="irow ${m ? "" : "new"}" data-pid="${p.id}"><div><b>#${esc(p.number || "-")} ${esc(p.name)}</b><small>${s.pts} pt · ${s.reb} rimb · ${s.A} ass · ${s.m2 + s.m3}/${s.a2 + s.a3} dal campo · ${fmtMin(s.sec)} min</small></div>
      <select><option value="__new" ${m ? "" : "selected"}>Aggiungi come nuovo giocatore</option>${opts.replace(`value="${m}"`, `value="${m}" selected`)}<option value="__skip">Non importare</option></select></div>`;
  }).join("");
  $("importList").querySelectorAll("select").forEach(sel => { sel.dataset.prev = sel.value; });
  $("importList").onchange = e => {
    const sel = e.target, r = sel.closest(".irow"), v = sel.value;
    if (v !== "__new" && v !== "__skip") {
      const clash = [...$("importList").querySelectorAll("select")].find(x => x !== sel && x.value === v);
      if (clash) { toast("Questo giocatore è già assegnato a un'altra riga", true); sel.value = sel.dataset.prev || "__skip"; return; }
    }
    sel.dataset.prev = v;
    r.classList.toggle("new", v === "__new"); r.classList.toggle("skip", v === "__skip");
  };
  $("importDlg").showModal();
}
async function readStats(id) {
  if (window.cloudDB) try { const d = await window.cloudDB.collection("playerStats").doc(id).get(); if (d.exists && d.data().games) return d.data(); } catch (e) { console.warn(e); }
  try { const l = JSON.parse(localStorage.getItem(`capocottaStats_${id}`)); if (l && l.games) return l; } catch (e) { }
  return null;
}
$("importGo").onclick = async () => {
  const btn = $("importGo");
  const sels = [...$("importList").querySelectorAll("select")].map(s => s.value).filter(v => v !== "__new" && v !== "__skip");
  if (new Set(sels).size !== sels.length) { toast("Lo stesso giocatore è assegnato a più righe: correggi prima di importare", true); return; }
  btn.disabled = true; btn.textContent = "Salvo…";
  const reg = await fetchReg(), ts = teamScore(), won = ts > G.oppScore ? "V" : "P";
  const anyTime = G.players.some(p => p.sec > 0);
  let n = 0;
  try {
    for (const row of $("importList").querySelectorAll(".irow")) {
      const sel = row.querySelector("select").value; if (sel === "__skip") continue;
      const pl = P(row.dataset.pid), s = stats(pl.id);
      let id = sel, entry = reg.find(x => x.id === id);
      if (sel === "__new") {
        const parts = pl.name.trim().split(/\s+/); id = crypto.randomUUID ? crypto.randomUUID() : "p_" + uid();
        entry = { id, firstName: parts[0], lastName: parts.slice(1).join(" "), number: pl.number || "", role: "", photo: "", passHash: "", noPassword: true, updatedAt: Date.now() };
        reg.push(entry); localStorage.setItem(REG, JSON.stringify(reg));
        if (window.cloudDB) await window.cloudDB.collection("players").doc(id).set(entry);
      }
      let d = await readStats(id) || { profile: { firstName: entry.firstName || "", lastName: entry.lastName || "", number: entry.number || "", role: entry.role || "", height: "", weight: "", birthDate: "", photo: entry.photo || "" }, games: [], excludedSeasons: [] };
      d.games.unshift({ date: G.date, season: G.season || seasonOf(G.date), team: G.team, opponent: G.opp, result: won, score: `${ts}-${G.oppScore}`, venue: G.venue || "", gameType: G.gameType || "", category: G.comp || "", ageGroup: G.ageGroup || "", giornata: G.giornata || "", gameNumber: G.gameNumber || "",
        scout: { v: 1, single: SINGLE, team: G.team, opp: G.opp, teamScore: ts, oppScore: G.oppScore, infoLine: gameInfoParts().join("   ·   "), me: G.players.indexOf(pl), shots: shotsOf(pl.id), rows: boxData() },
        min: anyTime ? +(pl.sec / 60).toFixed(1) : "Unknown", pts: s.pts, ast: s.A, blk: s.ST, twoM: s.m2, twoA: s.a2, threeM: s.m3, threeA: s.a3, ftM: s.ftm, ftA: s.fta, oreb: s.RO, dreb: s.RD, stl: s.PR, to: s.PP });
      d.updatedAt = Date.now();
      localStorage.setItem(`capocottaStats_${id}`, JSON.stringify(d));
      if (window.cloudDB) await window.cloudDB.collection("playerStats").doc(id).set(d);
      n++;
    }
    G.finished = true; save(); localStorage.removeItem(KEY);
    toast(`Partita salvata su ${n} giocatori`); setTimeout(() => location.href = "index.html", 900);
  } catch (e) { console.error(e); btn.disabled = false; btn.textContent = "Importa e chiudi partita"; toast("Errore di salvataggio: riprova (la partita è ancora salva)", true); }
};
render();
