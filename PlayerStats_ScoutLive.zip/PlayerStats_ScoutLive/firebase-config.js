// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDUYjNq0Ov7EkqfrvIYQVp2X_qIKWuVz9c",
  authDomain: "playerstatsweb.firebaseapp.com",
  projectId: "playerstatsweb",
  storageBucket: "playerstatsweb.firebasestorage.app",
  messagingSenderId: "594985153019",
  appId: "1:594985153019:web:264585218d26516eeb9b5e",
  measurementId: "G-8DKS1E9SZX"
};

window.cloudDB = null;
try {
  if (firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith("INCOLLA_QUI")) {
    firebase.initializeApp(firebaseConfig);
    window.cloudDB = firebase.firestore();
    console.log("[Player Stats Profile] Database condiviso attivo (Firebase).");
  } else {
    console.log("[Player Stats Profile] Firebase non configurato: uso solo il salvataggio locale del browser.");
  }
} catch (e) {
  console.warn("[Player Stats Profile] Impossibile inizializzare Firebase, uso solo il salvataggio locale.", e);
  window.cloudDB = null;
}
