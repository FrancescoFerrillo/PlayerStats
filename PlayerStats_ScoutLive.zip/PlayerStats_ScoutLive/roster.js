// roster.js — Home/Roster: elenco giocatori salvati nel "database" locale
// (nessun import/export manuale necessario: tutto viene salvato automaticamente).

const THEME_KEY = "capocottaTheme";
const REGISTRY_KEY = "capocottaPlayersRegistry"; // "database" dei giocatori
const $ = id => document.getElementById(id);

const DEFAULT_USER_AVATAR = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100' fill='none' stroke='%23f47721' stroke-width='6' stroke-linecap='round' stroke-linejoin='round'><circle cx='50' cy='50' r='44' fill='%23101d35'/><path d='M6 50h88'/><path d='M50 6v88'/><path d='M20 12c22 18 22 58 0 76'/><path d='M80 12c-22 18-22 58 0 76'/></svg>";

// Tema (condiviso con la scheda giocatore)
function initTheme() {
  const savedTheme = localStorage.getItem(THEME_KEY);
  if (savedTheme === "dark") {
    document.documentElement.classList.add("dark-mode");
    if ($("themeToggle")) $("themeToggle").textContent = "☀️ Light Mode";
  }
}
function toggleTheme() {
  const isDark = document.documentElement.classList.toggle("dark-mode");
  localStorage.setItem(THEME_KEY, isDark ? "dark" : "light");
  if ($("themeToggle")) $("themeToggle").textContent = isDark ? "☀️ Light Mode" : "🌙 Night Mode";
}
initTheme();
if ($("themeToggle")) $("themeToggle").onclick = toggleTheme;

function esc(s = "") {
  return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function genId() {
  return crypto.randomUUID ? crypto.randomUUID() : ("p_" + Date.now() + "_" + Math.random().toString(36).slice(2, 9));
}

function loadRegistry() {
  try {
    const r = JSON.parse(localStorage.getItem(REGISTRY_KEY));
    return Array.isArray(r) ? r : [];
  } catch (e) {
    console.warn("Registro giocatori non leggibile", e);
    return [];
  }
}
function saveRegistry(reg) {
  PhotoUtils.safeSet(REGISTRY_KEY, JSON.stringify(reg));
}

// Finche' il database condiviso non ha risposto, con l'elenco locale vuoto mostriamo
// "Caricamento…" invece di "Nessun giocatore" (che sembrava un elenco perso).
let cloudPending = !!window.cloudDB;
const currentQuery = () => ($("searchPlayer") ? $("searchPlayer").value : "");

// --- Sincronizzazione con il database condiviso (Firebase), se configurato ---
// Il salvataggio locale (sopra) resta invariato per una UI sempre istantanea;
// in piu', se firebase-config.js e' configurato, replichiamo i dati online
// cosi' che altre persone, da altri dispositivi, vedano le stesse info.
// Scritture verso il cloud non ancora confermate (rete assente, errore...): restano segnate
// e vengono rinviate al prossimo caricamento invece di sparire alla prima sincronizzazione.
const PENDING_KEY = "capocottaPendingCloud"; // stesso formato usato dalla scheda giocatore
function loadPending() {
  try {
    const p = JSON.parse(localStorage.getItem(PENDING_KEY)) || {};
    return { players: Array.isArray(p.players) ? p.players : [], stats: Array.isArray(p.stats) ? p.stats : [] };
  } catch (e) {
    return { players: [], stats: [] };
  }
}
function setPending(kind, id, on) {
  const p = loadPending();
  const set = new Set(p[kind]);
  if (on) set.add(id); else set.delete(id);
  p[kind] = [...set];
  PhotoUtils.safeSet(PENDING_KEY, JSON.stringify(p));
}

let cloudWarnShown = false;
function cloudWarn(msg) {
  if (cloudWarnShown) return;
  cloudWarnShown = true;
  const el = document.createElement("div");
  el.textContent = msg;
  el.style.cssText = "position:fixed;left:50%;bottom:20px;transform:translateX(-50%);max-width:92vw;z-index:9999;background:#b3261e;color:#fff;padding:10px 16px;border-radius:10px;font-size:13px;box-shadow:0 6px 24px rgba(0,0,0,.35);cursor:pointer";
  el.onclick = () => el.remove();
  document.body.appendChild(el);
  setTimeout(() => { el.remove(); cloudWarnShown = false; }, 9000);
}

function cloudUpsertPlayer(entry) {
  if (!window.cloudDB) return;
  setPending("players", entry.id, true);
  window.cloudDB.collection("players").doc(entry.id).set(entry)
    .then(() => setPending("players", entry.id, false))
    .catch(e => {
      console.warn("Sincronizzazione cloud (salvataggio giocatore) fallita:", e);
      cloudWarn("Salvataggio online non riuscito: il giocatore per ora è solo su questo dispositivo.");
    });
}
function cloudUpsertStats(id, statsData) {
  if (!window.cloudDB) return;
  setPending("stats", id, true);
  window.cloudDB.collection("playerStats").doc(id).set(statsData)
    .then(() => setPending("stats", id, false))
    .catch(e => {
      console.warn("Sincronizzazione cloud (statistiche importate) fallita:", e);
      cloudWarn("Salvataggio online delle statistiche non riuscito: restano solo su questo dispositivo.");
    });
}
function cloudDeletePlayer(id) {
  if (!window.cloudDB) return;
  setPending("players", id, false);
  setPending("stats", id, false);
  window.cloudDB.collection("players").doc(id).delete().catch(e =>
    console.warn("Sincronizzazione cloud (eliminazione giocatore) fallita:", e)
  );
  window.cloudDB.collection("playerStats").doc(id).delete().catch(() => {});
}

async function cloudRefreshRoster() {
  if (!window.cloudDB) return;
  try {
    const snap = await window.cloudDB.collection("players").get();
    const cloud = [];
    snap.forEach(doc => cloud.push(doc.data()));

    // Il cloud e' la fonte di verita', TRANNE per i giocatori creati/modificati su questo
    // dispositivo il cui salvataggio online non e' mai stato confermato: quelli si tengono
    // e si rinviano (prima sparivano alla prima sincronizzazione).
    const pending = loadPending();
    const localPending = loadRegistry().filter(p => pending.players.includes(p.id));
    const cloudById = new Map(cloud.map(p => [p.id, p]));
    const reg = cloud.slice();
    localPending.forEach(l => {
      const c = cloudById.get(l.id);
      if (!c) {
        reg.push(l);
        cloudUpsertPlayer(l);
      } else if ((l.updatedAt || 0) > (c.updatedAt || 0)) {
        reg[reg.indexOf(c)] = l;
        cloudUpsertPlayer(l);
      } else {
        setPending("players", l.id, false);
      }
    });
    // Statistiche in attesa di invio (es. giocatore importato da JSON senza rete)
    pending.stats.forEach(id => {
      try {
        const st = JSON.parse(localStorage.getItem(`capocottaStats_${id}`));
        if (st && st.profile && Array.isArray(st.games)) cloudUpsertStats(id, st);
        else setPending("stats", id, false);
      } catch (e) { /* dati locali non leggibili: si lasciano stare */ }
    });

    saveRegistry(reg);
    cloudPending = false;
    renderRoster(currentQuery());
    healEmptyEntries(reg);  // in background: ripara le schede rimaste "senza nome"
    shrinkHeavyPhotos(reg); // in background: alleggerisce le vecchie foto non compresse
  } catch (e) {
    console.warn("Impossibile scaricare l'elenco giocatori dal database condiviso, mostro i dati salvati localmente.", e);
    cloudPending = false;
    renderRoster(currentQuery());
  }
}

// Riparazione: le voci del registro rimaste vuote (nome, cognome, numero e ruolo assenti) a causa
// del vecchio bug vengono ricostruite dal profilo salvato nelle statistiche del giocatore.
async function healEmptyEntries(reg) {
  let changed = false;
  for (const p of reg) {
    if (p.firstName || p.lastName || p.number || p.role) continue;
    try {
      const doc = await window.cloudDB.collection("playerStats").doc(p.id).get();
      const pr = doc.exists && doc.data() && doc.data().profile;
      if (!pr || !(pr.firstName || pr.lastName)) continue;
      const fix = {
        firstName: pr.firstName || "",
        lastName: pr.lastName || "",
        number: pr.number || "",
        role: pr.role || ""
      };
      if (pr.photo && pr.photo.length < 400000) fix.photo = pr.photo;
      Object.assign(p, fix);
      changed = true;
      window.cloudDB.collection("players").doc(p.id).set(fix, { merge: true }).catch(() => {});
    } catch (e) {
      console.warn("Riparazione scheda non riuscita per", p.id, e);
    }
  }
  if (changed) {
    saveRegistry(reg);
    renderRoster(currentQuery());
  }
}

// Le foto salvate in passato senza compressione rendevano lenti il caricamento della home
// e il database: le riduciamo una volta sola (aggiorna solo il campo foto).
async function shrinkHeavyPhotos(reg) {
  let changed = false;
  for (const p of reg) {
    if (!p.photo || p.photo.length <= PhotoUtils.HEAVY) continue;
    try {
      const small = await PhotoUtils.compressDataUrl(p.photo);
      p.photo = small;
      changed = true;
      window.cloudDB.collection("players").doc(p.id).update({ photo: small }).catch(() => {});
    } catch (e) {
      console.warn("Foto non riducibile per", p.id, e);
    }
  }
  if (changed) {
    saveRegistry(reg);
    renderRoster(currentQuery());
  }
}

async function sha256Hex(str) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
}


// Sblocco per sessione: dopo aver inserito la password di un giocatore, resta sbloccato finche'
// non si chiude il sito (sessionStorage). Si salva l'hash: se la password cambia, lo sblocco decade.
const UNLOCK_KEY = "psUnlockedHashes";
// Si ricordano gli hash delle password inserite in questa sessione: ogni giocatore con la stessa password
// risulta sbloccato. Se la password di un giocatore cambia, il nuovo hash non e' nella lista e la chiede.
function getUnlocked() { try { const a = JSON.parse(sessionStorage.getItem(UNLOCK_KEY)); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
function markUnlocked(id, hash) { if (!hash) return; const u = getUnlocked(); if (u.includes(hash)) return; u.push(hash); try { sessionStorage.setItem(UNLOCK_KEY, JSON.stringify(u)); } catch (e) {} }
function isUnlocked(id, hash) { return !!hash && getUnlocked().includes(hash); }

// Chiede la password di un giocatore: risolve true solo se corretta, false se annullato
function askPlayerPassword(expectedHash, playerId) {
  if (isUnlocked(playerId, expectedHash)) return Promise.resolve(true); // gia' sbloccato in questa sessione
  return new Promise(resolve => {
    const dialog = $("deletePassDialog");
    const form = $("deletePassForm");
    const input = $("deletePassInput");
    const err = $("deletePassError");
    input.value = "";
    err.classList.add("hidden");

    let done = false;
    const finish = ok => {
      if (done) return;
      done = true;
      dialog.close();
      resolve(ok);
    };

    form.onsubmit = async e => {
      e.preventDefault();
      if ((await sha256Hex(input.value)) === expectedHash) { markUnlocked(playerId, expectedHash); finish(true); }
      else { err.classList.remove("hidden"); input.select(); }
    };
    $("deletePassCancel").onclick = () => finish(false);
    $("deletePassClose").onclick = () => finish(false);
    dialog.addEventListener("cancel", () => finish(false), { once: true });

    dialog.showModal();
    input.focus();
  });
}

// Modale di conferma (stesso comportamento di quella nella scheda giocatore)
function showCustomConfirm(title, message, isDangerous = false, hideCancel = false) {
  return new Promise((resolve) => {
    const dialog = $("confirmDialog");
    const okBtn = $("confirmOk");
    const cancelBtn = $("confirmCancel");
    const closeXBtn = $("closeConfirmBtn");

    $("confirmTitle").textContent = title;
    $("confirmMessage").textContent = message;
    okBtn.className = isDangerous ? "delete-btn" : "primary";
    cancelBtn.style.display = hideCancel ? "none" : "";

    const handleOk = () => { cleanup(); dialog.close(); resolve(true); };
    const handleCancel = () => { cleanup(); dialog.close(); resolve(false); };
    const cleanup = () => {
      okBtn.removeEventListener("click", handleOk);
      cancelBtn.removeEventListener("click", handleCancel);
      closeXBtn.removeEventListener("click", handleCancel);
    };

    okBtn.addEventListener("click", handleOk);
    cancelBtn.addEventListener("click", handleCancel);
    closeXBtn.addEventListener("click", handleCancel);
    dialog.showModal();
  });
}

function playerCardHTML(p) {
  const fullName = `${p.firstName || ""} ${p.lastName || ""}`.trim() || "Giocatore senza nome";
  const roleStr = p.role || "Ruolo non impostato";
  const avgStr = typeof p.avgPts === "number" ? ` · <span class="player-card-avg">${p.avgPts.toFixed(1)} PPG</span>` : "";
  const photo = p.photo && p.photo.trim() !== "" ? p.photo : DEFAULT_USER_AVATAR;
  return `
    <div class="player-card" data-id="${esc(p.id)}">
      <button class="player-card-delete" data-id="${esc(p.id)}" title="Elimina giocatore">×</button>
      <img class="player-card-photo" src="${photo}" alt="${esc(fullName)}" loading="lazy" decoding="async">
      <div class="player-card-jersey">${esc(p.number || "-")}</div>
      <div class="player-card-name">${esc(fullName)}</div>
      <div class="player-card-meta">${esc(roleStr)}${avgStr}</div>
    </div>
  `;
}

// --- Ordinamento della home ---
// Priorita' dei ruoli (dal primo all'ultimo). Per cambiarla basta riordinare questo elenco:
// ogni voce ha un'etichetta e le parole/sigle che la riconoscono nel testo libero del ruolo.
const ROLE_ORDER = [
  { label: "Playmaker",  re: /play|regista|point|\bpg\b|\bp\.?g\.?\b|\b1\b/ },
  { label: "Guardia",    re: /guardia|guard|shooting|\bsg\b|\bg\b|\b2\b/ },
  { label: "Ala piccola", re: /ala piccola|small|\bsf\b|\bap\b|\b3\b/ },
  { label: "Ala grande", re: /ala grande|power|\bpf\b|\bag\b|\b4\b/ },
  { label: "Centro",     re: /centro|center|centre|pivot|\bc\b|\b5\b/ }
];
const ROLE_NONE = { label: "Ruolo non impostato", rank: ROLE_ORDER.length + 1 };
function roleInfo(role) {
  const t = String(role || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
  if (!t) return ROLE_NONE;
  // Prima le ali (piccola/grande) per non confonderle con "guardia/centro" in ruoli composti
  const order = [0, 2, 3, 1, 4];
  for (const i of order) if (ROLE_ORDER[i].re.test(t)) return { label: ROLE_ORDER[i].label, rank: i };
  if (/\bala\b|forward/.test(t)) return { label: "Ala", rank: 2.5 };
  return { label: "Altri ruoli", rank: ROLE_ORDER.length };
}

const SORT_KEY = "psRosterSort";
const SORT_MODES = ["avgDesc", "avgAsc", "first", "last", "role"];
let sortMode = SORT_MODES.includes(localStorage.getItem(SORT_KEY)) ? localStorage.getItem(SORT_KEY) : "avgDesc";
if ($("sortPlayer")) {
  $("sortPlayer").value = sortMode;
  $("sortPlayer").addEventListener("change", e => {
    sortMode = e.target.value;
    try { localStorage.setItem(SORT_KEY, sortMode); } catch (err) { /* ignora */ }
    renderRoster(currentQuery());
  });
}

const cmp = (a, b) => String(a || "").localeCompare(String(b || ""), "it", { sensitivity: "base" });
const hasAvg = p => typeof p.avgPts === "number" && !isNaN(p.avgPts);

// Ordina l'elenco e lo divide in gruppi { label, players }: label vuota = nessuna intestazione
function sortAndGroup(all) {
  const byLast = (a, b) => cmp(a.lastName || a.firstName, b.lastName || b.firstName) || cmp(a.firstName, b.firstName);
  if (sortMode === "avgDesc" || sortMode === "avgAsc") {
    const dir = sortMode === "avgDesc" ? -1 : 1;
    const arr = all.slice().sort((a, b) => {
      if (hasAvg(a) !== hasAvg(b)) return hasAvg(a) ? -1 : 1; // senza media sempre in fondo
      if (hasAvg(a) && a.avgPts !== b.avgPts) return (a.avgPts - b.avgPts) * dir;
      return byLast(a, b);
    });
    return [{ label: "", players: arr }];
  }
  if (sortMode === "role") {
    const arr = all.slice().sort((a, b) => {
      const ra = roleInfo(a.role).rank, rb = roleInfo(b.role).rank;
      if (ra !== rb) return ra - rb;
      if (hasAvg(a) !== hasAvg(b)) return hasAvg(a) ? -1 : 1;
      if (hasAvg(a) && a.avgPts !== b.avgPts) return b.avgPts - a.avgPts;
      return byLast(a, b);
    });
    const groups = new Map();
    arr.forEach(p => {
      const label = roleInfo(p.role).label;
      if (!groups.has(label)) groups.set(label, []);
      groups.get(label).push(p);
    });
    return [...groups].map(([label, players]) => ({ label, players }));
  }
  // Nome o cognome: ordine alfabetico con intestazioni per lettera iniziale
  const useFirst = sortMode === "first";
  const keyOf = p => useFirst ? (p.firstName || p.lastName || "") : (p.lastName || p.firstName || "");
  const arr = all.slice().sort((a, b) => cmp(keyOf(a), keyOf(b)) || (useFirst ? cmp(a.lastName, b.lastName) : cmp(a.firstName, b.firstName)));
  const groups = new Map();
  arr.forEach(p => {
    const letter = keyOf(p).trim().charAt(0).toUpperCase() || "#";
    if (!groups.has(letter)) groups.set(letter, []);
    groups.get(letter).push(p);
  });
  return [...groups.keys()].sort((a, b) => cmp(a, b)).map(label => ({ label, players: groups.get(label) }));
}

function renderRoster(query = "") {
  const all = loadRegistry();
  const list = $("rosterList");
  const empty = $("rosterEmpty");
  const noResults = $("rosterNoResults");
  const loading = $("rosterLoading");
  const counter = $("rosterCount");

  counter.textContent = all.length ? `· ${all.length}` : "";

  if (!all.length) {
    list.innerHTML = "";
    loading.classList.toggle("hidden", !cloudPending);
    empty.classList.toggle("hidden", cloudPending);
    noResults.classList.add("hidden");
    return;
  }
  loading.classList.add("hidden");
  empty.classList.add("hidden");

  const q = query.trim().toLowerCase();
  const reg = !q ? all : all.filter(p => {
    const haystack = `${p.firstName || ""} ${p.lastName || ""} ${p.role || ""} ${p.number || ""}`.toLowerCase();
    return haystack.includes(q);
  });

  if (!reg.length) {
    list.innerHTML = "";
    noResults.classList.remove("hidden");
    return;
  }
  noResults.classList.add("hidden");

  list.innerHTML = sortAndGroup(reg).map(g => `
    <div class="roster-letter-group ${g.label ? "" : "roster-flat-group"}">
      ${g.label ? `<div class="roster-letter"><span>${esc(g.label)}</span></div>` : ""}
      <div class="roster-grid">
        ${g.players.map(playerCardHTML).join("")}
      </div>
    </div>
  `).join("");

  list.querySelectorAll(".player-card").forEach(card => {
    card.addEventListener("click", e => {
      if (e.target.closest(".player-card-delete")) return;
      location.href = `player.html?id=${encodeURIComponent(card.dataset.id)}`;
    });
  });

  list.querySelectorAll(".player-card-delete").forEach(btn => {
    btn.addEventListener("click", async e => {
      e.stopPropagation();
      const id = btn.dataset.id;
      // Se il giocatore e' protetto da password, va inserita prima di poterlo eliminare
      const entry = loadRegistry().find(p => p.id === id);
      if (entry && entry.passHash) {
        const ok = await askPlayerPassword(entry.passHash, id);
        if (!ok) return;
      }
      const confirmed = await showCustomConfirm(
        "Elimina giocatore",
        "Sei sicuro di voler eliminare definitivamente questo giocatore e tutte le sue statistiche? L'azione non è reversibile.",
        true
      );
      if (confirmed) {
        localStorage.removeItem(`capocottaStats_${id}`);
        saveRegistry(loadRegistry().filter(p => p.id !== id));
        cloudDeletePlayer(id);
        renderRoster($("searchPlayer") ? $("searchPlayer").value : "");
      }
    });
  });
}

if ($("searchPlayer")) {
  $("searchPlayer").addEventListener("input", e => renderRoster(e.target.value));
}

// Spunta "Continua senza password": chiede conferma con un avviso, poi disattiva i campi password
function setNoPassword(on) {
  $("noPasswordCheck").checked = on;
  $("addPlayerGrid").classList.toggle("nopass-on", on);
  ["newPassword", "newPasswordConfirm"].forEach(id => {
    $(id).required = !on;
    $(id).disabled = on;
    if (on) $(id).value = "";
  });
}
$("noPasswordCheck").addEventListener("change", async e => {
  if (e.target.checked) {
    const ok = await showCustomConfirm(
      "ATTENZIONE",
      "IN QUESTO MODO CHIUNQUE PUÒ MODIFICARE O ELIMINARE IL TUO PROFILO",
      true
    );
    setNoPassword(ok);
  } else {
    setNoPassword(false);
  }
});

// --- Import di un file JSON (esportato dalla scheda giocatore) direttamente nella creazione ---
// I dati del file (nome, cognome, numero, ruolo) sostituiscono quelli gia' scritti nel form;
// partite, foto, altezza, peso, data di nascita vengono presi dal file.
let pendingImport = null; // { profile, games, excludedSeasons }

function clearPendingImport() {
  pendingImport = null;
  $("importJsonInfo").classList.add("hidden");
  $("importJsonClear").classList.add("hidden");
}

$("importJsonBtn").onclick = () => $("importJsonInput").click();
$("importJsonClear").onclick = clearPendingImport;

$("importJsonInput").onchange = async e => {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;
  const info = $("importJsonInfo");
  info.textContent = "Leggo il file…";
  info.classList.remove("hidden");
  try {
    const obj = JSON.parse(await file.text());
    if (!obj || typeof obj.profile !== "object" || obj.profile === null || !Array.isArray(obj.games)) {
      throw new Error("struttura non valida");
    }
    const hadPhoto = !!obj.profile.photo;
    const photo = await PhotoUtils.normalizePhoto(obj.profile.photo); // ricomprime le foto pesanti
    pendingImport = {
      profile: { ...obj.profile, photo },
      games: obj.games,
      excludedSeasons: Array.isArray(obj.excludedSeasons) ? obj.excludedSeasons : []
    };

    // Sovrascrive i campi del form con quelli del file (se presenti nel file)
    [["newFirstName", "firstName"], ["newLastName", "lastName"], ["newNumber", "number"], ["newRole", "role"]]
      .forEach(([inputId, key]) => {
        const v = obj.profile[key];
        if (v !== undefined && v !== null && String(v).trim() !== "") $(inputId).value = String(v).trim();
      });

    const who = `${obj.profile.firstName || ""} ${obj.profile.lastName || ""}`.trim() || "giocatore senza nome";
    const n = obj.games.length;
    info.textContent = `File caricato: ${who} · ${n} ${n === 1 ? "partita" : "partite"}. I dati del file hanno sostituito quelli inseriti qui sotto.` +
      (hadPhoto && !photo ? " La foto nel file non era valida e verrà ignorata." : "") +
      " Scegli la password e premi Crea Giocatore.";
    info.classList.remove("hidden");
    $("importJsonClear").classList.remove("hidden");
  } catch (err) {
    console.warn("Import JSON non riuscito", err);
    clearPendingImport();
    await showCustomConfirm("Errore", "Impossibile leggere il file: non è un JSON esportato da Player Stats Profile.", true, true);
  }
};

$("addPlayerBtn").onclick = () => {
  $("addPlayerForm").reset();
  clearPendingImport();
  setNoPassword(false);
  $("addPlayerDialog").showModal();
};

$("addPlayerForm").onsubmit = async e => {
  if (e.submitter && e.submitter.value === "cancel") return;
  e.preventDefault();

  const firstName = $("newFirstName").value.trim();
  const lastName = $("newLastName").value.trim();
  const number = $("newNumber").value.trim();
  const role = $("newRole").value.trim();
  const password = $("newPassword").value;
  const passwordConfirm = $("newPasswordConfirm").value;

  const noPassword = $("noPasswordCheck").checked;

  if (!firstName) { $("newFirstName").focus(); return; }
  if (!noPassword && (!password || password.length < 4)) {
    await showCustomConfirm("Password troppo corta", "Inserisci una password di almeno 4 caratteri.", true);
    $("newPassword").focus();
    return;
  }
  if (!noPassword && password !== passwordConfirm) {
    await showCustomConfirm("Le password non coincidono", "La password e la conferma devono essere identiche.", true);
    $("newPasswordConfirm").focus();
    return;
  }

  const id = genId();
  const passHash = noPassword ? "" : await sha256Hex(password);
  const reg = loadRegistry();
  const imp = pendingImport;
  const photo = imp && imp.profile.photo ? imp.profile.photo : "";
  const entry = { id, firstName, lastName, number, role, photo: photo.length < 400000 ? photo : "", passHash, noPassword, updatedAt: Date.now() };
  reg.push(entry);
  saveRegistry(reg);
  cloudUpsertPlayer(entry);

  // Precompila i dati base cosi' la scheda del nuovo giocatore si apre gia' pronta
  // (con un file JSON importato: anche partite, foto e dati fisici del file)
  const initialData = {
    profile: imp
      ? { height: "", weight: "", birthDate: "", ...imp.profile, firstName, lastName, number, role, photo }
      : { firstName, lastName, number, role, height: "", weight: "", birthDate: "", photo: "" },
    games: imp ? imp.games : [],
    excludedSeasons: imp ? imp.excludedSeasons : []
  };
  if (!PhotoUtils.safeSet(`capocottaStats_${id}`, JSON.stringify(initialData)) && !window.cloudDB) {
    await showCustomConfirm("Memoria piena", "Non è stato possibile salvare i dati nel browser.", true, true);
  }
  // Le statistiche vanno online SEMPRE alla creazione (anche senza JSON): senza, un altro dispositivo
  // trovava il giocatore nell'elenco ma con la scheda vuota ("non registrato").
  cloudUpsertStats(id, initialData);

  // Chi ha appena creato il giocatore (e impostato la password) non deve doverla
  // reinserire subito dopo: la scheda si apre gia' sbloccata questa unica volta.
  sessionStorage.setItem(`capocottaJustSet_${id}`, "1");
  markUnlocked(id, passHash);

  $("addPlayerDialog").close();
  location.href = `player.html?id=${encodeURIComponent(id)}`;
};

renderRoster();       // mostra subito i dati locali (istantaneo)
cloudRefreshRoster(); // poi aggiorna con i dati del database condiviso, se configurato

// Se il database condiviso non risponde (rete lenta/assente) non restiamo su "Caricamento…"
setTimeout(() => {
  if (cloudPending) { cloudPending = false; renderRoster(currentQuery()); }
}, 8000);
