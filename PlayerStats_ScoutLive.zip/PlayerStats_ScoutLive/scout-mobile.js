// scout-mobile.js — comodita' per il telefono: tocca lo sfondo per chiudere le finestre,
// schermo sempre acceso durante lo scout.
(function () {
  // tocco fuori dalla finestra = chiude (tranne setup e conferme, per non perdere dati)
  document.addEventListener("click", e => {
    const d = e.target;
    if (!(d instanceof HTMLDialogElement) || !d.classList.contains("scout-dialog") || d.id === "scoutSetupDialog") return;
    const r = d.getBoundingClientRect();
    if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) d.close();
  });

  // schermo acceso mentre si fa lo scout
  if (document.body.classList.contains("scout-body") && "wakeLock" in navigator) {
    let lock = null;
    const ask = async () => { try { lock = await navigator.wakeLock.request("screen"); } catch (e) { /* non supportato o negato */ } };
    ask();
    document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible") ask(); });
  }

  // ---- home: "Ordina per" con etichette corte su telefono ----
  const mq = window.matchMedia("(max-width: 720px)");
  const sel = document.getElementById("sortPlayer");
  if (sel) {
    const full = [...sel.options].map(o => o.textContent), short = ["Media alta", "Media bassa", "Nome A-Z", "Cognome A-Z", "Ruolo"];
    const apply = () => [...sel.options].forEach((o, i) => { o.textContent = mq.matches ? (short[i] || full[i]) : full[i]; });
    apply(); mq.addEventListener("change", apply); sel.setAttribute("aria-label", "Ordina per");
  }

  // ---- home: la scritta dei tasti si adatta al tasto senza cambiarne le dimensioni ----
  const fit = btn => {
    btn.style.fontSize = ""; let f = parseFloat(getComputedStyle(btn).fontSize);
    while (btn.scrollWidth > btn.clientWidth + 1 && f > 10) { f -= 0.5; btn.style.fontSize = f + "px"; }
  };
  const fitAll = () => document.querySelectorAll(".roster-actions .roster-add-btn").forEach(fit);
  if (document.querySelector(".roster-actions .roster-add-btn")) {
    fitAll(); window.addEventListener("resize", fitAll);
    const lbl = document.getElementById("scoutLiveLabel");
    if (lbl) new MutationObserver(fitAll).observe(lbl, { childList: true, characterData: true, subtree: true });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitAll);
  }
})();
