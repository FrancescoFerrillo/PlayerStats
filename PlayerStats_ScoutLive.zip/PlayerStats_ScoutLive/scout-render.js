// scout-render.js — funzioni condivise tra Scout Live e scheda giocatore:
// campo con i tiri, immagini JPG (box score e scheda giocatore) e ZIP di immagini.
(function () {
  const S = 500 / 15, BX = 250, BY = 470 - 1.575 * S;
  const ARC_Y = BY - Math.sqrt((6.75 * S) ** 2 - 220 ** 2);
  const rectD = (x, y, w, h) => `M${x} ${y}h${w}v${h}h${-w}z`;
  const LINES = [
    { d: rectD(2, 2, 496, 466) },
    { d: rectD(250 - 2.45 * S, 470 - 5.8 * S, 4.9 * S, 5.8 * S) },
    { d: `M${250 - 1.8 * S} ${470 - 5.8 * S}a${1.8 * S} ${1.8 * S} 0 0 1 ${3.6 * S} 0` },
    { d: `M${250 - 1.8 * S} ${470 - 5.8 * S}a${1.8 * S} ${1.8 * S} 0 0 0 ${3.6 * S} 0`, dash: true },
    { d: `M30 470V${ARC_Y}A${6.75 * S} ${6.75 * S} 0 0 1 470 ${ARC_Y}V470` },
    { d: `M${250 - 1.25 * S} ${BY}a${1.25 * S} ${1.25 * S} 0 0 1 ${2.5 * S} 0` },
    { d: `M${250 - 0.9 * S} ${470 - 1.2 * S}h${1.8 * S}` }
  ];
  const SANS = "Inter, Arial, Helvetica, sans-serif", COND = "'Barlow Condensed', 'Arial Narrow', Arial, sans-serif";

  const courtInner = () => `<g class="ln">${LINES.map(l => `<path d="${l.d}"${l.dash ? ' stroke-dasharray="8 8"' : ""}/>`).join("")}</g><circle cx="${BX}" cy="${BY}" r="9" fill="none" stroke="#f47721" stroke-width="4"/>`;
  const shotSvg = e => `<g class="shot">${e.m
    ? `<circle cx="${e.x}" cy="${e.y}" r="11" fill="#16a34a" stroke="#fff" stroke-width="2"/>`
    : `<path d="M${e.x - 8} ${e.y - 8}l16 16m0-16l-16 16" stroke="#dc2626" stroke-width="4" stroke-linecap="round"/>`}</g>`;
  const shotsSvg = shots => shots.map(shotSvg).join("");

  const fmtMin = s => { s = Math.max(0, Math.round(s || 0)); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };
  const pct = (m, a) => a ? Math.round(m / a * 100) + "%" : "-";
  const fit = (ctx, text, maxW) => {
    if (ctx.measureText(text).width <= maxW) return text;
    let t = text; while (t.length > 1 && ctx.measureText(t + "…").width > maxW) t = t.slice(0, -1);
    return t + "…";
  };
  async function loadFonts() {
    try { await Promise.all([document.fonts.load("700 24px Inter"), document.fonts.load("800 60px 'Barlow Condensed'")]); } catch (e) { /* font di sistema */ }
  }
  function totals(rows) {
    const T = { pts: 0, m2: 0, a2: 0, m3: 0, a3: 0, ftm: 0, fta: 0, reb: 0, A: 0, PR: 0, PP: 0, FF: 0, ST: 0, val: 0, sec: 0 };
    rows.forEach(r => Object.keys(T).forEach(k => T[k] += r[k] || 0));
    return T;
  }
  function newCanvas(W, H) {
    const scale = 2, cv = document.createElement("canvas"); cv.width = W * scale; cv.height = H * scale;
    const ctx = cv.getContext("2d"); ctx.scale(scale, scale); ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, W, H);
    return { cv, ctx };
  }
  function band(ctx, W, H, info, y0) {
    ctx.fillStyle = "#101d35"; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = "#f47721"; ctx.fillRect(0, H - 6, W, 6);
  }

  // ---------- box score di squadra ----------
  // info: { team, opp, teamScore, oppScore, infoLine, rows: [{num,name,sec,pts,m2,a2,...}] }
  async function boxCanvas(info) {
    await loadFonts();
    const rows = info.rows, T = totals(rows);
    const cols = [
      { h: "N°", w: 64, a: "c", v: r => r.num || "-" }, { h: "GIOCATORE", w: 320, a: "l", v: r => r.name },
      { h: "MIN", w: 86, v: r => fmtMin(r.sec) }, { h: "PTS", w: 80, v: r => r.pts, hl: 1 },
      { h: "2P", w: 92, v: r => `${r.m2}/${r.a2}` }, { h: "3P", w: 92, v: r => `${r.m3}/${r.a3}` }, { h: "TL", w: 92, v: r => `${r.ftm}/${r.fta}` },
      { h: "RIM", w: 80, v: r => r.reb }, { h: "AST", w: 80, v: r => r.A }, { h: "PR", w: 72, v: r => r.PR },
      { h: "PP", w: 72, v: r => r.PP }, { h: "FF", w: 72, v: r => r.FF }, { h: "ST", w: 72, v: r => r.ST }, { h: "VAL", w: 84, v: r => r.val }
    ];
    const PAD = 40, tableW = cols.reduce((a, c) => a + c.w, 0), W = tableW + PAD * 2;
    const BAND = 190, HEAD = 54, ROW = 48, TOT = info.noTotal ? 0 : 56, FOOT = 56;
    const H = BAND + 26 + HEAD + rows.length * ROW + TOT + FOOT;
    const { cv, ctx } = newCanvas(W, H);
    band(ctx, W, BAND, info);
    const mid = W / 2, nameW = W / 2 - 230;
    ctx.textBaseline = "alphabetic"; ctx.font = `700 34px ${SANS}`; ctx.fillStyle = "#ffffff";
    ctx.textAlign = "left"; ctx.fillText(fit(ctx, String(info.team).toUpperCase(), nameW), PAD, 92);
    ctx.textAlign = "right"; ctx.fillText(fit(ctx, String(info.opp).toUpperCase(), nameW), W - PAD, 92);
    const win = info.teamScore > info.oppScore;
    ctx.font = `800 104px ${COND}`; ctx.textAlign = "center"; ctx.fillStyle = "#ffffff";
    ctx.fillText(`${info.teamScore}  –  ${info.oppScore}`, mid, 118);
    ctx.font = `700 22px ${SANS}`; ctx.fillStyle = "#f47721";
    ctx.textAlign = "left"; if (win) ctx.fillText("VITTORIA", PAD, 130);
    ctx.textAlign = "right"; if (!win && info.teamScore !== info.oppScore) ctx.fillText("VITTORIA", W - PAD, 130);
    ctx.font = `600 22px ${SANS}`; ctx.fillStyle = "rgba(255,255,255,.78)"; ctx.textAlign = "center";
    ctx.fillText(fit(ctx, info.infoLine || "Box score", W - PAD * 2), mid, 166);

    let y = BAND + 26;
    const drawRow = (h, bg, fn) => { ctx.fillStyle = bg; ctx.fillRect(PAD, y, tableW, h); fn(); y += h; };
    const cells = (h, get, size, weight, color, hlColor) => {
      let x = PAD;
      cols.forEach(c => {
        const t = String(get(c)), hl = c.hl && hlColor;
        ctx.font = `${hl ? 800 : weight} ${size}px ${SANS}`; ctx.fillStyle = hl ? hlColor : color;
        if (c.a === "l") { ctx.textAlign = "left"; ctx.fillText(fit(ctx, t, c.w - 24), x + 14, y + h / 2 + 8); }
        else { ctx.textAlign = "center"; ctx.fillText(t, x + c.w / 2, y + h / 2 + 8); }
        x += c.w;
      });
    };
    drawRow(HEAD, "#e9edf5", () => cells(HEAD, c => c.h, 19, 700, "#101d35"));
    rows.forEach((r, i) => drawRow(ROW, i % 2 ? "#f6f8fc" : "#ffffff", () => {
      cells(ROW, c => c.v(r), 24, 600, "#1c2333", "#f47721");
      ctx.strokeStyle = "#e3e8f0"; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(PAD, y + ROW - .5); ctx.lineTo(PAD + tableW, y + ROW - .5); ctx.stroke();
    }));
    if (!info.noTotal) drawRow(TOT, "#101d35", () => cells(TOT, c => c.h === "GIOCATORE" ? "TOTALE" : c.h === "N°" ? "" : c.v(T), 25, 700, "#ffffff", "#ffb27a"));
    ctx.font = `600 18px ${SANS}`; ctx.fillStyle = "#8a93a6"; ctx.textAlign = "center";
    ctx.fillText("Player Stats · Scout Live", mid, y + 36);
    return cv;
  }

  // ---------- scheda singolo giocatore: mappa tiri + statistiche ----------
  // info: { team, opp, teamScore, oppScore, infoLine, num, name, s: riga statistiche, shots: [{x,y,m,pt}] }
  async function playerCanvas(info) {
    await loadFonts();
    const s = info.s, shots = info.shots || [];
    const W = 1100, PAD = 40, BAND = 170, CS = 1.12, CW = 500 * CS, CH = 470 * CS;
    const H = BAND + 30 + CH + 70;
    const { cv, ctx } = newCanvas(W, H);
    band(ctx, W, BAND, info);
    ctx.textBaseline = "alphabetic"; ctx.textAlign = "left";
    ctx.font = `800 92px ${COND}`; ctx.fillStyle = "#f47721"; ctx.fillText("#" + (info.num || "-"), PAD, 100);
    const numW = ctx.measureText("#" + (info.num || "-")).width;
    ctx.font = `700 40px ${SANS}`; ctx.fillStyle = "#ffffff";
    ctx.fillText(fit(ctx, String(info.name).toUpperCase(), W - PAD * 2 - numW - 330), PAD + numW + 22, 88);
    ctx.textAlign = "right"; ctx.font = `800 64px ${COND}`; ctx.fillStyle = "#ffffff";
    ctx.fillText(info.scoreText || `${info.teamScore} – ${info.oppScore}`, W - PAD, 78);
    ctx.font = `600 20px ${SANS}`; ctx.fillStyle = "rgba(255,255,255,.78)";
    ctx.fillText(fit(ctx, info.matchText || `${info.team} vs ${info.opp}`, 320), W - PAD, 108);
    ctx.textAlign = "left"; ctx.fillText(fit(ctx, info.infoLine || "", W - PAD * 2), PAD, 146);

    // campo
    const cy = BAND + 30;
    ctx.save(); ctx.translate(PAD, cy); ctx.scale(CS, CS);
    ctx.fillStyle = "#c98d4b"; ctx.fillRect(0, 0, 500, 470);
    ctx.strokeStyle = "rgba(255,255,255,.92)"; ctx.lineWidth = 3; ctx.lineJoin = "round";
    LINES.forEach(l => { ctx.setLineDash(l.dash ? [8, 8] : []); ctx.stroke(new Path2D(l.d)); });
    ctx.setLineDash([]); ctx.strokeStyle = "#f47721"; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(BX, BY, 9, 0, Math.PI * 2); ctx.stroke();
    shots.forEach(e => {
      if (e.m) { ctx.beginPath(); ctx.arc(e.x, e.y, 11, 0, Math.PI * 2); ctx.fillStyle = "#16a34a"; ctx.fill(); ctx.strokeStyle = "#fff"; ctx.lineWidth = 2; ctx.stroke(); }
      else { ctx.strokeStyle = "#dc2626"; ctx.lineWidth = 4; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(e.x - 8, e.y - 8); ctx.lineTo(e.x + 8, e.y + 8); ctx.moveTo(e.x + 8, e.y - 8); ctx.lineTo(e.x - 8, e.y + 8); ctx.stroke(); ctx.lineCap = "butt"; }
    });
    ctx.restore();

    // statistiche
    const X0 = PAD + CW + 40, RW = W - PAD - X0, GAP = 14, TW = (RW - GAP * 2) / 3, TH = 96;
    const tiles = [["PUNTI", s.pts, 1], ["MINUTI", fmtMin(s.sec)], ["VALUTAZ.", s.val], ["2 PUNTI", `${s.m2}/${s.a2}`], ["3 PUNTI", `${s.m3}/${s.a3}`], ["LIBERI", `${s.ftm}/${s.fta}`],
      ["RIMBALZI", s.reb], ["ASSIST", s.A], ["RECUPERI", s.PR], ["PALLE PERSE", s.PP], ["FALLI", s.FF], ["STOPPATE", s.ST]];
    tiles.forEach((t, i) => {
      const x = X0 + (i % 3) * (TW + GAP), y = cy + Math.floor(i / 3) * (TH + GAP);
      ctx.fillStyle = t[2] ? "#101d35" : "#f1f4f9"; ctx.fillRect(x, y, TW, TH);
      ctx.textAlign = "center"; ctx.font = `700 15px ${SANS}`; ctx.fillStyle = t[2] ? "#ffb27a" : "#718096"; ctx.fillText(t[0], x + TW / 2, y + 28);
      ctx.font = `800 46px ${COND}`; ctx.fillStyle = t[2] ? "#ffffff" : "#101d35"; ctx.fillText(String(t[1]), x + TW / 2, y + 76);
    });
    const fgm = s.m2 + s.m3, fga = s.a2 + s.a3;
    let ly = cy + 4 * (TH + GAP) + 18;
    ctx.textAlign = "left"; ctx.font = `700 20px ${SANS}`; ctx.fillStyle = "#1c2333";
    ctx.fillText(`Dal campo ${fgm}/${fga} (${pct(fgm, fga)})   2P ${pct(s.m2, s.a2)}   3P ${pct(s.m3, s.a3)}   TL ${pct(s.ftm, s.fta)}`, X0, ly);
    ly += 34; ctx.beginPath(); ctx.arc(X0 + 10, ly - 7, 10, 0, Math.PI * 2); ctx.fillStyle = "#16a34a"; ctx.fill();
    ctx.font = `600 18px ${SANS}`; ctx.fillStyle = "#4a5568"; ctx.fillText("Tiro segnato", X0 + 30, ly);
    ctx.strokeStyle = "#dc2626"; ctx.lineWidth = 4; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(X0 + 210, ly - 15); ctx.lineTo(X0 + 226, ly + 1); ctx.moveTo(X0 + 226, ly - 15); ctx.lineTo(X0 + 210, ly + 1); ctx.stroke(); ctx.lineCap = "butt";
    ctx.fillText("Tiro sbagliato", X0 + 240, ly);
    ctx.font = `600 18px ${SANS}`; ctx.fillStyle = "#8a93a6"; ctx.textAlign = "center";
    ctx.fillText("Player Stats · Scout Live", W / 2, H - 26);
    return cv;
  }

  const toBlob = cv => new Promise(res => cv.toBlob(res, "image/jpeg", 0.93));
  function download(blob, name) {
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }
  const safe = s => String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9]+/g, "_").replace(/^_|_$/g, "");

  // ZIP senza compressione (i JPG sono gia' compressi)
  const CRC = (() => { const t = []; for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = u8 => { let c = ~0; for (let i = 0; i < u8.length; i++) c = CRC[(c ^ u8[i]) & 255] ^ (c >>> 8); return (~c) >>> 0; };
  async function makeZip(files) {
    const enc = new TextEncoder(), parts = [], central = [], now = new Date();
    const dt = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1);
    const dd = ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
    let off = 0;
    for (const f of files) {
      const data = new Uint8Array(await f.blob.arrayBuffer()), name = enc.encode(f.name), crc = crc32(data);
      const lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(10, dt, true); lh.setUint16(12, dd, true);
      lh.setUint32(14, crc, true); lh.setUint32(18, data.length, true); lh.setUint32(22, data.length, true); lh.setUint16(26, name.length, true);
      parts.push(lh.buffer, name, data);
      const ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(12, dt, true); ch.setUint16(14, dd, true);
      ch.setUint32(16, crc, true); ch.setUint32(20, data.length, true); ch.setUint32(24, data.length, true); ch.setUint16(28, name.length, true); ch.setUint32(42, off, true);
      central.push(ch.buffer, name);
      off += 30 + name.length + data.length;
    }
    const cd = central.reduce((a, b) => a + b.byteLength, 0), end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true); end.setUint32(12, cd, true); end.setUint32(16, off, true);
    return new Blob([...parts, ...central, end.buffer], { type: "application/zip" });
  }

  // ---------- tabella box score (HTML) condivisa da Scout Live e scheda giocatore ----------
  const escH = (s = "") => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const TCOLS = [["N°", 34], ["Giocatore", 104], ["MIN", 46], ["PTS", 40], ["2P", 46], ["3P", 46], ["TL", 46], ["RIM", 40], ["AST", 40], ["PR", 36], ["PP", 36], ["FF", 36], ["ST", 36], ["VAL", 42]];
  // rows: [{num,name,sec,pts,...}] — opt: { me: indice riga evidenziata, noTotal: true }
  function tableHtml(rows, opt = {}) {
    const T = totals(rows);
    const tr = (x, cls) => `<tr class="${cls || ""}"><td>${escH(x.num || "")}</td><td>${escH(x.name || "")}</td><td>${fmtMin(x.sec)}</td><td><b>${x.pts}</b></td><td>${x.m2}/${x.a2}</td><td>${x.m3}/${x.a3}</td><td>${x.ftm}/${x.fta}</td><td>${x.reb}</td><td>${x.A}</td><td>${x.PR}</td><td>${x.PP}</td><td>${x.FF}</td><td>${x.ST}</td><td>${x.val}</td></tr>`;
    return `<table class="bx"><colgroup>${TCOLS.map(c => `<col style="width:${c[1]}px">`).join("")}</colgroup><thead><tr>${TCOLS.map(c => `<th>${c[0]}</th>`).join("")}</tr></thead><tbody>` +
      rows.map((r, i) => tr({ ...r, num: r.num || "-" }, i === opt.me ? "me" : "")).join("") +
      (opt.noTotal ? "" : tr({ ...T, num: "", name: "TOTALE" }, "tot")) + "</tbody></table>";
  }

  window.ScoutRender = { tableHtml, courtInner, shotsSvg, shotSvg, boxCanvas, playerCanvas, toBlob, download, makeZip, totals, fmtMin, pct, safe };
})();
