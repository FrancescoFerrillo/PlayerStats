# Player Stats Profile — versione con database condiviso

Ho aggiunto un file, `firebase-config.js`, e collegato il tuo `index.html` e
`player.html` a **Firebase Firestore**: un database gratuito in cloud.
Tutta la logica dell'app e' rimasta identica — ho solo aggiunto la
sincronizzazione: ogni salvataggio locale viene ora replicato online, e
all'apertura della pagina i dati vengono scaricati dal database condiviso.

Senza configurare Firebase, l'app funziona esattamente come prima (solo sul
browser di chi la usa). Con Firebase configurato, chiunque apra il link vede
e puo' inserire gli stessi giocatori e le stesse partite, da qualsiasi
dispositivo.

## 1. Crea il database (5 minuti, gratis, nessuna carta richiesta)

Le istruzioni complete sono scritte dentro `firebase-config.js` — apri il
file e seguile passo passo. In sintesi:

1. https://console.firebase.google.com → crea un progetto.
2. Build → Firestore Database → crea database (modalita' produzione).
3. Regole → incolla quelle indicate nel file → Pubblica.
4. Impostazioni progetto → Le tue app → "</>" (Web) → registra l'app →
   copia l'oggetto `firebaseConfig`.
5. Incollalo dentro `firebase-config.js` al posto dei valori di esempio.

## 2. Metti il sito online

Questi sono file statici (HTML/CSS/JS), quindi puoi ospitarli gratis con
uno qualsiasi di questi servizi — carica semplicemente tutta questa cartella:

- **Netlify** (piu' semplice): netlify.com → trascina la cartella nella
  pagina "Deploy" → ottieni un link tipo `nomeprogetto.netlify.app`.
- **Firebase Hosting** (stesso account di prima, comodo da tenere insieme):
  `firebase init hosting` poi `firebase deploy` (richiede Node.js e
  `npm install -g firebase-tools`).
- **GitHub Pages**: carica i file in un repository, attiva Pages nelle
  impostazioni del repo.

## 3. Attenzione alla sicurezza

Le regole Firestore suggerite sono **aperte**: chiunque abbia il link puo'
leggere e modificare i dati. Nessun login, per restare semplice. Va bene
per un uso tra squadra/famiglia con link privato, non pubblicizzato.
Se in futuro vuoi un vero login (es. solo l'allenatore puo' modificare, gli
altri vedono in sola lettura), si puo' aggiungere l'autenticazione Firebase:
basta chiedermelo.

## File in questa cartella

- `index.html`, `player.html`, `style.css`, `roster.js`, `script.js` —
  la tua app, invariata nella logica.
- `firebase-config.js` — **nuovo**: qui incolli le credenziali del tuo
  database. Contiene le istruzioni complete.

## Import dello storico da PlayBasket

Nella scheda giocatore c'e' la sezione **Storico da PlayBasket** con il
pulsante **Importa da PlayBasket** (visibile solo a chi ha sbloccato la
modifica). Si incolla il link del profilo, si controlla l'anteprima e si
conferma. Vengono importati i **totali per stagione e competizione** (punti,
presenze, media, best), non le singole partite: restano separati dal Registro
Partite e non modificano le statistiche calcolate. Si sincronizzano con
Firebase come il resto dei dati.

- Metodo principale: `api/playbasket.js` e' una funzione serverless Vercel che
  scarica la pagina lato server. Funziona quando il progetto e' pubblicato su
  Vercel (import da GitHub oppure `npx vercel` dalla cartella del progetto):
  la cartella `api` viene riconosciuta da sola, senza configurazione.
- Alternativa che funziona ovunque: nella finestra di import c'e' "Il link non
  funziona? Incolla la tabella": si copia la tabella dal profilo PlayBasket e
  si incolla.

Nuovo file: `playbasket-import.js`. Modificati: `player.html`, `script.js`
(salvataggio/caricamento dei nuovi campi), `style.css`.

## Aggiornamento Scout Live e home

- **Home**: menu "Ordina per" (media punti più alta / più bassa, nome, cognome, ruolo). L'ordine scelto viene ricordato. Priorità ruoli: Playmaker, Guardia, Ala piccola, Ala grande, Centro, poi ruolo non impostato (modificabile in `roster.js`, costante `ROLE_ORDER`). I giocatori senza media punti vanno in fondo.
- **Scheda giocatore**: il banner "sola lettura" non lampeggia più all'apertura; compare solo dopo la verifica di accesso.
- **Setup Scout Live**: non si può inserire due volte lo stesso giocatore (né lo stesso numero); nuovi campi Competizione, Tipo partita, Data, Giornata, N° partita e durata del quarto. Questi dati vengono salvati nel registro partite del giocatore all'import.
- **Scout**: tiri liberi con mini menu (Segnato / Sbagliato con un tocco, più inserimento multiplo), cronometro per periodo (avvio/stop, tocco sul tempo per modificarlo), pulsante +OT per più supplementari, minuti giocati per giocatore, cambi dal menu "Numeri" (panchina → poi chi esce).
- **Partita finita**: scarica box score in JPG, "Importa e chiudi partita", oppure "Non importare e chiudi partita" (rosso).
- File modificati: `index.html`, `roster.js`, `script.js`, `style.css`, `scout.html`, `scout.js`, `scout.css`, `scout-setup.js`.

## Aggiornamento Scout Live (stagione, roster, immagini, profilo)

- **Stagione**: nel setup c'e' il campo Stagione (si compila da sola dalla data, es. 2026/27, ma si puo' modificare). Compare nell'intestazione dello scout, nelle immagini e viene salvata nella partita del giocatore all'import.
- **Emoji**: tolte da tutte le schermate di Scout Live e dal setup partita (icone del cronometro ora in SVG). Restano solo quelle delle altre pagine (Night Mode, ricerca, ecc.).
- **Roster**: "Numeri" ora si chiama **Roster** ed e' un pulsante fisso in basso a destra, sempre visibile (anche scorrendo la pagina e a cronometro in marcia). Il cambio e' rapido: panchina, poi chi esce. La finestra resta aperta per piu' cambi di fila; mostra minuti, punti e falli.
- **Fine partita**: mostra il riepilogo box score e i 3 tasti: Scarica box score (JPG), Importa e chiudi partita, Non importare e chiudi partita (la X in alto torna allo scout).
- **Scout come immagine**: dal pulsante Box Score dello scout: Box score (JPG), Scout giocatore (JPG: mappa tiri + statistiche del giocatore attivo) e Tutti gli scout (ZIP con box score + una immagine per ogni giocatore).
- **Scout nel profilo**: all'import ogni partita salva anche mappa dei tiri e box score di squadra. Nel Registro Partite compare il pulsante **Scout** sotto l'avversario: si apre la mappa tiri (filtro per tempo), le statistiche, il box score, con download JPG. Con "Tutte le partite con scout" si vede la mappa tiri cumulativa (rispetta il filtro stagione).
- Nuovi file: `scout-render.js` (immagini/ZIP condivisi), `scout-view.js` e `scout-view.css` (vista nel profilo). Modificati: `scout.html`, `scout.js`, `scout.css`, `scout-setup.js`, `index.html`, `player.html`, `script.js`.

## Versione telefono (Scout Live, setup e profilo)

- **Barra in basso** (solo su telefono): Tiri, Statistiche, **Roster** (evidenziato), Annulla, Altro. Il pulsante Roster e' sempre a portata di pollice per i cambi. "Altro" apre un menu con Box score, Partita finita, Tema chiaro/scuro ed Esci.
- **Schermata scout compatta**: niente intestazione, punteggio con cronometro e pulsanti avversari grandi (-1 rosso, +1 +2 +3), giocatori in campo sempre per primi, riga del giocatore attivo su una linea. Il campo si adatta all'altezza dello schermo, cosi' si vede tutto senza scorrere.
- **Finestre a scorrimento dal basso** con maniglia, X grande e tasti fissi in fondo. Si chiudono anche toccando fuori (tranne setup partita e conferme, per non perdere dati).
- **Roster**: righe grandi con numero, barra verde per chi e' in campo, e un avviso passo-passo (chi entra, poi chi esce, con le righe di chi puo' uscire evidenziate in rosso).
- **Box score e riepilogo**: numero e nome restano fissi mentre scorri le colonne; tasti fissi in fondo.
- **Setup partita**: a schermo quasi intero, campi affiancati a due a due, tastiera grande (niente zoom automatico su iPhone), tasto "Inizia lo scout" sempre visibile.
- **Scout nel profilo**: mappa tiri in alto, statistiche a tessere, filtri scorrevoli, tasti JPG fissi in fondo.
- **Schermo sempre acceso** durante lo scout (dove il telefono lo permette).
- Nuovi file: `scout-mobile.css`, `scout-mobile.js`. Modificati: `scout.html`, `scout.js`, `scout.css`, `index.html`, `player.html`.

## Scout singolo, tasti compatti e rifiniture (desktop + mobile)

- **Scout singolo**: nel setup, in alto, scegli "Squadra intera" oppure "Giocatore singolo". Con il singolo segui una sola persona: niente barra giocatori né cambi; il pulsante in basso/destra diventa "In campo / In panchina" (i minuti scorrono solo quando e' in campo). Puoi segnare a mano i punti dei compagni e degli avversari (tasti -1 +1 +2 +3 con le scritte "Punti compagni" e "Avversari"); il punteggio squadra = punti del giocatore + punti dei compagni. Box score e import mostrano solo quel giocatore, e nel profilo la partita ha il pulsante Scout come le altre.
- **Setup partita (desktop)**: finestra piu' larga; Competizione affiancata a Tipo partita; Data, Stagione, Giornata, N° partita e Quarto (min) su una sola riga; i giocatori si inseriscono in un'unica colonna e si scorre verso il basso (niente scorrimento a destra); Annulla / Inizia lo scout restano sempre visibili.
- **Tasti compatti** in tutte le finestre dello scout: Scarica box score (JPG), Importa e chiudi partita, Non importare e chiudi partita (rosso morbido), Esporta JSON, Box score (JPG), Scout giocatore (JPG), Tutti gli scout (ZIP), Chiudi. Su desktop sono in fila e a larghezza naturale; su telefono in colonna o a due a due, alti 40-42 px.
- **Fine partita**: intestazione con squadre e punteggio ben allineati; box score con colonne a larghezza fissa (intestazioni e valori allineati), su telefono N° e nome restano fissi mentre scorri.
- **Mobile, scout**: punti avversari (-1 +1 +2 +3) sulla destra, piu' piccoli; popup del setup ridimensionato (campi da 40 px, Annulla e Inizia sulla stessa riga).
- **Mobile, home**: "Ordina per" e' di fianco alla barra di ricerca (etichette corte: Media alta, Media bassa, Nome A-Z, Cognome A-Z, Ruolo); la scritta di "Scout Live" e "Aggiungi Giocatore" e' centrata e si adatta al tasto senza cambiarne la dimensione.
- **Mobile, profilo giocatore**: la scritta di "Tutte le stagioni" torna alla dimensione normale (prima era ingrandita dalla regola anti-zoom, ora limitata alle schermate dello scout).
- Nuovo file: `scout-ui.css` (stile condiviso). Modificati: `index.html`, `player.html`, `scout.html`, `scout.js`, `scout.css`, `scout-setup.js`, `scout-render.js`, `scout-view.js`, `scout-mobile.css`, `scout-mobile.js`.
