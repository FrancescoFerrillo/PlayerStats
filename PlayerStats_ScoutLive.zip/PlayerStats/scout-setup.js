// scout-setup.js — Home: pulsante "Scout Live" + setup partita (12 giocatori, avversario, dettagli partita)
const SCOUT_KEY = "psScoutLive";
const SCOUT_COMPS_KEY = "psScoutComps"; // ultime competizioni usate (suggerimenti)
const scLoad = () => { try { return JSON.parse(localStorage.getItem(SCOUT_KEY)); } catch (e) { return null; } };
const scRows = $("scRows");

const SC_GAME_TYPES = [
  "RS (Regular Season)", "Amichevole (Pre season)", "PlayIn", "PlayOut", "PlayOff",
  "Ottavi di finale (Round of 16)", "Quarti di finale (Quarterfinals)", "Semifinale (Semifinal)", "Finale (Final)"
];
$("scType").innerHTML = SC_GAME_TYPES.map(t => `<option value="${esc(t)}">${esc(t)}</option>`).join("");

const scSeasonOf = d => { const y = +String(d).slice(0, 4), m = +String(d).slice(5, 7); if (!y) return ""; return m >= 8 ? `${y}/${String(y + 1).slice(2)}` : `${y - 1}/${String(y).slice(2)}`; };
const scToday = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };

// Normalizza un nome per confrontarlo: senza accenti/maiuscole e con le parole in ordine alfabetico,
// cosi' "Mario Rossi" e "rossi  mario" risultano lo stesso giocatore.
const scNormName = s => String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
  .replace(/[^a-z0-9 ]/g, " ").split(/\s+/).filter(Boolean).sort().join(" ");

function scCompSuggestions() {
  const set = new Set();
  try { (JSON.parse(localStorage.getItem(SCOUT_COMPS_KEY)) || []).forEach(c => c && set.add(c)); } catch (e) { /* ignora */ }
  // anche le competizioni gia' presenti nei registri partite salvati su questo dispositivo
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (!k || !k.startsWith("capocottaStats_")) continue;
      const d = JSON.parse(localStorage.getItem(k));
      (d && d.games || []).forEach(g => { if (g.category && String(g.category).trim()) set.add(String(g.category).trim()); });
    }
  } catch (e) { /* ignora */ }
  return [...set].slice(0, 30);
}
function scRememberComp(c) {
  if (!c) return;
  try {
    const arr = (JSON.parse(localStorage.getItem(SCOUT_COMPS_KEY)) || []).filter(x => x !== c);
    arr.unshift(c);
    localStorage.setItem(SCOUT_COMPS_KEY, JSON.stringify(arr.slice(0, 12)));
  } catch (e) { /* ignora */ }
}

// Controlla i doppioni tra le righe: stesso giocatore o stesso numero di maglia.
// Evidenzia le righe in conflitto e restituisce il messaggio da mostrare (o "").
function scCheckDuplicates() {
  const rows = [...scRows.querySelectorAll(".sc-row")];
  const seenName = new Map(), seenNum = new Map();
  let msg = "";
  rows.forEach(r => r.classList.remove("dup"));
  rows.forEach((r, i) => {
    const name = r.querySelector(".sc-name").value.trim();
    const num = r.querySelector(".sc-num").value.trim();
    if (name) {
      const k = scNormName(name);
      if (k && seenName.has(k)) {
        r.classList.add("dup"); rows[seenName.get(k)].classList.add("dup");
        msg = msg || `"${name}" è già inserito (righe ${seenName.get(k) + 1} e ${i + 1}).`;
      } else if (k) seenName.set(k, i);
    }
    if (num && name) {
      if (seenNum.has(num)) {
        r.classList.add("dup"); rows[seenNum.get(num)].classList.add("dup");
        msg = msg || `Il numero ${num} è assegnato a due giocatori (righe ${seenNum.get(num) + 1} e ${i + 1}).`;
      } else seenNum.set(num, i);
    }
  });
  const el = $("scDupMsg");
  el.textContent = msg;
  el.classList.toggle("hidden", !msg);
  return msg;
}

// Il suggerimento a tendina non propone i giocatori gia' scelti in un'altra riga
function scRefreshDatalist() {
  const used = new Set([...scRows.querySelectorAll(".sc-name")].map(i => scNormName(i.value)).filter(Boolean));
  const dl = document.getElementById("scRoster");
  if (!dl) return;
  dl.innerHTML = loadRegistry()
    .filter(p => !used.has(scNormName(`${p.firstName || ""} ${p.lastName || ""}`)))
    .map(p => `<option value="${esc((p.firstName + " " + p.lastName).trim())}" label="#${esc(p.number || "-")}"></option>`).join("");
}

// Modalita': "team" = 12 giocatori con cambi, "single" = scout di una sola persona
let scMode = "team", scBackup = null;
const scCount = () => scMode === "single" ? 1 : 12;
const scCollect = () => [...scRows.querySelectorAll(".sc-row")].map(r => ({ name: r.querySelector(".sc-name").value, number: r.querySelector(".sc-num").value }));
const SC_HINT = {
  team: "Servono almeno 5 giocatori. Lo stesso giocatore (o lo stesso numero di maglia) non può essere inserito due volte. Il pulsante Scegli importa un giocatore già presente nel database. La stagione si compila da sola in base alla data, ma puoi modificarla.",
  single: "Scout singolo: segui una sola persona. Niente cambi né roster: puoi segnare a mano i punti dei compagni e degli avversari. Il pulsante Scegli importa un giocatore già presente nel database."
};
function scSetMode(m, keep = true) {
  if (keep && scMode === "team") scBackup = scCollect();
  const cur = keep ? scCollect() : [];
  scMode = m;
  document.querySelectorAll("#scMode button").forEach(b => b.classList.toggle("on", b.dataset.mode === m));
  document.getElementById("scoutSetupDialog").classList.toggle("single", m === "single");
  $("scPlTitle").textContent = m === "single" ? "Giocatore da seguire" : "Giocatori (12)";
  $("scHint").textContent = SC_HINT[m];
  let rows = null;
  if (m === "single") rows = [cur.find(x => x.name.trim() || x.number.trim()) || {}];
  else rows = scBackup || cur;
  scBuildRows(rows);
}
document.querySelectorAll("#scMode button").forEach(b => b.onclick = () => { if (b.dataset.mode !== scMode) scSetMode(b.dataset.mode); });

function scBuildRows(saved) {
  const N = scCount();
  scRows.innerHTML = Array.from({ length: N }, (_, i) => `
    <div class="sc-row">
      <span class="sc-idx">${i + 1}</span>
      <input class="sc-num" inputmode="numeric" maxlength="3" placeholder="#" value="${esc(saved?.[i]?.number || "")}">
      <input class="sc-name" list="scRoster" placeholder="Nome e cognome" value="${esc(saved?.[i]?.name || "")}">
      <button type="button" class="sc-pick" title="Scegli dal database">Scegli</button>
    </div>`).join("") + `<datalist id="scRoster"></datalist>`;
  const filled = () => { $("scFilled").textContent = [...scRows.querySelectorAll(".sc-name")].filter(i => i.value.trim()).length + "/" + N; };
  scRows.querySelectorAll(".sc-row").forEach(row => {
    const name = row.querySelector(".sc-name"), num = row.querySelector(".sc-num");
    const fill = () => {
      const q = scNormName(name.value);
      const m = q && loadRegistry().find(p => scNormName(`${p.firstName || ""} ${p.lastName || ""}`) === q);
      if (m && !num.value && m.number) num.value = m.number;
      filled(); scCheckDuplicates(); scRefreshDatalist();
    };
    name.addEventListener("input", fill); name.addEventListener("change", fill);
    num.addEventListener("input", scCheckDuplicates);
    row.querySelector(".sc-pick").onclick = () => { name.value = ""; scCheckDuplicates(); scRefreshDatalist(); name.focus(); name.showPicker?.(); };
  });
  filled(); scRefreshDatalist(); scCheckDuplicates();
}

function scRefreshLabel() {
  const s = scLoad();
  $("scoutLiveLabel").textContent = s && !s.finished ? "Riprendi Scout Live" : "Scout Live";
  $("scoutLiveBtn").classList.toggle("has-live", !!(s && !s.finished));
}
scRefreshLabel();

$("scoutLiveBtn").onclick = async () => {
  const s = scLoad();
  if (s && !s.finished) {
    const resume = await showCustomConfirm("Partita in corso",
      `Hai una partita non conclusa contro ${s.opp}. Vuoi riprenderla? (Annulla = iniziane una nuova, quella attuale andrà persa)`);
    if (resume) { location.href = "scout.html"; return; }
  }
  $("scoutSetupForm").reset();
  $("scDate").value = scToday();
  $("scSeason").value = scSeasonOf($("scDate").value); $("scSeason").dataset.manual = "";
  $("scType").value = SC_GAME_TYPES[0];
  $("scCompList").innerHTML = scCompSuggestions().map(c => `<option value="${esc(c)}"></option>`).join("");
  scBackup = null; scSetMode("team", false);
  $("scoutSetupDialog").showModal();
};

// La stagione segue la data finche' non viene modificata a mano
$("scDate").addEventListener("input", () => { if (!$("scSeason").dataset.manual) $("scSeason").value = scSeasonOf($("scDate").value); });
$("scSeason").addEventListener("input", () => { $("scSeason").dataset.manual = $("scSeason").value.trim() ? "1" : ""; });

$("scoutSetupForm").onsubmit = async e => {
  e.preventDefault();
  const dup = scCheckDuplicates();
  if (dup) { await showCustomConfirm("Giocatore duplicato", dup + " Correggi prima di iniziare.", true, true); return; }
  const players = [...scRows.querySelectorAll(".sc-row")].map((r, i) => ({
    id: "sp" + (i + 1), name: r.querySelector(".sc-name").value.trim().replace(/\s+/g, " "), number: r.querySelector(".sc-num").value.trim(), onCourt: false, sec: 0
  })).filter(p => p.name);
  const minP = scMode === "single" ? 1 : 5;
  if (players.length < minP) { await showCustomConfirm(scMode === "single" ? "Manca il giocatore" : "Servono più giocatori", scMode === "single" ? "Inserisci il nome del giocatore da seguire." : "Inserisci almeno 5 giocatori per iniziare.", true, true); return; }
  players.slice(0, scMode === "single" ? 1 : 5).forEach(p => p.onCourt = true);
  const comp = $("scComp").value.trim();
  scRememberComp(comp);
  const qLen = Math.min(30, Math.max(1, parseInt($("scQLen").value, 10) || 10));
  localStorage.setItem(SCOUT_KEY, JSON.stringify({
    v: 2, mode: scMode, teamExtra: 0, team: $("scTeam").value.trim() || "Noi", opp: $("scOpp").value.trim(),
    comp, ageGroup: $("scAge").value, venue: $("scVenue").value, gameType: $("scType").value, giornata: $("scGiornata").value.trim(), gameNumber: $("scGameNum").value.trim(),
    date: $("scDate").value || scToday(), season: $("scSeason").value.trim() || scSeasonOf($("scDate").value || scToday()),
    qLen, otLen: 5, periods: ["Q1", "Q2", "Q3", "Q4"], clock: { rem: {}, running: false, last: 0 },
    quarter: "Q1", oppScore: 0, players, events: [], subs: [], finished: false, startedAt: Date.now()
  }));
  location.href = "scout.html";
};
