// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCj926hBev9jT8_IkuM8aLNqVAg0_GLKdQ",
  authDomain: "player-stats-bd1af.firebaseapp.com",
  projectId: "player-stats-bd1af",
  storageBucket: "player-stats-bd1af.firebasestorage.app",
  messagingSenderId: "530296378791",
  appId: "1:530296378791:web:d65bef59c4e8ccbcb71282",
  measurementId: "G-GRNG72LHHW"
};

window.cloudDB = null;
try {
  if (firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith("INCOLLA_QUI")) {
    firebase.initializeApp(firebaseConfig);
    window.cloudDB = firebase.firestore();
    console.log("[Player Stats Profile] Database condiviso attivo (Firebase).");
  } else {
    console.log("[Player Stats Profile] Firebase non configurato: uso solo il salvataggio locale del browser.");
  }
} catch (e) {
  console.warn("[Player Stats Profile] Impossibile inizializzare Firebase, uso solo il salvataggio locale.", e);
  window.cloudDB = null;
}
